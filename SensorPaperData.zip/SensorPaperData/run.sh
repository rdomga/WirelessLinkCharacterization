#! /bin/bash

#Parse and plot figures
python PythonCode/Parse_All.py
python PythonCode/Plot_All.py
python PythonCode/RunAnalyticalModel.py

#COpy Images useed in the paper
#Theoretcal RSSI and PRR
cp Analytical/FLAT_26_3_82/SIMULATED/ANAL_CDF_PRR.eps Images_Paper
cp Analytical/FLAT_26_3_82/SIMULATED/ANAL_PRR_VAL.eps Images_Paper

cp Analytical_Validation/VALIDATION_PRR_FLAT_HILL_CDF_ALL_LINKS_102.eps Images_Paper
cp Analytical_Validation/VALIDATION_RSSI_FLAT_HILL_CDF_ALL_LINKS_102.eps Images_Paper

#Impact of the ground
cp Impact_Ground/26/3/82/LINK_PRR_DEF_GROUND_HEIGTH.eps Images_Paper

cp Impact_Ground/26/3/82/PRR_1_2_GROUND_HEIGTH.eps Images_Paper
cp Impact_Ground/26/3/82/PRR_3_4_GROUND_HEIGTH.eps Images_Paper
cp Impact_Ground/26/3/82/RSSI_1_2_GROUND_HEIGTH.eps Images_Paper
cp Impact_Ground/26/3/82/RSSI_3_4_GROUND_HEIGTH.eps Images_Paper

cp Impact_Ground/26/3/82/CDF_RSSI_GROUND_HEIGTH_3M.eps Images_Paper
cp Impact_Ground/26/3/82/CDF_RSSI_GROUND_HEIGTH_6M.eps Images_Paper
cp Impact_Ground/26/3/82/CDF_RSSI_GROUND_HEIGTH_ALL_LINKS.eps Images_Paper

cp Impact_Ground/26/3/82/CDF_PRR_GROUND_HEIGTH_3M.eps Images_Paper
cp Impact_Ground/26/3/82/CDF_PRR_GROUND_HEIGTH_6M.eps Images_Paper
cp Impact_Ground/26/3/82/CDF_PRR_GROUND_HEIGTH_ALL_LINKS.eps Images_Paper

#Impact of the Channel
cp Impact_Channel/3/82/LINK_PRR_DEF_FREQUENCY.eps Images_Paper

cp Impact_Channel/3/82/CDF_RSSI_FREQUENCY_3M.eps Images_Paper
cp Impact_Channel/3/82/CDF_RSSI_FREQUENCY_6M.eps Images_Paper
cp Impact_Channel/3/82/CDF_RSSI_FREQUENCY_ALL_LINKS.eps Images_Paper

cp Impact_Channel/3/82/CDF_PRR_FREQUENCY_3M.eps Images_Paper
cp Impact_Channel/3/82/CDF_PRR_FREQUENCY_6M.eps Images_Paper
cp Impact_Channel/3/82/CDF_PRR_FREQUENCY_ALL_LINKS.eps Images_Paper

#Impact of the Message size
cp Impact_MSize/Ground/26/3/LINK_PRR_DEF_PKTSIZE.eps Images_Paper

cp Impact_MSize/Ground/26/3/CDF_RSSI_PKTSIZE_3M.eps Images_Paper
cp Impact_MSize/Ground/26/3/CDF_RSSI_PKTSIZE_6M.eps Images_Paper
cp Impact_MSize/Ground/26/3/CDF_RSSI_PKTSIZE_ALL_LINKS.eps Images_Paper

cp Impact_MSize/Ground/26/3/CDF_PRR_PKTSIZE_3M.eps Images_Paper
cp Impact_MSize/Ground/26/3/CDF_PRR_PKTSIZE_6M.eps Images_Paper
cp Impact_MSize/Ground/26/3/CDF_PRR_PKTSIZE_ALL_LINKS.eps Images_Paper

#Impact of the Topograpy
cp Impact_Topography/3/82/LINK_PRR_DEF_FLAT_HILL.eps Images_Paper

cp Impact_Topography/3/82/CDF_RSSI_FLAT_HILL_3M.eps Images_Paper
cp Impact_Topography/3/82/CDF_RSSI_FLAT_HILL_6M.eps Images_Paper
cp Impact_Topography/3/82/CDF_RSSI_FLAT_HILL_ALL_LINKS.eps Images_Paper

cp Impact_Topography/3/82/CDF_PRR_FLAT_HILL_3M.eps Images_Paper
cp Impact_Topography/3/82/CDF_PRR_FLAT_HILL_6M.eps Images_Paper
cp Impact_Topography/3/82/CDF_PRR_FLAT_HILL_ALL_LINKS.eps Images_Paper


#Correlation between Link quality and distance
cp Distance_Correlation/82/STAT_PRR_DISTANCE.eps Images_Paper
cp Distance_Correlation/82/STAT_RSSI_DISTANCE.eps Images_Paper

