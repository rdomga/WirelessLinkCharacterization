
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.style
import matplotlib
matplotlib.use('Agg')

matplotlib.style.use('classic')

import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter
import numpy as np
import six
from matplotlib import colors

import gc    
import math, random
from collections import Counter

fond_size = 16
legend_fond_size = 14
lines_width = 2.0

image_width = 6
image_heigth = 4

def PlotSingleTopologieMultipleCurves_AllParams(x_datas, y_datas, y_errors, xlab, ylab, titre, image_fname, legends, legend_title, xticInt, yticInt, o_legend, min_x, max_x, min_y, max_y, stic_x, stic_y, xticslabels = None, x_decimal=2, y_decimal=2, yticlab=None):        
    try:
        #params = {'font.size':23, 'lines.linewidth': 2.0, 'legend.fontsize': 18}
        params = {'font.size':fond_size, 'lines.linewidth': lines_width, 'legend.fontsize': legend_fond_size}

        plt.rcParams.update(params)
        fig, ax = plt.subplots()
                
        lignes = ['-', '--', '-.', ':']
        s_lignes = len(lignes)
        unfilled_markers = ['<', 's','p','*', 'o','v','+','^', '>', 'd', 'D' ,'h','H','x','1','2','3','4','8']
        s_markers = len(unfilled_markers)
        for i in range(len(y_datas)):
            if legends != None:
                if y_errors == None:
                    plt.plot(x_datas[i], y_datas[i], label=legends[i], linestyle=lignes[i%s_lignes], marker=unfilled_markers[i%s_markers])
                else:
                    plt.errorbar(x_datas[i], y_datas[i], yerr=y_errors[i], label=legends[i], linestyle=lignes[0], marker=None)
            else:
                if y_errors == None:
                    plt.plot(x_datas[i], y_datas[i], linestyle=lignes[i%s_lignes], marker=unfilled_markers[i%s_markers])
                else:
                    plt.errorbar(x_datas[i], y_datas[i], yerr=y_errors[i], linestyle=lignes[0], marker=None)
        if xticslabels != None:
            plt.xticks(xticslabels)            
        elif stic_x != None:
            if xticInt == 0:
                ax.xaxis.set_major_formatter(FormatStrFormatter('%.' + str(x_decimal) + 'f'))
            else:
                ax.xaxis.set_major_formatter(FormatStrFormatter('%d')) 
            
            if stic_x != 0 and min_x != max_x:
                vec = np.arange(min_x, max_x, stic_x)
            else:
                vec = [min_x, max_x]
            plt.xticks(vec)
        
        if yticlab != None:
            plt.yticks(yticlab)
        elif stic_y != None:
            if yticInt == 0:
                ax.yaxis.set_major_formatter(FormatStrFormatter('%.' + str(y_decimal) + 'f'))
            else:
                ax.yaxis.set_major_formatter(FormatStrFormatter('%d'))
            if stic_y != 0 and min_x != max_x:
                vec = np.arange(min_y, max_y, stic_y)
            else:
                vec = [min_y, max_y]
            plt.yticks(vec)
        
        #print "BB3"

        axes = plt.gca()
        axes.set_xlim([min_x, max_x])
        axes.set_ylim([min_y, max_y])
        #print "BB4"
        
        if legends != None:
            if o_legend == 1:
                leg = plt.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=2, mode="expand", borderaxespad=0., title=legend_title)
            elif o_legend == 0:
                #nbcols = max(1, len(y_datas)/2)
                leg = plt.legend(loc=0, ncol=1, title=legend_title)
            else:
                leg = plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0., title=legend_title)            
            leg.get_title().set_fontsize('18')            
            leg.get_frame().set_linewidth(2.0)
        
        fig.set_size_inches(image_width, image_heigth)
        #fig.set_size_inches(7.5, 6.5)
        
        plt.xlabel(xlab)        
        plt.ylabel(ylab)
        plt.title(titre, fontsize=12)
        #print "BB6"
        if legends != None:
            plt.savefig(image_fname, bbox_extra_artists=(leg,), bbox_inches='tight')
        else:
            plt.savefig(image_fname, bbox_inches='tight')
            
        plt.close()    
        gc.collect()
    except Exception as inst:
        print type(inst)
        print inst.args        
        print x_datas
        print y_datas       


def PlotSingleTopologieMultipleCurves_AllParams_NoMarkers(x_datas, y_datas, y_errors, xlab, ylab, titre, image_fname, legends, legend_title, xticInt, yticInt, o_legend, min_x, max_x, min_y, max_y, stic_x, stic_y, xticslabels = None, x_decimal=2, y_decimal=2):        
    try:
        #params = {'font.size':23, 'lines.linewidth': 2.0, 'legend.fontsize': 18}
        params = {'font.size':fond_size, 'lines.linewidth': lines_width, 'legend.fontsize': legend_fond_size}

        plt.rcParams.update(params)
        fig, ax = plt.subplots()
                
        lignes = ['-', '--', ':', '-.']
        s_lignes = len(lignes)
        if xticslabels != None:
            markers_on = xticslabels
        else : 
            markers_on = range(10)
            
        markevery=markers_on
        
        for i in range(len(y_datas)):
            if legends != None:
                if y_errors == None:
                    plt.plot(x_datas[i], y_datas[i], label=legends[i], linestyle=lignes[i%s_lignes])
                else:
                    plt.errorbar(x_datas[i], y_datas[i], yerr=y_errors[i], label=legends[i], linestyle=lignes[0], marker=None)
            else:
                if y_errors == None:
                    plt.plot(x_datas[i], y_datas[i], linestyle=lignes[i%s_lignes])
                else:
                    plt.errorbar(x_datas[i], y_datas[i], yerr=y_errors[i], linestyle=lignes[0], marker=None)
        if xticslabels != None:
            print "xtics passed"
            plt.xticks(xticslabels)            
        elif stic_x != None:
            if xticInt == 0:
                ax.xaxis.set_major_formatter(FormatStrFormatter('%.' + str(x_decimal) + 'f'))
            else:
                ax.xaxis.set_major_formatter(FormatStrFormatter('%d')) 
            
            if stic_x != 0 and min_x != max_x:
                vec = np.arange(min_x, max_x, stic_x)
            else:
                vec = [min_x, max_x]
            plt.xticks(vec)
        else: 
            if xticInt == 0:
                ax.xaxis.set_major_formatter(FormatStrFormatter('%.' + str(x_decimal) + 'f'))
            else:
                ax.xaxis.set_major_formatter(FormatStrFormatter('%d')) 
            
        if stic_y != None:
            if yticInt == 0:
                ax.yaxis.set_major_formatter(FormatStrFormatter('%.' + str(y_decimal) + 'f'))
            else:
                ax.yaxis.set_major_formatter(FormatStrFormatter('%d'))
            if stic_y != 0 and min_x != max_x:
                vec = np.arange(min_y, max_y, stic_y)
            else:
                vec = [min_y, max_y]
            plt.yticks(vec)
        else:
            if yticInt == 0:
                ax.yaxis.set_major_formatter(FormatStrFormatter('%.' + str(y_decimal) + 'f'))
            else:
                ax.yaxis.set_major_formatter(FormatStrFormatter('%d'))
        
        #print "BB3"

        axes = plt.gca()
        axes.set_xlim([min_x, max_x])
        axes.set_ylim([min_y, max_y])
        #print "BB4"
        
        if legends != None:
            if o_legend == 1:
                leg = plt.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=2, mode="expand", borderaxespad=0., title=legend_title)
            elif o_legend == 0:
                #nbcols = max(1, len(y_datas)/2)
                leg = plt.legend(loc=0, ncol=1, title=legend_title)
            elif o_legend == 2:
                leg = plt.legend(loc=0, ncol=3, title=legend_title)
            else:
                leg = plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0., title=legend_title)            
            leg.get_title().set_fontsize('18')            
            leg.get_frame().set_linewidth(2.0)
        
        fig.set_size_inches(image_width, image_heigth)
        
        plt.xlabel(xlab)        
        plt.ylabel(ylab)
        plt.title(titre, fontsize=12)
        #print "BB6"
        if legends != None:
            plt.savefig(image_fname, bbox_extra_artists=(leg,), bbox_inches='tight')
        else:
            plt.savefig(image_fname, bbox_inches='tight')
            
        plt.close()    
        gc.collect()
    except Exception as inst:
        print type(inst)
        print inst.args        
        print x_datas
        print y_datas       

def PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(x_datas, y_datas, y_errors, xlab, ylab, titre, image_fname, legends, legend_title, xticInt, yticInt, o_legend, min_x, max_x, min_y, max_y, stic_x, stic_y, xticslabels = None, x_decimal=2, y_decimal=2, lfs=None, yticlab=None, labtics = None):        
    try:
        if lfs != None:
            params = {'font.size':fond_size, 'lines.linewidth': lines_width, 'legend.fontsize': lfs}
        else:
            params = {'font.size':fond_size, 'lines.linewidth': lines_width, 'legend.fontsize': legend_fond_size}
            
        plt.rcParams.update(params)
        fig, ax = plt.subplots()
                
        lignes = ['-', '--', ':', '-.']
        s_lignes = len(lignes)

        markevery_val = 0.1
        
        unfilled_markers = ['<', 's','p','*', 'o','v','+','^', '>', 'd', 'D' ,'h','H','x','1','2','3','4','8']
        s_markers = len(unfilled_markers)
        for i in range(len(y_datas)):
            if legends != None:
                if y_errors == None:
                    plt.plot(x_datas[i], y_datas[i], label=legends[i], linestyle=lignes[i%s_lignes], marker=unfilled_markers[i%s_markers], markevery=markevery_val)
                else:
                    plt.errorbar(x_datas[i], y_datas[i], yerr=y_errors[i],  label=legends[i], linestyle=lignes[i%s_lignes], marker=unfilled_markers[i%s_markers], markevery=markevery_val)                    
                    #plt.errorbar(x_datas[i], y_datas[i], yerr=y_errors[i], label=legends[i], linestyle=lignes[0], marker=None)
            else:
                if y_errors == None:
                    plt.plot(x_datas[i], y_datas[i], linestyle=lignes[i%s_lignes], marker=unfilled_markers[i%s_markers], markevery=markevery_val)
                else:
                    plt.errorbar(x_datas[i], y_datas[i], yerr=y_errors[i], linestyle=lignes[i%s_lignes], marker=unfilled_markers[i%s_markers], markevery=markevery_val)
                    
        if (xticslabels != None) and (labtics != None):
            plt.xticks(xticslabels, labtics)            
        elif xticslabels != None:
            plt.xticks(xticslabels)
        elif stic_x != None:
            if xticInt == 0:
                ax.xaxis.set_major_formatter(FormatStrFormatter('%.' + str(x_decimal) + 'f'))
            else:
                ax.xaxis.set_major_formatter(FormatStrFormatter('%d')) 
            
            if stic_x != 0 and min_x != max_x:
                vec = np.arange(min_x, max_x, stic_x)
            else:
                vec = [min_x, max_x]
            plt.xticks(vec)
        else: 
            if xticInt == 0:
                ax.xaxis.set_major_formatter(FormatStrFormatter('%.' + str(x_decimal) + 'f'))
            else:
                ax.xaxis.set_major_formatter(FormatStrFormatter('%d')) 
        
        if yticlab != None:
            plt.yticks(yticlab)
        elif stic_y != None:
            if yticInt == 0:
                ax.yaxis.set_major_formatter(FormatStrFormatter('%.' + str(y_decimal) + 'f'))
            else:
                ax.yaxis.set_major_formatter(FormatStrFormatter('%d'))
            if stic_y != 0 and min_x != max_x:
                vec = np.arange(min_y, max_y, stic_y)
            else:
                vec = [min_y, max_y]
            plt.yticks(vec)
        else:
            if yticInt == 0:
                ax.yaxis.set_major_formatter(FormatStrFormatter('%.' + str(y_decimal) + 'f'))
            else:
                ax.yaxis.set_major_formatter(FormatStrFormatter('%d'))
        
        axes = plt.gca()
        if (min_x != None) and (max_x != None):
            axes.set_xlim([min_x, max_x])
            
        if (min_y != None) and (max_y != None):
            axes.set_ylim([min_y, max_y])
        
        if legends != None:
            if o_legend == 1:
                leg = plt.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=2, mode="expand", borderaxespad=0., title=legend_title,fancybox=True,framealpha=0.5)
            elif o_legend == 0:
                leg = plt.legend(loc=0, ncol=1, title=legend_title,fancybox=True,framealpha=0.5)
            elif o_legend == 2:
                leg = plt.legend(loc=0, ncol=2, title=legend_title,fancybox=True,framealpha=0.5)
            else:
                leg = plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0., title=legend_title,fancybox=True,framealpha=0.5)            
            leg.get_title().set_fontsize('18')            
            leg.get_frame().set_linewidth(2.0)
            leg.get_frame().set_facecolor('none')
            
        
            #set(leg, 'color','none')
        
        fig.set_size_inches(image_width, image_heigth)
        
        plt.xlabel(xlab)        
        plt.ylabel(ylab)
        plt.title(titre, fontsize=12)
        if legends != None:
            plt.savefig(image_fname, bbox_extra_artists=(leg,), bbox_inches='tight')
        else:
            plt.savefig(image_fname, bbox_inches='tight')
            
        plt.close()    
        gc.collect()
    except Exception as inst:
        print type(inst)
        print inst.args        
        print x_datas
        print y_datas       

def PlotBar(x_datas, y_datas, y_errors, xlab, ylab, titre, image_fname, legends, legend_title, min_y, max_y, stic_y, o_legend=1, xticslabels=None, xticlab_angle_degre=0, y_decimal=None, n_legend_col=None, yticslabels=None):    
    try:        
        params = {'font.size':fond_size, 'lines.linewidth': lines_width, 'legend.fontsize': legend_fond_size}
        plt.rcParams.update(params)
        colors_ = list(six.iteritems(colors.cnames))
        patterns = ['-', 'o', 'x', '*', '\\',  'O', '.', '+']
        
        len_legend = 1
        if legends != None:
            len_legend = len(legends)
        all_xx = []
        for xx in x_datas:
            all_xx += xx
        xxxx = set(all_xx)
        xx_max = list(xxxx)
        xx_max =  sorted(xx_max) 
        max_x = max(xx_max)
        nb_ind = len(x_datas[0])
        
        inds = [float(i) for i in range(nb_ind)]
        inds[0]
        width = 0.8*nb_ind/float(nb_ind*len_legend)
        space = 0.2*nb_ind/float(nb_ind+1)
        #inds[0] += space
        #print inds 

        #inds = [(i+1)*space + i*width for i in range(nb_ind)]
        #print nb_ind, inds

        #wdd = (max_x - (0.1*max_x))/(float(len(x_datas))*float(len(xx_max)))
        #width = wdd
        #print 1, inds
        fig, ax = plt.subplots()
        for i in range(len(x_datas)):
            if y_errors != None:# hatch=patterns[i],fill = False,
                if legends != None:
                    plt.bar([p + i*width for p in inds], y_datas[i], width, color=colors_[i], label=legends[i], edgecolor='black', hatch=patterns[i], yerr=y_errors[i])
                else:
                    plt.bar([p + i*width for p in inds], y_datas[i], width, color=colors_[i], edgecolor='black', hatch=patterns[i], yerr=y_errors[i])
            else:#
                if legends != None:
                    plt.bar([p + i*width for p in inds], y_datas[i], width, color=colors_[i], label=legends[i], edgecolor='black', hatch=patterns[i])
                else:
                    plt.bar([p + i*width for p in inds], y_datas[i], width, color=colors_[i], edgecolor='black', hatch=patterns[i])
                                    
        #print 2
        ax.set_ylabel(ylab)
        ax.set_xlabel(xlab)
        
        xtvec = [p + width*len_legend/2 for p in inds]        
        ax.set_xticks(xtvec)
        if xticslabels != None:
            plt.xticks(xtvec, xticslabels, rotation=xticlab_angle_degre)
        else:
            ax.set_xticklabels(xx_max)            
        
        if yticslabels != None:
            plt.yticks(yticslabels)
        else:
            if stic_y != None:
                vec = np.arange(min_y, max_y, stic_y)
                plt.yticks(vec)
            
        axes = plt.gca()
        axes.set_ylim([min_y, max_y])
        
        if y_decimal != None:
            ax.yaxis.set_major_formatter(FormatStrFormatter('%.' + str(y_decimal) + 'f'))
            
        if legends != None:
            if o_legend == 1:
                if n_legend_col != None:
                    leg = plt.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=n_legend_col, mode="expand", borderaxespad=0., title=legend_title)
                    #leg = plt.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=n_legend_col, mode="expand", borderaxespad=0., title=legend_title)
                else:
                    leg = plt.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=1, mode="expand", borderaxespad=0., title=legend_title)
            elif o_legend == 0:
                if n_legend_col != None:
                    leg = plt.legend(loc=0, ncol=n_legend_col, title=legend_title)
                else:
                    leg = plt.legend(loc=0, ncol=1, title=legend_title)                    
            else:
                leg = plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0., title=legend_title)
                    
            leg.get_frame().set_linewidth(2.0)
            leg.get_frame().set_facecolor('none')
                
        fig.set_size_inches(image_width, image_heigth)
        plt.title(titre, fontsize=12)
                    
        #plt.tight_layout()
        if legends != None:
            plt.savefig(image_fname, bbox_extra_artists=(leg,), bbox_inches='tight')
        else:
            plt.savefig(image_fname, bbox_inches='tight')
            
        plt.close()    
        gc.collect()
    except Exception as inst:
        print type(inst)
        print inst.args        
        print x_datas
        print y_datas
        print y_errors

def PlotSingleTopologieMultipleCurves_AllParams_Two_Axis(x_datas1, y_datas1, y_error1, x_datas2, y_datas2, y_error2, xlab, ylab1, ylab2, titre, image_fname, legends1, legends2, xticInt, yticInt, o_legend, min_x, max_x, stic_x, stic_y1, delta_y1, stic_y2, delta_y2):        
    try:
        params = {'font.size':fond_size, 'lines.linewidth': lines_width, 'legend.fontsize': legend_fond_size}
        plt.rcParams.update(params)
        
        lignes = ['-', '--', '-.', ':']
        s_lignes = len(lignes)
        unfilled_markers = ['s','p','*', 'o','v','+','^', '<','>', 'd', 'D' ,'h','H','x','1','2','3','4','8']
        s_markers = len(unfilled_markers)
        #unfilled_markers = [m for m, func in iteritems(Line2D.markers) if func != 'nothing' and m not in Line2D.filled_markers]
        

        min_y1 = min([np.nanmin(vect) for vect in y_datas1])
        max_y1 = max([np.nanmax(vect) for vect in y_datas1])
        max_y1 += delta_y1
        
        min_y2 = min([np.nanmin(vect) for vect in y_datas2])
        max_y2 = max([np.nanmax(vect) for vect in y_datas2])
        max_y2 += delta_y2
        
        fig = plt.figure()        
        ax1 = fig.add_subplot(111)
                
        ax1.set_xlabel(xlab)        
        if xticInt == 0:
            ax1.xaxis.set_major_formatter(FormatStrFormatter('%.2f'))
        else:
            ax1.xaxis.set_major_formatter(FormatStrFormatter('%d')) 
        
        if yticInt == 0:
            ax1.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
        else:
            ax1.yaxis.set_major_formatter(FormatStrFormatter('%d'))
            
        vec = np.arange(min_x, max_x, stic_x)
        plt.xticks(vec)

        for i in range(len(y_datas1)):
            if y_error1 == None:
                ax1.plot(x_datas1[i], y_datas1[i], label=legends1[i], linestyle=lignes[i%s_lignes], marker=unfilled_markers[i%s_markers], color = 'b')
            else:
                ax1.errorbar(x_datas1[i], y_datas1[i], yerr=y_error1[i], label=legends1[i], linestyle=lignes[0], marker=None, color = 'b')                                
        vec = np.arange(min_y1, max_y1, stic_y1)
        ax1.set_yticks(vec)

        #axes = ax1.gca()
        ax1.set_xlim([min_x, max_x])
        ax1.set_ylim([min_y1, max_y1])
        ax1.set_ylabel(ylab1)
            
        lignes = ['-.', ':']
        ax2 = ax1.twinx()
        for i in range(len(y_datas2)):
            if y_error2 == None:
                ax2.plot(x_datas2[i], y_datas2[i], label=legends2[i], linestyle=lignes[i%s_lignes], marker=unfilled_markers[i%s_markers], color = 'r')
            else:
                ax2.errorbar(x_datas2[i], y_datas2[i], yerr=y_error2[i], label=legends2[i], linestyle=lignes[0], marker=None, color = 'r')                                
        vec = np.arange(min_y2, max_y2, stic_y2)
        ax2.set_yticks(vec)

        ax2.set_ylim([min_y2, max_y2])
        ax2.set_ylabel(ylab2)

        if yticInt == 0:
            ax2.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
        else:
            ax2.yaxis.set_major_formatter(FormatStrFormatter('%d'))
                        
        if o_legend == 1:
            leg = plt.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=2, mode="expand", borderaxespad=0.)
        elif o_legend == 0:
            leg = plt.legend(loc=0, ncol=1)
        else:
            leg = plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
            
        leg.get_title().set_fontsize('18')
            
        leg.get_frame().set_linewidth(2.0)
        fig.set_size_inches(image_width, image_heigth)
        plt.savefig(image_fname, bbox_extra_artists=(leg,), bbox_inches='tight')
        plt.close()    
        gc.collect()
    except Exception as inst:
        print type(inst)
        print inst.args        



def PlotBar_Stacked(x_datas, y_datas, y_errors, xlab, ylab, titre, image_fname, legends, legend_title, min_y, max_y, stic_y, xticslabels=None, xticlab_angle_degre=0):    
    try:
        params = {'font.size':fond_size, 'lines.linewidth': lines_width, 'legend.fontsize': legend_fond_size}
        plt.rcParams.update(params)
        
        colors_ = list(six.iteritems(colors.cnames))
        
        patterns = ['-', 'o', 'x', '*', '\\',  'O', '.', '+']
        width = 5       # the width of the bars
        
        all_xx = []
        for xx in x_datas:
            all_xx += xx
        xxxx = set(all_xx)
        xx_max = list(xxxx)
        xx_max =  sorted(xx_max)       
        max_x = max(xx_max)
        wd = (max_x - (0.1*max_x))/float(len(xx_max))
        width = wd
    
        nb_ind = len(x_datas[0])        
        inds = [float(i) for i in range(nb_ind)]        
        
        fig, ax = plt.subplots()
        for i in range(len(x_datas)):
            bttom = [0.0 for k in range(len(y_datas[i]))]
            if i != 0:
                for k in range(i):
                    for kk in range(len(y_datas[k])):
                        bttom[kk] += y_datas[k][kk]
             
            if y_errors != None:#hatch=patterns[i],fill = False,
                plt.bar(x_datas[i], y_datas[i], width, bottom=bttom, color=colors_[i], label=legends[i], edgecolor='black', hatch=patterns[i], yerr=y_errors[i])
            else:#
                plt.bar(x_datas[i], y_datas[i], width, bottom=bttom, color=colors_[i], label=legends[i], edgecolor='black', hatch=patterns[i])
                #[p + width for p in x_datas[i]]
        ax.set_ylabel(ylab)
        ax.set_xlabel(xlab)
        
        #ax.xaxis.set_major_formatter(FormatStrFormatter('%d'))
        ax.set_xticks([p + width/2 for p in xx_max])
        xxx_int = [x for x in xx_max]
        ax.set_xticklabels(xxx_int)
        
        """
        if xticslabels != None:
            ax.set_xticklabels(xxx_int, xticslabels, rotation=xticlab_angle_degre)
        else:
            ax.set_xticklabels(xxx_int)
        """
        
        vec = np.arange(min_y, max_y, stic_y)
        plt.yticks(vec)
        axes = plt.gca()
        axes.set_ylim([min_y, max_y])
        
        leg = plt.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=2, mode="expand", borderaxespad=0.)
        leg.get_frame().set_linewidth(2.0)
        fig.set_size_inches(image_width, image_heigth)
                    
        #plt.tight_layout()
        plt.savefig(image_fname, bbox_extra_artists=(leg,), bbox_inches='tight')
        plt.close()    
        gc.collect()
    except Exception as inst:
        print type(inst)
        print inst.args        
        print x_datas
        print y_datas
        print y_errors

def PlotBar_Group_Stacked(x_datas, y_datas, y_errors, xlab, ylab, titre, image_fname, legends, legend_title, min_y, max_y, stic_y, legend_pos = 0, xticInt = 1):    
    try:        
        params = {'font.size':fond_size, 'lines.linewidth': lines_width, 'legend.fontsize': legend_fond_size}
        plt.rcParams.update(params)
        
        cc = list(six.iteritems(colors.cnames))
        colors_ = [cc[i:i + len(x_datas[0])] for i in range(0, len(cc), len(x_datas[0]))]
                
        patterns = ['-', 'o', 'x', '*', '<',  'O', '.', '+', '<', '>', '//', '|' , ':', 'q', 'f', 'p', 't', 'm']
        
        all_xx = []
        for xxx in x_datas:
            for xx in xxx:
                all_xx += xx
        xxxx = set(all_xx)
        xx_max = list(xxxx)
        xx_max =  sorted(xx_max)
        max_x = max(xx_max)
        wd = (max_x - (0.1*max_x))/(float(len(x_datas[0]))*float(len(xx_max)))
        width = wd
                
        fig, ax = plt.subplots()
        for stck in range(len(x_datas)):
            for i in range(len(x_datas[stck])):
                bttom = [0.0 for k in range(len(y_datas[stck][i]))]
                if stck != 0:
                    for k in range(stck):
                        for kk in range(len(y_datas[k][i])):
                            bttom[kk] += y_datas[k][i][kk]
                
                if y_errors != None:# hatch=patterns[i],fill = False, colors_[stck][i]
                    plt.bar([p + i*width for p in x_datas[stck][i]], y_datas[stck][i], width, bottom=bttom, color=cc[stck], label=legends[stck][i], edgecolor='black', hatch=patterns[i], yerr=y_errors[stck][i])
                else:#
                    plt.bar([p + i*width for p in x_datas[stck][i]], y_datas[stck][i], width, bottom=bttom, color=cc[stck], label=legends[stck][i], edgecolor='black', hatch=patterns[i])
        ax.set_ylabel(ylab)
        ax.set_xlabel(xlab)
        
        ax.set_xticks([p + width*len(x_datas[0])/2 for p in xx_max])
        if xticInt == 1:
            xtic_lab = [int(x) for x in xx_max]
            ax.xaxis.set_major_formatter(FormatStrFormatter('%d'))
        else:
            xtic_lab = [x for x in xx_max]
            ax.xaxis.set_major_formatter(FormatStrFormatter('%.2f'))
        ax.set_xticklabels(xtic_lab)
             
        
        vec = np.arange(min_y, max_y, stic_y)
        plt.yticks(vec)
        axes = plt.gca()
        axes.set_ylim([min_y, max_y])
        
        if legend_pos == 0:
            leg = plt.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=3, mode="expand", borderaxespad=0.)
        elif legend_pos == 1:
            leg = plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
        
        leg.get_frame().set_linewidth(2.0)
        fig.set_size_inches(image_width, image_heigth)
                    
        #plt.tight_layout()
        plt.savefig(image_fname, bbox_extra_artists=(leg,), bbox_inches='tight')
        plt.close()    
        gc.collect()
    except Exception as inst:
        print type(inst)
        print inst.args        
        print x_datas
        print y_datas
        print y_errors

               
def plot3dHist(nl_dresults, image_fname1, image_fname2):
    try:
        keylist = nl_dresults.keys()
        keylist.sort()
        
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        for nb_deleted_links in keylist:
            values = nl_dresults[nb_deleted_links]
            ll = [v[0] for v in values]
            c = Counter(ll)
            xs = c.keys()
            ys = c.values()
            print nb_deleted_links, xs, ys
            ax.bar(xs, ys, zs=nb_deleted_links, zdir='y', alpha=0.8)            
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')
        
        plt.tight_layout()
        plt.savefig(image_fname1)
        plt.close()    
        gc.collect()


        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        for nb_deleted_links in keylist:
            values = nl_dresults[nb_deleted_links]
            ll = [v[1] for v in values]
            c = Counter(ll)
            xs = c.keys()
            ys = c.values()
            ax.bar(xs, ys, zs=nb_deleted_links, zdir='y', alpha=0.8)            
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')
        
        plt.tight_layout()
        plt.savefig(image_fname2)
        plt.close()
        gc.collect()
                
                    
    except Exception as inst:
        print type(inst)
        print inst.args        
        print nl_dresults
        print image_fname1, image_fname2

def get_color_map(nb_line, nb_column):
    colors = [[None for j in range(nb_column)] for i in range(nb_line)]
    
    for i in range(nb_line):
        for j in range(nb_column):
            r = random.random()
            g = random.random()
            b = random.random()
            colors[i][j] = (r, g, b)
            
    return colors


def plot_box_plot(image_fname, datas, labels, xlab, ylab, titre, min_y=None, max_y=None):
    try:    
        params = {'font.size':fond_size, 'lines.linewidth': lines_width, 'legend.fontsize': legend_fond_size, 'legend.numpoints': 1}
        plt.rcParams.update(params)

        fig, ax = plt.subplots()
        bp = ax.boxplot(datas, 0, 'gD', showmeans = True, patch_artist = True)
                
        ax.get_xaxis().tick_bottom()
        ax.get_yaxis().tick_left()
        
        xtickNames = plt.setp(ax, xticklabels=labels)
            
        plt.setp(xtickNames, rotation=0, fontsize=fond_size)
        
        ax.yaxis.grid(True, linestyle='-', which='major', color='lightgrey', alpha=0.5)
        ax.set_axisbelow(True)
        
        if (min_y != None) and (max_y != None):
            ax.set_ylim([min_y, max_y])
        else:        
            min_y = min([min(yy) for yy in datas])
            max_y = max([max(yy) for yy in datas])        
            add = (max_y - min_y)/10.0        
            ax.set_ylim([min_y-add, max_y+add])

        fig.set_size_inches(image_width, image_heigth)

        ax.set_xlabel(xlab)
        ax.set_ylabel(ylab)
        plt.title(titre, fontsize=fond_size)
        
        ax.legend([bp['medians'][0],bp['means'][0]], ['Median', 'Mean'], loc=0)
        
        plt.savefig(image_fname, bbox_inches='tight')
        plt.close()
        gc.collect()
    except Exception as inst:
        print type(inst)
        print inst.args        
        print datas
        print image_fname
      

def plotSurfaceColored(x_data, y_data, z_values, titre, xlab, ylab, barlab, image_fname, xticInt, yticInt, zticInt = 0):
    try:
        fig, ax = plt.subplots()
        X, Y = np.meshgrid(x_data, y_data)
            
        plt.pcolormesh(X, Y, z_values, cmap = 'RdBu')
        plt.axis([np.nanmin(X), np.nanmax(X), np.nanmin(Y), np.nanmax(Y)])
        
        if xticInt == 0:
            ax.xaxis.set_major_formatter(FormatStrFormatter('%.2f'))
            
        if yticInt == 0:
            ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
                
        if len(x_data)  > 10:
            if xticInt == 0:
                xstep = (np.nanmax(X) - np.nanmin(X))/10.0
            else:
                xstep = math.ceil((np.nanmax(X) - np.nanmin(X))/10.0)
                        
            vec = np.arange(np.nanmin(X), np.nanmax(X), xstep)
            plt.xticks(vec)
        
        if len(y_data) > 10:
            if yticInt == 0:
                ystep = (np.nanmax(Y) - np.nanmin(Y))/10.0
            else:
                ystep = math.ceil((np.nanmax(Y) - np.nanmin(Y))/10.0)
                
            vec = np.arange(np.nanmin(Y), np.nanmax(Y), ystep)
            plt.yticks(vec)
                    
        cbar = plt.colorbar(orientation='horizontal')
        cbar.set_label(barlab)
        if zticInt == 1:
            cbar.ax.xaxis.set_major_formatter(FormatStrFormatter('%d'))
            cbar.ax.yaxis.set_major_formatter(FormatStrFormatter('%d'))
        
                
        plt.xlabel(xlab)
        plt.ylabel(ylab)
        fig.set_size_inches(image_width, image_heigth)
        
        plt.tight_layout()
        plt.savefig(image_fname)
        plt.close()    
        gc.collect()
    except Exception as inst:
        print type(inst)
        print inst.args        
        print x_data
        print y_data
        print z_values   
            
def getMarker(i):
    markers = ['\\alpha', '\\beta', '\gamma', '\sigma','\infty', \
                    '\spadesuit', '\heartsuit', '\diamondsuit', '\clubsuit', \
                    '\\bigodot', '\\bigotimes', '\\bigoplus', '\imath', '\\bowtie', \
                    '\\bigtriangleup', '\\bigtriangledown', '\oslash' \
                   '\ast', '\\times', '\circ', '\\bullet', '\star', '+', \
                    '\Theta', '\Xi', '\Phi', \
                    '\$', '\#', '\%', '\S']
    
    return "$"+markers[i % len(markers)]+"$"

def plotScatterColoredResults(x_scatter_s, y_scatter_s, x_scatter_f, y_scatter_f, titre, xlab, ylab, success_legend, fail_legend, image_fname, outside_legend, min_x, max_x, min_y, max_y, stic_x, stic_y):
    try:
        params = {'font.size':fond_size, 'lines.linewidth': lines_width, 'legend.fontsize': legend_fond_size}

        plt.rcParams.update(params)
        
        fig, ax = plt.subplots()
                
        xstep = math.ceil((np.nanmax(x_scatter_s+x_scatter_f) - np.nanmin(x_scatter_s+x_scatter_f))/10.0)                    
        vec = np.arange(np.nanmin(x_scatter_s+x_scatter_f), np.nanmax(x_scatter_s+x_scatter_f), xstep)
        plt.xticks(vec)
        
        
        ystep = math.ceil((np.nanmax(y_scatter_s+y_scatter_f) - np.nanmin(y_scatter_s+y_scatter_f))/10.0)
            
        vec = np.arange(np.nanmin(y_scatter_s+y_scatter_f), np.nanmax(y_scatter_s+y_scatter_f), ystep)
        plt.yticks(vec)
        #edgecolors='none'
        plt.scatter(x_scatter_s, y_scatter_s, c='black', marker=getMarker(19),label=success_legend, s=72)
        plt.scatter(x_scatter_f, y_scatter_f, c='black', marker=getMarker(14), label=fail_legend, s=42, edgecolors='none')
                
        vec = np.arange(min_x, max_x, stic_x)
        plt.xticks(vec)
        
        vec = np.arange(min_y, max_y, stic_y)
        plt.yticks(vec)

        axes = plt.gca()
        axes.set_xlim([min_x-1, max_x])
        axes.set_ylim([min_y-1, max_y])
        
        if outside_legend == 0:
            leg = plt.legend(loc=0, ncol=1)
        else:
            leg = plt.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=2, mode="expand", borderaxespad=0.)

        leg.get_title().set_fontsize('26')            
        leg.get_frame().set_linewidth(2.0)
        fig.set_size_inches(image_width, image_heigth)
        
        plt.xlabel(xlab)
        plt.ylabel(ylab)
        
        plt.tight_layout()    
        plt.savefig(image_fname, bbox_extra_artists=(leg,), bbox_inches='tight')
        plt.close()    
        gc.collect()
    except Exception as inst:
        print type(inst)
        print inst.args        
        print x_scatter_s, y_scatter_s
        print x_scatter_f, y_scatter_f       


def plotScatter(x_scatter, y_scatter, xlab, ylab, image_fname, titre, min_x, max_x, min_y, max_y, stic_x, stic_y, xticslabels, xticInt, yticInt, x_decimal=2, y_decimal=2, verlabs = None):
    try:
        params = {'font.size':fond_size, 'lines.linewidth': lines_width, 'legend.fontsize': legend_fond_size}

        plt.rcParams.update(params)
        
        fig, ax = plt.subplots()
                
        xstep = math.ceil((np.nanmax(x_scatter) - np.nanmin(x_scatter))/10.0)                    
        vec = np.arange(np.nanmin(x_scatter), np.nanmax(x_scatter), xstep)
        plt.xticks(vec)
        
        
        ystep = math.ceil((np.nanmax(y_scatter) - np.nanmin(y_scatter))/10.0)
            
        vec = np.arange(np.nanmin(y_scatter), np.nanmax(y_scatter), ystep)
        plt.yticks(vec)
        plt.scatter(x_scatter, y_scatter, c='black', marker=getMarker(19), s=72)
                
        vec = np.arange(min_x, max_x, stic_x)
        plt.xticks(vec)
        
        vec = np.arange(min_y, max_y, stic_y)
        plt.yticks(vec)

        if xticslabels != None:
            plt.xticks(xticslabels)            
        elif stic_x != None:
            if xticInt == 0:
                ax.xaxis.set_major_formatter(FormatStrFormatter('%.' + str(x_decimal) + 'f'))
            else:
                ax.xaxis.set_major_formatter(FormatStrFormatter('%d')) 
            
            if stic_x != 0 and min_x != max_x:
                vec = np.arange(min_x, max_x, stic_x)
            else:
                vec = [min_x, max_x]
            plt.xticks(vec)
        else: 
            if xticInt == 0:
                ax.xaxis.set_major_formatter(FormatStrFormatter('%.' + str(x_decimal) + 'f'))
            else:
                ax.xaxis.set_major_formatter(FormatStrFormatter('%d')) 
            
        if stic_y != None:
            if yticInt == 0:
                ax.yaxis.set_major_formatter(FormatStrFormatter('%.' + str(y_decimal) + 'f'))
            else:
                ax.yaxis.set_major_formatter(FormatStrFormatter('%d'))
            if stic_y != 0 and min_x != max_x:
                vec = np.arange(min_y, max_y, stic_y)
            else:
                vec = [min_y, max_y]
            plt.yticks(vec)
        else:
            if yticInt == 0:
                ax.yaxis.set_major_formatter(FormatStrFormatter('%.' + str(y_decimal) + 'f'))
            else:
                ax.yaxis.set_major_formatter(FormatStrFormatter('%d'))

        axes = plt.gca()
        if (min_x != None) and (max_x != None):
            axes.set_xlim([min_x, max_x])
            
        if (min_y != None) and (max_y != None):
            axes.set_ylim([min_y, max_y])
        
        
        if verlabs != None:
            for xp in verlabs:
                plt.axvline(x=xp, color='r', linestyle='-')
            
            plt.text(0.5, 0.5, 'Connected', color = 'r', weight = 'bold')
            plt.text(11, 0.5, 'Transitionnal', color = 'r', weight = 'bold')
            plt.text(22.5, 0.5, 'Disconnected', color = 'r', weight = 'bold')
                
        plt.xlabel(xlab)
        plt.ylabel(ylab)
        
        plt.tight_layout()  
        plt.title(titre, fontsize=12)
        fig.set_size_inches(image_width, image_heigth)
          
        plt.savefig(image_fname, bbox_inches='tight')
        plt.close()    
        gc.collect()
    except Exception as inst:
        print type(inst)
        print inst.args        
        print x_scatter
        print y_scatter       


def Plot_Theoretical_PRR(xx, y_con, y_trans, y_discon, y_no_mark, lab_con, lab_trans, lab_discon, image_fname):        
    try:
        params = {'font.size':fond_size, 'lines.linewidth': lines_width, 'legend.fontsize': legend_fond_size}

        plt.rcParams.update(params)
        fig, ax = plt.subplots()
                
        markevery_val = 0.1
        
        #unfilled_markers = ['<', 's','p','*', 'o','v','+','^', '>', 'd', 'D' ,'h','H','x','1','2','3','4','8']
        
        plt.plot(xx, y_con, label=lab_con, linestyle='-', marker='<', markevery=markevery_val)
        plt.plot(xx, y_trans, label=lab_trans, linestyle=':', marker='*', markevery=markevery_val)
        plt.plot(xx, y_discon, label=lab_discon, linestyle='-.', marker='v', markevery=markevery_val)
                    
        for i in range(0, len(y_no_mark), 7):
            if len(y_no_mark[i]) == len(xx):
                plt.plot(xx, y_no_mark[i], label='', linewidth = 0.2, linestyle='--', marker=None)
            
        vec = np.arange(0, 1.01, 0.1)
        plt.xticks(vec)
        plt.yticks(vec)
        ax.xaxis.set_major_formatter(FormatStrFormatter('%.1f'))
        ax.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))

        axes = plt.gca()
        axes.set_xlim([0.1, 1.02])
        axes.set_ylim([-0.02, 1.02])
        
        leg = plt.legend(loc=0, ncol=1)
        
        leg.get_title().set_fontsize('18')            
        leg.get_frame().set_linewidth(2.0)
        
        fig.set_size_inches(image_width, image_heigth)
        
        plt.xlabel('Packet reception ratio')        
        plt.ylabel('CDF')

        plt.savefig(image_fname, bbox_extra_artists=(leg,), bbox_inches='tight')
                    
        plt.close()    
        gc.collect()
    except Exception as inst:
        print type(inst)
        print inst.args        
        print xx
        print y_con
        print y_trans
        print y_discon
        print y_no_mark     


