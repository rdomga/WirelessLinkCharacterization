import os, shutil#, sys

from Functions import Read_And_Plot as RP
from Functions import Impact_TX_Power as ITP
from Functions import Impact_Ground as IG
from Functions import Impact_Channel as ICH
from Functions import Impact_Message_Size as IMS
from Functions import Impact_Topography as IT

from Functions import Correlation_LinkQuality_Distance as CLD
#base_dir = '/home/domga/Travail/Recherches/ContikiOS_Code/expe1/'

image_rep = 'Images_Paper'
if os.path.exists(image_rep):
    shutil.rmtree(image_rep)        
os.makedirs(image_rep)

"""
(nb_msg, rep, nb_power, exp, channel, nb_pos, distance)
"""
"""
parameters_parse_power = [(200,'Extention/26/1', 8, 1, 26, 6, 1), (200, 'Extention/26/2', 8, 1, 26, 6, 2), \
                          (200, 'Extention/26/3', 8, 1, 26, 6, 3), (200, 'Extention/26/4', 8, 1, 26, 6, 4), \
                          (200, 'Extention/26/5', 8, 1, 26, 6, 5), (200, 'Extention/26/Hauteur/2', 8, 1, 26, 5, 2), \
                          (200, 'Extention/26/Hauteur/3', 8, 1, 26, 5, 3), (200, 'Extention/22/3', 8, 1, 22, 6, 3),\
                           (200, 'Extention/18/3', 8, 1, 18, 6, 3), (200, 'Extention/14/3', 8, 1, 14, 6, 3), \
                           (200, 'Extention/11/3', 8, 1, 11, 6, 3), (200, 'Extention/26/Hauteur/3', 8, 1, 26, 5, 3), \
                           (200, 'Extention/26/Hauteur/2', 8, 1, 26, 5, 2)]
"""
"""
for parameters in parameters_parse_power:
    nb_msg = parameters[0]
    #deploy_dir = base_dir + parameters[1]
    deploy_dir = parameters[1]
    nb_power = parameters[2]
    nb_pos = parameters[5]
    distance = parameters[6]
    
    Exp = parameters[3]
    Channel = parameters[4] 
        
    fname = deploy_dir + '/txpower.data'
    if os.path.isfile(fname) and os.access(fname, os.R_OK):
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            if len(data) != nb_power:
                continue
            TX_Powers_List = [int(p) for p in data]            
        ifile.close()
    
    for tx_power in TX_Powers_List:        
        data_dir = deploy_dir + '/' + str(tx_power) + 'dBm'        
        image_rep = data_dir + '/Images'
        if os.path.exists(image_rep):
            shutil.rmtree(image_rep)        
        os.makedirs(image_rep)
    
    RP.plot_received_messages(deploy_dir, nb_pos, TX_Powers_List, Exp, Channel)
    RP.plot_bidirectional_RSSI_LQI(deploy_dir, nb_pos, TX_Powers_List, Exp, Channel)
    RP.plot_bidirectional_PRR(deploy_dir, nb_pos, TX_Powers_List, Exp, Channel)  
      
    RP.plot_pdf_or_cdf_prr(deploy_dir, nb_pos, TX_Powers_List, distance, Exp, Channel, Distribution='PDF', subdir_prefix='dBm')
    RP.plot_pdf_or_cdf_rssi(deploy_dir, nb_pos, TX_Powers_List, distance, Exp, Channel, Distribution='PDF', subdir_prefix='dBm')
    #RP.plot_pdf_or_cdf_lqi(deploy_dir, nb_pos, TX_Powers_List, distance, Exp, Distribution='PDF', subdir_prefix='dBm')
    
    RP.plot_pdf_or_cdf_prr(deploy_dir, nb_pos, TX_Powers_List, distance, Exp, Channel, Distribution='CDF', subdir_prefix='dBm')
    RP.plot_pdf_or_cdf_rssi(deploy_dir, nb_pos, TX_Powers_List, distance, Exp, Channel, Distribution='CDF', subdir_prefix='dBm')
    #RP.plot_pdf_lqi(deploy_dir, nb_pos, TX_Powers_List, distance, Exp, Channel, Distribution='CDF', subdir_prefix='dBm')
"""

"""
Impact of the transmission power
"""
"""
print "Impact of the transmission power"
prefix = 'dBm'
list_distance = [1, 2, 3, 4, 5]
for dist in list_distance:
    link_len = [dist*i for i in range(1, 6)]
    base_dir = 'Extention/26/' + str(dist)
    image_rep = 'Extention/Impact_TPower/26/' + str(dist)
    if os.path.exists(image_rep):
        shutil.rmtree(image_rep)        
    os.makedirs(image_rep)    
    ITP.plot_curve(base_dir, image_rep, prefix, link_len)
"""
    
"""
(nb_msg, rep, exp, channel, nb_pos, distance)
"""

parameters_parse_msg_size = [(200, 'Extention/26/MSG/2', 1, 26, 5, 2), (200, 'Extention/26/MSG/3', 1, 26, 5, 3), \
                             (400, 'Extention/22/MSG/3', 1, 26, 5, 3), (400, 'Extention/18/MSG/3', 1, 18, 4, 3), \
                             (400, 'Extention/18/MSG/4', 1, 18, 4, 4), (400, 'Extention/14/MSG/3', 1, 18, 4, 3), \
                             (400, 'Extention/14/MSG/4', 1, 18, 4, 4), (400, 'Extention/11/MSG/3', 1, 11, 4, 3), \
                             (400, 'Extention/11/MSG/4', 1, 11, 4, 4), (400, 'Extention/26/Hauteur/MSG/3', 1, 26, 4, 3),\
                              (400, 'Extention/26/Hauteur/MSG/4', 1, 26, 4, 4), (400, 'Extention/26/Hauteur/MSG/5', 1, 26, 4, 5), \
                              (400, 'Extention/26/Hauteur/MSG/6', 1, 26, 4, 6), (400, 'Extention/26/Coline/MSG/3', 1, 26, 4, 3), \
                              (400, 'Extention/26/Coline/MSG/4', 1, 26, 4, 4)]
"""
for parameters in parameters_parse_msg_size:
    nb_msg = parameters[0]
    #deploy_dir = base_dir + parameters[1]
    deploy_dir = parameters[1]
    nb_pos = parameters[4]
    distance = parameters[5]
    
    Exp = parameters[2]
    Channel = parameters[3] 
    
    fname = deploy_dir + '/msg_size.data'
    if os.path.isfile(fname) and os.access(fname, os.R_OK):
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            MSG_SIZE_List = [int(ms) for ms in data]            
        ifile.close()
    
    for message_size in MSG_SIZE_List:        
        data_dir = deploy_dir + '/' + str(message_size)        
        image_rep = data_dir + '/Images'
        if os.path.exists(image_rep):
            shutil.rmtree(image_rep)        
        os.makedirs(image_rep)
        
    RP.plot_received_messages(deploy_dir, nb_pos, MSG_SIZE_List, Exp, Channel)
    RP.plot_bidirectional_RSSI_LQI(deploy_dir, nb_pos, MSG_SIZE_List, Exp, Channel)
    RP.plot_bidirectional_PRR(deploy_dir, nb_pos, MSG_SIZE_List, Exp, Channel)
    
    RP.plot_pdf_or_cdf_prr(deploy_dir, nb_pos, MSG_SIZE_List, distance, Exp, Channel, Distribution='PDF', subdir_prefix='')
    RP.plot_pdf_or_cdf_rssi(deploy_dir, nb_pos, MSG_SIZE_List, distance, Exp, Channel, Distribution='PDF', subdir_prefix='')
    #RP.plot_pdf_or_cdf_lqi(deploy_dir, nb_pos, MSG_SIZE_List, distance, Exp, Channel, Distribution='PDF', subdir_prefix='')
    
    RP.plot_pdf_or_cdf_prr(deploy_dir, nb_pos, MSG_SIZE_List, distance, Exp, Channel, Distribution='CDF', subdir_prefix='')
    RP.plot_pdf_or_cdf_rssi(deploy_dir, nb_pos, MSG_SIZE_List, distance, Exp, Channel, Distribution='CDF', subdir_prefix='')
    #RP.plot_pdf_lqi(deploy_dir, nb_pos, MSG_SIZE_List, distance, Exp, Channel, Distribution='CDF', subdir_prefix='')
"""

"""
Impact of the Ground
"""
print "Impact of the Ground and Channel"
msize_list = [2, 22, 42, 62, 82, 102]
for msize in msize_list:
    image_rep = 'Impact_Ground/26/3/' + str(msize)
    if os.path.exists(image_rep):
        shutil.rmtree(image_rep)        
    os.makedirs(image_rep)
    IG.plot_curve('Extention/26/MSG/3', 'Extention/26/Hauteur/MSG/3', image_rep, msize, '')
    
    image_rep = 'Impact_Channel/3/' + str(msize)
    if os.path.exists(image_rep):
        shutil.rmtree(image_rep)        
    os.makedirs(image_rep)
    ICH.plot_curve('Extention', image_rep, 3, msize, '')
    
"""
Impact of the Message size
"""
print "Impact of the Message size"
list_channel = [11, 14, 18, 22, 26]
for channel in list_channel:
    image_rep = 'Impact_MSize/Ground/' + str(channel) + '/3'
    if os.path.exists(image_rep):
        shutil.rmtree(image_rep)        
    os.makedirs(image_rep)
    IMS.plot_curve('Extention/' + str(channel) + '/MSG/3', image_rep, '')

list_distance = [3, 4, 5, 6]
for dist in list_distance:
    link_len = [dist*i for i in range(1, 4)]
    image_rep = 'Impact_MSize/Heigth/26/' + str(dist)
    if os.path.exists(image_rep):
        shutil.rmtree(image_rep)        
    os.makedirs(image_rep)
    IMS.plot_curve('Extention/26/Hauteur/MSG/' + str(dist), image_rep, '', link_len)
    
list_distance = [3, 4]
for dist in list_distance:
    link_len = [dist*i for i in range(1, 4)]
    image_rep = 'Impact_MSize/Hill/26/' + str(dist)
    if os.path.exists(image_rep):
        shutil.rmtree(image_rep)        
    os.makedirs(image_rep)
    IMS.plot_curve('Extention/26/Coline/MSG/' + str(dist), image_rep, '', link_len)

"""
Impact of the Topography
"""
print "Impact of the Topography"
link_len = [3*i for i in range(1, 5)]    
msize_list = [2, 22, 42, 62, 82, 102]
for msize in msize_list:
    image_rep = 'Impact_Topography/3/' + str(msize)
    if os.path.exists(image_rep):
        shutil.rmtree(image_rep)        
    os.makedirs(image_rep)
    
    IT.plot_curve('Extention/26/MSG/3', 'Extention/26/Coline/MSG/3', image_rep, msize, '', link_len)

"""
Corelation between the link with and the distance
"""
print "Corelation between the link with and the distance"
msize_list = [2, 22, 42, 62, 82, 102]
for msize in msize_list:    
    image_rep = 'Distance_Correlation/' + str(msize)
    if os.path.exists(image_rep):
        shutil.rmtree(image_rep)        
    os.makedirs(image_rep)
    
    list_rep = ['Extention/26/MSG/2/' + str(msize), 'Extention/26/MSG/2/' + str(msize),  'Extention/26/MSG/2/' + str(msize), 'Extention/26/MSG/2_bis', 'Extention/26/MSG/3/' + str(msize)]    
    #print msize
    CLD.plot_curve(list_rep, image_rep)
