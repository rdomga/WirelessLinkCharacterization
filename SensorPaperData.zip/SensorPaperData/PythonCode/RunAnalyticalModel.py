
import os, shutil

from AnalyticalModel import CalAvgRssiAndModelParam as CARP
from AnalyticalModel import AnalyticalModel as ANA
from AnalyticalModel import AnalyticalPlot as AnaPlot
from AnalyticalModel import GenerateAndPlotTheoreticalData as GAP
node_distance = 3
"""
Flat area : Cannal 26
"""
list_msize = [102, 82]
print 'Flat area, channel 26'
for msize in list_msize:
    result = CARP.calc(26, node_distance, msize)
    #print 'message size = ', msize, result
    
    path_lost_expo = result[0]
    sigma = result[1]
    #print "PARAMETRES = ", msize, path_lost_expo, sigma
    
    output_dir = 'Analytical/FLAT_26_3_' + str(msize)
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)        
    os.makedirs(output_dir)
        
    rep_emrirical_data = 'Extention/26/MSG/' + str(node_distance) + '/' + str(msize)    
    ANA.run(msize, sigma, path_lost_expo, output_dir, rep_emrirical_data, node_distance)
        
    AnaPlot.plot_data(output_dir, rep_emrirical_data,  msize, sigma, path_lost_expo)
    
    if (msize == 82) or (msize == 102):
        GAP.generate(30, msize, sigma, path_lost_expo, output_dir)

"""
Flat area, on a chair : Cannal 26
"""
result = CARP.calc(26, node_distance, 82, 'Hauteur')
#print result
print 'Flat area, nodes deployed on a chair, channel 26, message size = 82'

msize = 82
path_lost_expo = result[0]
sigma = result[1]
#print "PARAMETRES = ", msize, path_lost_expo, sigma

output_dir = 'Analytical/FLAT_HEIGTH_26_3_82'
if os.path.exists(output_dir):
    shutil.rmtree(output_dir)        
os.makedirs(output_dir)
rep_emrirical_data = 'Extention/26/Hauteur/MSG/3/82'

ANA.run(msize, sigma, path_lost_expo, output_dir, rep_emrirical_data, node_distance)
AnaPlot.plot_data(output_dir, rep_emrirical_data, msize, sigma, path_lost_expo)        

"""
Hill area, on a chair : Cannal 26
"""
msize = 82
result = CARP.calc(26, node_distance, msize, 'Coline')
#print result
print 'Hill area, channel 26, message size = 82'

path_lost_expo = result[0]
sigma = result[1]
#print "PARAMETRES = ", msize, path_lost_expo, sigma

output_dir = 'Analytical/FLAT_HILL_26_3_' + str(msize)
if os.path.exists(output_dir):
    shutil.rmtree(output_dir)        
os.makedirs(output_dir)
rep_emrirical_data = 'Extention/26/Coline/MSG/3/' + str(msize)

ANA.run(msize, sigma, path_lost_expo, output_dir, rep_emrirical_data, node_distance)
AnaPlot.plot_data(output_dir, rep_emrirical_data, msize, sigma, path_lost_expo)        

msize = 102
result = CARP.calc(26, node_distance, msize, 'Coline')
#print result
print 'Hill area, channel 26, message size = 102'

path_lost_expo = result[0]
sigma = result[1]
#print "PARAMETRES = ", msize, path_lost_expo, sigma

output_dir = 'Analytical/FLAT_HILL_26_3_' + str(msize)
if os.path.exists(output_dir):
    shutil.rmtree(output_dir)        
os.makedirs(output_dir)
rep_emrirical_data = 'Extention/26/Coline/MSG/3/' + str(msize)

ANA.run(msize, sigma, path_lost_expo, output_dir, rep_emrirical_data, node_distance)
AnaPlot.plot_data(output_dir, rep_emrirical_data, msize, sigma, path_lost_expo)        


"""
Flat area : different channel, messahe size 82
"""

"""
msize = 82
list_channel = [11, 14, 18, 22]
print 'Flat area, message size 82'
for channel in list_channel:
    result = CARP.calc(channel, node_distance, msize)
    #print 'Channel = ', channel, result

    path_lost_expo = result[0]
    sigma = result[1]
    print "PARAMETRES = ", msize, path_lost_expo, sigma
    
    output_dir = 'Extention/Analytical/FLAT_' + str(channel) + '_3_' + str(msize)
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)        
    os.makedirs(output_dir)
    rep_emrirical_data = 'Extention/' + str(channel) + '/MSG/' + str(node_distance) + '/' + str(msize)
    
    ANA.run(msize, sigma, path_lost_expo, output_dir, rep_emrirical_data, node_distance)
    AnaPlot.plot_data(output_dir, rep_emrirical_data, msize, sigma, path_lost_expo)        
"""

image_dir = 'Analytical_Validation'
if os.path.exists(image_dir):
    shutil.rmtree(image_dir)        
os.makedirs(image_dir)

msize = 102
AnaPlot.compare_distribution(msize, 'Extention/26', 'Analytical', image_dir)        

msize = 82
AnaPlot.compare_distribution(msize, 'Extention/26', 'Analytical', image_dir)        

    
