

from os import path, access, R_OK

list_rep = []
for rep in list_rep:
    data_dir = rep[0]
    nb_rx = rep[1]
    decalage = rep[2]
    ext = rep[3]
    tx_power = rep[4]
    distance = rep[5]
    nb_msg = [6]
    for n in range(nb_rx): 
        fname = data_dir + '/' + str(n+1+decalage) + ext
        if path.isfile(fname) and access(fname, R_OK):    
            ifile = open(fname, 'r')
            ofile = open(data_dir + '/' + str((n+1+decalage)*distance) + 'm_' + str(tx_power) + 'dBm' + ext, 'w')
            
            for line in ifile:
                data = line.strip('\r\n').split(' ')
                if len(data) != 4:
                    continue
                #lcount = lcount + 1
                #print fname, line
                if int(data[0]) < nb_msg:
                    ofile[index].write(line)                        
        