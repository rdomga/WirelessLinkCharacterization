
import os, shutil

from Functions import Parse_File_Power as PFPower
from Functions import Parse_File_MSG_Size as PFMSize
from Functions import Read_And_Plot as RP

nb_msg_prr=20
interval_l_prr_distrib=0.1
"""
(nb_msg, rep, nb_power, exp, channel, nb_pos, distance)
"""
parameters_parse_power = [(200,'Extention/26/1', 8, 1, 26, 6, 1), (200, 'Extention/26/2', 8, 1, 26, 6, 2), \
                          (200, 'Extention/26/3', 8, 1, 26, 6, 3), (200, 'Extention/26/4', 8, 1, 26, 6, 4), \
                          (200, 'Extention/26/5', 8, 1, 26, 6, 5), (200, 'Extention/26/Hauteur/2', 8, 1, 26, 5, 2), \
                          (200, 'Extention/26/Hauteur/3', 8, 1, 26, 5, 3), (200, 'Extention/22/3', 8, 1, 22, 6, 3),\
                           (200, 'Extention/18/3', 8, 1, 18, 6, 3), (200, 'Extention/14/3', 8, 1, 14, 6, 3), \
                           (200, 'Extention/11/3', 8, 1, 11, 6, 3), (200, 'Extention/26/Hauteur/3', 8, 1, 26, 5, 3), \
                           (200, 'Extention/26/Hauteur/2', 8, 1, 26, 5, 2)]

for parameters in parameters_parse_power:
    nb_msg = parameters[0]
    deploy_dir = parameters[1]
    nb_power = parameters[2]
    nb_pos = parameters[5]
    distance = parameters[6]
    
    Exp = parameters[3]
    Channel = parameters[4] 
    
    PFPower.parse(deploy_dir, nb_pos, distance, nb_msg_prr, nb_msg, nb_power, interval_l_prr_distrib)
    
    fname = deploy_dir + '/txpower.data'
    if os.path.isfile(fname) and os.access(fname, os.R_OK):
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            if len(data) != nb_power:
                continue
            TX_Powers_List = [int(p) for p in data]            
        ifile.close()
    
    for tx_power in TX_Powers_List:        
        data_dir = deploy_dir + '/' + str(tx_power) + 'dBm'        
        image_rep = data_dir + '/Images'
        if os.path.exists(image_rep):
            shutil.rmtree(image_rep)        
        os.makedirs(image_rep)
    
    RP.plot_received_messages(deploy_dir, nb_pos, TX_Powers_List, Exp, Channel)
    RP.plot_bidirectional_RSSI_LQI(deploy_dir, nb_pos, TX_Powers_List, Exp, Channel)
    #RP.plot_distrib(deploy_dir, nb_pos, TX_Powers_List, distance)
    
        
"""
(nb_msg, rep, exp, channel, nb_pos, distance)
"""
parameters_parse_msg_size = [(200, 'Extention/26/MSG/2', 1, 26, 5, 2), (200, 'Extention/26/MSG/3', 1, 26, 5, 3), \
                             (400, 'Extention/22/MSG/3', 1, 26, 5, 3), (400, 'Extention/18/MSG/3', 1, 18, 4, 3), \
                             (400, 'Extention/18/MSG/4', 1, 18, 4, 4), (400, 'Extention/14/MSG/3', 1, 18, 4, 3), \
                             (400, 'Extention/14/MSG/4', 1, 18, 4, 4), (400, 'Extention/11/MSG/3', 1, 11, 4, 3), \
                             (400, 'Extention/11/MSG/4', 1, 11, 4, 4), (400, 'Extention/26/Hauteur/MSG/3', 1, 26, 4, 3),\
                              (400, 'Extention/26/Hauteur/MSG/4', 1, 26, 4, 4), (400, 'Extention/26/Hauteur/MSG/5', 1, 26, 4, 5), \
                              (400, 'Extention/26/Hauteur/MSG/6', 1, 26, 4, 6), (400, 'Extention/26/Coline/MSG/3', 1, 26, 4, 3), \
                              (400, 'Extention/26/Coline/MSG/4', 1, 26, 4, 4)]

for parameters in parameters_parse_msg_size:
    nb_msg = parameters[0]
    deploy_dir = parameters[1]
    nb_pos = parameters[4]
    distance = parameters[5]
    
    Exp = parameters[2]
    Channel = parameters[3] 
    PFMSize.parse(deploy_dir, nb_pos, distance, nb_msg_prr, nb_msg, interval_l_prr_distrib)
    
    fname = deploy_dir + '/msg_size.data'
    if os.path.isfile(fname) and os.access(fname, os.R_OK):
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            MSG_SIZE_List = [int(ms) for ms in data]            
        ifile.close()
    
    for message_size in MSG_SIZE_List:        
        data_dir = deploy_dir + '/' + str(message_size)        
        image_rep = data_dir + '/Images'
        if os.path.exists(image_rep):
            shutil.rmtree(image_rep)        
        os.makedirs(image_rep)
    RP.plot_received_messages(deploy_dir, nb_pos, MSG_SIZE_List, Exp, Channel)
    RP.plot_bidirectional_RSSI_LQI(deploy_dir, nb_pos, MSG_SIZE_List, Exp, Channel)
    #RP.plot_distrib(deploy_dir, nb_pos, MSG_SIZE_List, distance)
    