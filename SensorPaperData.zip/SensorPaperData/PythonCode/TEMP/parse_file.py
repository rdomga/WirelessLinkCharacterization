
import sys, os
     
def add_prr(prr_list, distance, prr):
    for vv in prr_list:
        if vv[0] == distance:
            vv[1].append(prr)
            return
    prr_list.append((distance, [prr]))

def add_rssi(rssi_list, distance, rssi):
    for vv in rssi_list:
        if vv[0] == distance:
            vv[1].append(rssi)
            return
    rssi_list.append((distance, [rssi]))

def add_lqi(lqi_list, distance, lqi):
    for vv in lqi_list:
        if vv[0] == distance:
            vv[1].append(lqi)
            return
    lqi_list.append((distance, [lqi]))
    
def get_indice_puissance(puissance, nb_puissance):
    if nb_puissance == 1:
        return 0
    elif nb_puissance == 2:
        if puissance == 0:
            return 0
        else: 
            return 1
    elif nb_puissance == 8:
        if puissance == 0:
            return 0
        elif puissance == -1:
            return 1
        elif puissance == -3:
            return 2
        elif puissance == -5:
            return 3
        elif puissance == -7:
            return 4
        elif puissance == -10:
            return 5
        elif puissance == -15:
            return 6
        elif puissance == -25:
            return 7
            
if __name__ == "__main__":
    deploy_dir = sys.argv[1] #Dans quel repertoire sont stockes les fichiers    
    nb_pos = int(sys.argv[2]) #Dans le cas ou les donnees sont stockees dans chaque capteur, indique le nombre de fichier dans le repertoire d'origine
    distance = int(sys.argv[3]) #Distance entre capteurs
    nb_msg_prr = int(sys.argv[4]) #Nombre de point sur lequel on doit calculer le PRR (20 par exemple)
    nb_msg = int(sys.argv[5]) #Nombre de message envoyer par cycle
    nb_puissance = int(sys.argv[6]) #Nombre de niveau de puissance utilise
    interval_l = float(sys.argv[7]) #Pour le calcul de la distribution du PRR, on fait une repartition par intervalle dans l'intervalle [0,1]. Ceci est donc la longeur de l'intervalle, par exemple 0.01 ou encore 0.05

    txpower = []
    stat = []
    rx_msg = []
    for n in range(nb_pos):
        fname = deploy_dir + '/' + str(n+1) + '.data'
        
        if os.path.isfile(fname) and os.access(fname, os.R_OK):    
            ifile = open(fname, 'r')
            for line in ifile:
                data = line.strip('\r\n').split(' ')
                if len(data) != 6:
                    continue
                if not (int(data[5]) <= 0 and int(data[5]) >= -25):
                    continue
                    
                if int(data[5]) in txpower:
                    p_index = txpower.index(int(data[5]))
                    stat[p_index][int(data[0])-1][int(data[2])-1].append((int(data[1]), int(data[3]), int(data[4])))
                    rx_msg[p_index][int(data[2])-1].append((int(data[1]), int(data[0])))
                    
                else:
                    txpower.append(int(data[5]))

                    node = [[[] for j in range(nb_pos)] for i in range(nb_pos)]
                    node[int(data[0])-1][int(data[2])-1].append((int(data[1]), int(data[3]), int(data[4])))
                    stat.append(node)
                    
                    rx_node = [[] for i in range(nb_pos)]
                    rx_node[int(data[2])-1].append((int(data[1]), int(data[0])))
                    rx_msg.append(rx_node)
    #print txpower
    for p_i in range(len(txpower)):
        dirname = deploy_dir + '/' + str(txpower[p_i]) + 'dBm'
        if not os.path.exists(dirname):
            os.makedirs(dirname)
        
        all_prr = []
        all_rssi = []
        all_lqi = []

        all_link_prr = []
        all_link_rssi = []
        all_link_lqi = []

        fdistrib_prr = open(dirname + '/ALL_DISTRIB_PRR.data', 'w')
        fdistrib_rssi = open(dirname + '/ALL_DISTRIB_RSSI.data', 'w')
        fdistrib_lqi = open(dirname + '/ALL_DISTRIB_LQI.data', 'w')
        prr_def_file = open(dirname + '/PRR_DEF.data', 'w')
        prr_def_file.write("'TYPE' 'NO LINK' 'POOR' 'INTERMEDIATE' 'GOOD' 'PERFECT'\n")
                
        for tx in range(nb_pos):
            for rx in range(nb_pos):
                if rx == tx:
                    continue
                if len(stat[p_i][tx][rx]) > 0:
                    index = 0
                    nb_msg_rcv = 0
                    prr_point = 0
                    temps = 0.0
                    avg_rssi = 0.0
                    fmsg = open(dirname + '/MSG_' + str(tx+1) + '_' + str(rx+1) + '.data', 'w')
                    fmsgb = open(dirname + '/MSGBIS_' + str(tx+1) + '_' + str(rx+1) + '.data', 'w')
                    fprr = open(dirname + '/PRR_' + str(tx+1) + '_' + str(rx+1) + '.data', 'w')
                    favg_rssi = open(dirname + '/AGV_RSSI_' + str(tx+1) + '_' + str(rx+1) + '.data', 'w')
                     
                    for m in stat[p_i][tx][rx]:
                        add_rssi(all_rssi, abs(tx-rx)*distance, m[1])
                        add_lqi(all_lqi, abs(tx-rx)*distance, m[2])
                        
                        all_link_rssi.append(m[1])
                        all_link_lqi.append(m[2])                        
                        
                        seq = int(m[0])                        
                        while index < seq:
                            fmsg.write(str(temps) + ' ' + str(index) + ' ' + str(seq) + ' ' + str(m[0]) + ' ? ?\n')
                            index += 1
                            temps += 0.4
                            
                            if index % nb_msg_prr == 0:
                                add_prr(all_prr, abs(tx-rx)*distance, float(nb_msg_rcv)/float(nb_msg_prr))
                                all_link_prr.append(float(nb_msg_rcv)/float(nb_msg_prr))
                                
                                fprr.write(str((prr_point+1)*8) + ' ' + str(float(nb_msg_rcv)/float(nb_msg_prr)) +'\n')
                                
                                if nb_msg_rcv != 0:
                                	favg_rssi.write(str((prr_point+1)*8) + ' ' + str(float(avg_rssi)/float(nb_msg_rcv)) +'\n')
                                else:
                                	favg_rssi.write(str((prr_point+1)*8) + ' ?\n')
																	
                                
                                nb_msg_rcv = 0
                                prr_point += 1
                                avg_rssi = 0.0
                                                                
                        fmsg.write(str(temps) + ' ' + str(seq) + ' ' + str(seq) + ' ' + str(m[0]) +  ' ' + str(m[1])+ ' ' + str(m[2]) + '\n')
                        temps += 0.4
                        index += 1
                        nb_msg_rcv += 1
                        avg_rssi += m[1]
                        
                        if index % nb_msg_prr == 0:
                            add_prr(all_prr, abs(tx-rx)*distance, float(nb_msg_rcv)/float(nb_msg_prr))
                            all_link_prr.append(float(nb_msg_rcv)/float(nb_msg_prr))
                            
                            fprr.write(str((prr_point+1)*8) + ' ' + str(float(nb_msg_rcv)/float(nb_msg_prr)) +'\n')
                            if nb_msg_rcv != 0:
                            	favg_rssi.write(str((prr_point+1)*8) + ' ' + str(float(avg_rssi)/float(nb_msg_rcv)) +'\n')
                            else:
                            	favg_rssi.write(str((prr_point+1)*8) + ' ?\n')
							
                            
                            nb_msg_rcv = 0
                            prr_point += 1
                            avg_rssi = 0.0
                                                                    
                    while index < nb_msg:
                        fmsg.write(str(temps) + ' ' + str(index) + ' ' + str(seq) + ' ' + str(m[0]) + ' ? ?\n')
                        index += 1
                        temps += 0.4
                    
                        if index % nb_msg_prr == 0:
                            add_prr(all_prr, abs(tx-rx)*distance, float(nb_msg_rcv)/float(nb_msg_prr))
                            all_link_prr.append(float(nb_msg_rcv)/float(nb_msg_prr))
                            
                            fprr.write(str((prr_point+1)*8) + ' ' + str(float(nb_msg_rcv)/float(nb_msg_prr)) +'\n')
                            
                            if nb_msg_rcv != 0:
                            	favg_rssi.write(str((prr_point+1)*8) + ' ' + str(float(avg_rssi)/float(nb_msg_rcv)) +'\n')
                            else:
                            	favg_rssi.write(str((prr_point+1)*8) + ' ?\n')
							
                            
                            nb_msg_rcv = 0
                            prr_point += 1
                            avg_rssi = 0.0
                                                                   
                    fmsg.close()
                    fmsgb.close()
                    fprr.close()
                    favg_rssi.close()
        
        for rx in range(nb_pos):
            fmsg = open(dirname + '/MSG_' + str(rx + 1) + '.data', 'w')
            index = 0
            for m in rx_msg[p_i][rx]:
                fmsg.write(str(index) + ' ' + str(m[0]) + ' ' + str(m[1]) + '\n')
                index += 1
            fmsg.close()

        count = int(1.0/interval_l)
        for prrs in all_prr:
            proba = [0 for k in range(count)]
            link_def = [0, 0, 0, 0, 0]
            
            for prr in prrs[1]:
                for k in range(count - 1):
                    if ((prr >= float(k*interval_l)) and (prr < float((k+1)*interval_l))):
                        proba[k] = proba[k] + 1
                                            
                if ((prr >= float((count-1)*interval_l)) and (prr <= float(count*interval_l))):
                    proba[count-1] = proba[count-1] + 1
                
                if (prr == 0):
                	link_def[0] += 1                
                if (prr > 0) and (prr <= 0.1):
                	link_def[1] += 1
                elif (prr > 0.1) and (prr < 0.9):
                	link_def[2] += 1                
                elif (prr >= 0.9) and (prr < 1.0):
                	link_def[3] += 1
                elif (prr == 1.0):
                	link_def[4] += 1
                	
            #Save PRR definition
            prr_def_file.write(str(prrs[0]) + 'M ' + ' '.join([str(float(c)*100.0/float(len(prrs[1]))) for c in link_def]) + '\n')
            
            ofile = open(dirname + '/Distrib_PRR_' + str(prrs[0]) + 'M.data', 'w')
            cdf_ofile = open(dirname + '/CDF_Distrib_PRR_' + str(prrs[0]) + 'M.data', 'w')
            #s_proba = 0.0
            for k in range(count):
                ofile.write(str((k+1)*interval_l) + ' ' + str(float(proba[k])/float(len(prrs[1]))) + '\n')
                cdf_ofile.write(str((k+1)*interval_l) + ' ' + str(float(sum(proba[:(k+1)]))/float(len(prrs[1]))) + '\n')
                #s_proba += float(proba[k])/float(len(prrs[1]))
            ofile.close()
            cdf_ofile.close()
            #print s_proba
            
        for prrs in all_prr:
            for prr in prrs[1]: 
                fdistrib_prr.write(str(prrs[0]) + ' ' + str(prr) + '\n')

        for rssis in all_rssi:
            for rssi in rssis[1]: 
                fdistrib_rssi.write(str(rssis[0]) + ' ' + str(rssi) + '\n')

        for lqis in all_lqi:
            for lqi in lqis[1]: 
                fdistrib_lqi.write(str(lqis[0]) + ' ' + str(lqi) + '\n')


        #PRR distribution for all links
        proba = [0 for k in range(count)]
        link_def = [0, 0, 0, 0, 0]       
        for prr in all_link_prr:
            for k in range(count - 1):
                if ((prr >= float(k*interval_l)) and (prr < float((k+1)*interval_l))):
                    proba[k] = proba[k] + 1
                                        
            if ((prr >= float((count-1)*interval_l)) and (prr <= float(count*interval_l))):
                proba[count-1] = proba[count-1] + 1
                
            if (prr == 0):
            	link_def[0] += 1                
            if (prr > 0) and (prr <= 0.1):
            	link_def[1] += 1
            elif (prr > 0.1) and (prr < 0.9):
            	link_def[2] += 1                
            elif (prr >= 0.9) and (prr < 1.0):
            	link_def[3] += 1
            elif (prr == 1.0):
            	link_def[4] += 1
            	
        #Save PRR definition
        prr_def_file.write('ALL_LINKS '+ ' '.join([str(float(c)*100.0/float(len(all_link_prr))) for c in link_def]) + '\n')
        prr_def_file.close()
        
        ofile = open(dirname + '/Distrib_PRR_ALL_LINKS.data', 'w')
        cdf_ofile = open(dirname + '/CDF_Distrib_PRR_ALL_LINKS.data', 'w')
        s_proba = 0.0
        for k in range(count):
            ofile.write(str((k+1)*interval_l) + ' ' + str(float(proba[k])/float(len(all_link_prr))) + '\n')
            cdf_ofile.write(str((k+1)*interval_l) + ' ' + str(float(sum(proba[:(k+1)]))/float(len(all_link_prr))) + '\n')
            s_proba += float(proba[k])/float(len(all_link_prr))
        ofile.close()
        cdf_ofile.close()
        print s_proba
        
        for rssis in all_rssi:
            proba = []
            for rssi in rssis[1]:
                found = False
                for k in range(len(proba)):                    
                    if proba[k][0] == rssi:
                        v = (rssi, proba[k][1] + 1)
                        proba[k] = v
                        found = True
                        break
                if not found:
                    proba.append((rssi, 1))
            sort_proba = sorted(proba, key=lambda x: x[0])
            s_proba = 0.0            
            ofile = open(dirname + '/Distrib_RSSI_' + str(rssis[0]) + 'M.data', 'w')
            cdf_ofile = open(dirname + '/CDF_Distrib_RSSI_' + str(rssis[0]) + 'M.data', 'w')
            for k in range(len(sort_proba)):
                pr = float(sort_proba[k][1])/float(len(rssis[1]))
                pr_cdf = sum([sort_proba[i][1] for i in range(k+1)])
                s_proba += pr
                ofile.write(str(sort_proba[k][0]) + ' ' + str(float(sort_proba[k][1])/float(len(rssis[1]))) + '\n')
                cdf_ofile.write(str(sort_proba[k][0]) + ' ' + str(float(pr_cdf)/float(len(rssis[1]))) + '\n')
            ofile.close()
            cdf_ofile.close()
            #print s_proba

        for lqis in all_lqi:
            proba = []
            for lqi in lqis[1]:
                found = False
                for k in range(len(proba)):
                    if proba[k][0] == lqi:
                        v = (lqi, proba[k][1] + 1)
                        proba[k] = v 
                        found = True
                        break
                if not found:
                    proba.append((lqi, 1))
            sort_proba = sorted(proba, key=lambda x: x[0])
            s_proba = 0.0
            ofile = open(dirname + '/Distri_LQI_' + str(lqis[0]) + 'M.data', 'w')
            for k in range(len(sort_proba)):
                pr = float(sort_proba[k][1])/float(len(lqis[1]))
                s_proba += pr
                ofile.write(str(sort_proba[k][0]) + ' ' + str(pr) + '\n')
            ofile.close()
            #print s_proba

        #RSSI distribution for all links
        proba = []        
        for rssi in all_link_rssi:
            found = False        
            for k in range(len(proba)):                    
                if proba[k][0] == rssi:
                    v = (rssi, proba[k][1] + 1)
                    proba[k] = v
                    found = True
                    break
            if not found:
                proba.append((rssi, 1))

        sort_proba = sorted(proba, key=lambda x: x[0])
        s_proba = 0.0            
        ofile = open(dirname + '/Distrib_RSSI_ALL_LINKS.data', 'w')
        cdf_ofile = open(dirname + '/CDF_Distrib_RSSI_ALL_LINKS.data', 'w')
        for k in range(len(sort_proba)):
            pr = float(sort_proba[k][1])/float(len(all_link_rssi))
            pr_cdf = sum([sort_proba[i][1] for i in range(k+1)])
            pr_cdf = float(pr_cdf)/float(len(all_link_rssi))
            
            s_proba += pr
            ofile.write(str(sort_proba[k][0]) + ' ' + str(pr) + '\n')
            cdf_ofile.write(str(sort_proba[k][0]) + ' ' + str(pr_cdf) + '\n')
        ofile.close()
        cdf_ofile.close()
        print s_proba
        
        fdistrib_prr.close()
        fdistrib_rssi.close()
        fdistrib_lqi.close()
            
    fmsg = open(deploy_dir + '/txpower.data', 'w')                  
    fmsg.write(' '.join([str(x) for x in txpower]))    
    fmsg.close()
        
                        
        
                                
