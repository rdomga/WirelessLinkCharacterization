import sys, os

def add_pdf_vall(list_val, val):
	index = 0
	for vv in list_val:
		if vv[0] == val:
			xx = (val, vv[1]+1)
			list_val[index] = xx
			return
		index += 1
	list_val.append((val, 1))

def calc_cdf(data, D, directory):
	nb_val = len(data)
	sorted_data = sorted(data, key=lambda x: x[0])
	total = sum([sorted_data[i][1] for i in range(nb_val)])
	cdf_ofile = open(directory + '/CDF_ASS_' + D + '.data', 'w')
	for k in range(nb_val):
		pr_cdf = sum([sorted_data[i][1] for i in range(k+1)])
		cdf_ofile.write(str(sorted_data[k][0]) + ' ' + str(float(pr_cdf)/float(total)) + '\n')
	cdf_ofile.close()
	
if __name__ == "__main__":
    rep = sys.argv[1] #Data directory
    nb_nodes = int(sys.argv[2]) #nombre de capteur
    
    Links_Assymetric_ALL_PRR = []
    Links_Assymetric_ALL_RSSI = []
    
    nb_unidirectional = 0
    nb_links = 0
    
    for a in range(nb_nodes-1):
        for b in range(a+1, nb_nodes):
            prr_ab = []
            fname = rep + '/PRR_' + str(a+1) + '_' + str(b+1) + '.data'
            if os.path.isfile(fname) and os.access(fname, os.R_OK):
				ifile = open(fname, 'r')
				for line in ifile:
					data = line.strip('\r\n').split(' ')
					if len(data) != 2:
						continue
					prr_ab.append(float(data[1]))			
				ifile.close()
            prr_ba = []
            fname = rep + '/PRR_' + str(b+1) + '_' + str(a+1) + '.data'
            if os.path.isfile(fname) and os.access(fname, os.R_OK):
				ifile = open(fname, 'r')
				for line in ifile:
					data = line.strip('\r\n').split(' ')
					if len(data) != 2:
						continue
					prr_ba.append(float(data[1]))			
				ifile.close()
            if len(prr_ab) == len(prr_ba):
				for i in range(len(prr_ab)):
					add_pdf_vall(Links_Assymetric_ALL_PRR, abs(prr_ab[i]-prr_ba[i]))
            rssi_ab = []
            fname = rep + '/AGV_RSSI_' + str(a+1) + '_' + str(b+1) + '.data'
            if os.path.isfile(fname) and os.access(fname, os.R_OK):
                ifile = open(fname, 'r')
                for line in ifile:
                    data = line.strip('\r\n').split(' ')
                    if len(data) != 2:
						continue
                    rssi_ab.append(data[1])
                ifile.close()
            rssi_ba = []
            fname = rep + '/AGV_RSSI_' + str(b+1) + '_' + str(a+1) + '.data'
            if os.path.isfile(fname) and os.access(fname, os.R_OK):
                ifile = open(fname, 'r')
                for line in ifile:
                    data = line.strip('\r\n').split(' ')
                    if len(data) != 2:
                        continue
                    rssi_ba.append(data[1])
                ifile.close()
            else:
                print 'fichier inexistant'
			
            if len(rssi_ab) == len(rssi_ba):
                for i in range(len(rssi_ab)):
                    nb_links += 1
                    if rssi_ab[i] != '?' and rssi_ba[i] != '?':
						add_pdf_vall(Links_Assymetric_ALL_RSSI, abs(float(rssi_ab[i])-float(rssi_ba[i])))
                    else:
						nb_unidirectional += 1
							
	calc_cdf(Links_Assymetric_ALL_PRR, 'PRR', rep)
	calc_cdf(Links_Assymetric_ALL_RSSI, 'RSSI', rep)
	
	ofile = open(rep + '/ASSY_STAT_DATA.data', 'w')
	ofile.write('DATA AVG MAX\n')	
	sorted_data = sorted(Links_Assymetric_ALL_PRR, key=lambda x: x[0])
	avg_prr = sum([sorted_data[i][1]*sorted_data[i][0] for i in range(len(Links_Assymetric_ALL_PRR))])/sum([sorted_data[i][1] for i in range(len(Links_Assymetric_ALL_PRR))])
	max_prr = sorted_data[len(Links_Assymetric_ALL_PRR)-1][0]
	ofile.write('PRR ' + str(avg_prr) + ' ' + str(max_prr) + '\n')
	

	sorted_data = sorted(Links_Assymetric_ALL_RSSI, key=lambda x: x[0])
	avg_rssi = sum([sorted_data[i][1]*sorted_data[i][0] for i in range(len(Links_Assymetric_ALL_RSSI))])/sum([sorted_data[i][1] for i in range(len(Links_Assymetric_ALL_RSSI))])
	max_rssi = sorted_data[len(Links_Assymetric_ALL_RSSI)-1][0]
	ofile.write('RSSI ' + str(avg_rssi) + ' ' + str(max_rssi) + '\n')
	ofile.write('UNIDIRECTIONAL ' + str(nb_unidirectional) + '\n')
    ofile.write('TOTAL ' + str(nb_links) + '\n')
    if nb_links != 0:
        ofile.write('%UNIDIRECTIONAL ' + str(float(nb_unidirectional)*100.0/float(nb_links)) + '\n')
    else:
        ofile.write('%UNIDIRECTIONAL ' + str(0) + '\n')
	
	ofile.close()
	
	
	
				
				
				
