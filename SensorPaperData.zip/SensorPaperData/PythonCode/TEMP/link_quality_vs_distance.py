
import sys, os, copy

def add_prr(prr_list, distance, prr):
    for vv in prr_list:
        if vv[0] == distance:
            vv[1].append(prr)
            return
    prr_list.append((distance, [prr]))

def add_rssi(rssi_list, distance, rssi):
    for vv in rssi_list:
        if vv[0] == distance:
            vv[1].append(rssi)
            return
    rssi_list.append((distance, [rssi]))
                
if __name__ == "__main__":
    
	nb_rep = len(sys.argv) - 1 #Nombre de repertoires
	interval_l = float(sys.argv[nb_rep]) #Pour le calcul de la distribution du PRR, on fait une repartition par intervalle dans l'intervalle [0,1]. Ceci est donc la longeur de l'intervalle, par exemple 0.01 ou encore 0.05
	
	o_rep = sys.argv[nb_rep-1] #Output directory
	
	all_prr = []
	all_rssi = []
	for rep in range(nb_rep-2):
		fname = sys.argv[rep+1] + '/ALL_DISTRIB_PRR.data'
		if os.path.isfile(fname) and os.access(fname, os.R_OK):    
			ifile = open(fname, 'r')
			for line in ifile:
				data = line.strip('\r\n').split(' ')
				if len(data) != 2:
					continue
				add_prr(all_prr, int(data[0]), float(data[1]))
			
			ifile.close()
				
		fname = sys.argv[rep+1] + '/ALL_DISTRIB_RSSI.data'
		if os.path.isfile(fname) and os.access(fname, os.R_OK):
			ifile = open(fname, 'r')
			for line in ifile:
				data = line.strip('\r\n').split(' ')
				if len(data) != 2:
					continue
				add_rssi(all_rssi, int(data[0]), int(data[1]))
				#print int(data[0]), int(data[1])
			ifile.close()
			
		#vv = input("press ton continue")
	
	"""
	Prepare data for Candlesticks plot
	
	For each metrics, i want to have : Distance -- Min -- FirstQuantile -- SecondQuantile -- Max -- Mediane
	If n is the number of element
		First Quantile index = n/4
		Second Quantile index = 3*n/4
		If n%2 == 0 Then { m = n/2; Mediane_value = (tab[m] + tab[m-1])/2 }
		else {Mediane = Tab[m];}	
	"""
	
	#Data for PRR
	ofile = open(o_rep + '/STAT_PRR.data', 'w')
	copy_all_prr = copy.deepcopy(all_prr)
	s_copy_all_prr = sorted(copy_all_prr, key=lambda prr_distance: prr_distance[0])
	for prrs in s_copy_all_prr:
		#prrs[0] est la distance, prrs[1] est la liste des PRR a cette distance la
		prr_list = copy.deepcopy(prrs[1])
		sorted_prr_list = sorted(prr_list)
		N = len(sorted_prr_list)
		min_prr = sorted_prr_list[0] 
		max_prr = sorted_prr_list[N-1]
		i1 = int(N/4)
		i2 = int(N*3/4)
		fst_qt = sorted_prr_list[i1]
		snd_qt = sorted_prr_list[i2]
		m = int(N/2)
		if N%2 == 0:
			mediane = (sorted_prr_list[m] + sorted_prr_list[m-1])/2.0
		else:
			mediane = sorted_prr_list[m]
		avg = float(sum(sorted_prr_list))/float(N)
		ofile.write(str(prrs[0])+' ' + str(min_prr) + ' ' + str(fst_qt) + ' ' + str(snd_qt) + ' ' + str(max_prr) + ' ' + str(mediane) + ' ' + str(avg) + '\n')		
	ofile.close()
	 

	#Data for RSSI
	ofile = open(o_rep + '/STAT_RSSI.data', 'w')
	copy_all_rssi = copy.deepcopy(all_rssi)
	s_copy_all_rssi = sorted(copy_all_rssi, key=lambda rssi_distance: rssi_distance[0])
	for rssis in s_copy_all_rssi:
		rssi_list = copy.deepcopy(rssis[1])
		sorted_rssi_list = sorted(rssi_list)
		N = len(sorted_rssi_list)
		min_rssi = sorted_rssi_list[0] 
		max_rssi = sorted_rssi_list[N-1]
		i1 = int(N/4)
		i2 = int(N*3/4)
		fst_qt = sorted_rssi_list[i1]
		snd_qt = sorted_rssi_list[i2]
		m = int(N/2)
		if N%2 == 0:
			mediane = (sorted_rssi_list[m] + sorted_rssi_list[m-1])/2.0
		else:
			mediane = sorted_rssi_list[m]
		avg = float(sum(sorted_rssi_list))/float(N)
		ofile.write(str(rssis[0])+' ' + str(min_rssi) + ' ' + str(fst_qt) + ' ' + str(snd_qt) + ' ' + str(max_rssi) + ' ' + str(mediane) + ' ' + str(avg) + '\n')		
	ofile.close()
	
			
	count = int(1.0/interval_l)
	for prrs in all_prr:
		proba = [0 for k in range(count)]
		for prr in prrs[1]:
			for k in range(count - 1):
				if ((prr >= float(k*interval_l)) and (prr < float((k+1)*interval_l))):
					proba[k] = proba[k] + 1
					
			if ((prr >= float((count-1)*interval_l)) and (prr <= float(count*interval_l))):
				proba[count-1] = proba[count-1] + 1
				
		ofile = open(o_rep + '/PDF_PRR_' + str(prrs[0]) + 'M.data', 'w')
		cdf_ofile = open(o_rep + '/CDF_PRR_' + str(prrs[0]) + 'M.data', 'w')
		for k in range(count):
			ofile.write(str((k+1)*interval_l) + ' ' + str(float(proba[k])/float(len(prrs[1]))) + '\n')
			cdf_ofile.write(str((k+1)*interval_l) + ' ' + str(float(sum(proba[:(k+1)]))/float(len(prrs[1]))) + '\n')
		ofile.close()
		cdf_ofile.close()
		       
	for i in range(len(all_rssi)):
		rssis = all_rssi[i]
		proba = []
		for rssi in rssis[1]:
			found = False
			for k in range(len(proba)):
				if proba[k][0] == rssi:
					v = (rssi, proba[k][1] + 1)
					proba[k] = v
					found = True
					break
			if not found:
				proba.append((rssi, 1))

		ofile = open(o_rep + '/PDF_RSSI_' + str(rssis[0]) + 'M.data', 'w')
		cdf_ofile = open(o_rep + '/CDF_RSSI_' + str(rssis[0]) + 'M.data', 'w')

		sort_proba = sorted(proba, key=lambda x: x[0])
		for k in range(len(sort_proba)):
			pr = float(sort_proba[k][1])/float(len(rssis[1]))
			pr_cdf = sum([sort_proba[i][1] for i in range(k+1)])
			ofile.write(str(sort_proba[k][0]) + ' ' + str(float(sort_proba[k][1])/float(len(rssis[1]))) + '\n')
			cdf_ofile.write(str(sort_proba[k][0]) + ' ' + str(float(pr_cdf)/float(len(rssis[1]))) + '\n')
		ofile.close()
		cdf_ofile.close()
		
		
