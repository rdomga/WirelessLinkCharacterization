
import os, math
import numpy as np

import PlotFunction as plot
import Read_Data as RD

def plot_received_messages(deploy_dir, nb_pos, TX_Powers_List, Exp, Channel):    
    for tx_power in TX_Powers_List:        
        if min(TX_Powers_List) < 0:       
            data_dir = deploy_dir + '/' + str(tx_power) + 'dBm'
        else:
            data_dir = deploy_dir + '/' + str(tx_power)
        image_rep = data_dir + '/Images'
        
        for node in range(1, nb_pos+1):
            fname = data_dir + '/RECEIVED_MESSAGES_' + str(node) + '.data'
            if os.path.isfile(fname) and os.access(fname, os.R_OK):
                print fname
                ifile = open(fname, 'r')
                xxx = []
                yyy = []
                for line in ifile:
                    data = line.strip('\r\n').split(' ')
                    if len(data) != 3:
                        continue                    
                    xxx.append(int(data[0]))
                    if data[2] != '?':
                        yyy.append(int(data[2]))
                    else:
                        yyy.append(np.NaN)                        
                ifile.close()
                
                if (len(yyy) != 0) and (len(xxx) != 0):                                
                    title  = 'EXPERIMENT ' + str(Exp) + ': CHANNEL ' + str(Channel) + '\nALL MESSAGES RECEIVED BY NODE ' + str(node)
                    ylabel = 'SENDER NODE'
                    xlabel = 'MESSAGE (LOCAL SEQUENCE NUMBER)'
                    
                    min_y = min(yyy)
                    max_y = max(yyy)
                    stic_y = None
                    y_int = 1
                    
                    min_x = min(xxx)
                    max_x = max(xxx)
                    stic_x = None  
                    x_int = 1 
                    
                    if max_x < 10:
                        xticslabels = None
                    else:
                        deb = int(math.ceil(float(min_x)/10)*10)
                        step = float(max_x - min_x)/10.0
                        step_dix = int(math.ceil(float(step)/10)*10)                        
                        xticslabels = range(deb, max_x, step_dix)
                    
                    legend_title = ''
                    legds = None
                    
                    image_fname = image_rep + '/RECEIVED_MESSAGES_' + str(node) + '.eps'                       
                    plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers([xxx], [yyy], None, xlabel, ylabel, title, image_fname, legds, legend_title,\
                                                                x_int, y_int, 0, min_x, max_x, min_y, max_y, stic_x, stic_y, xticslabels)
                                    
def plot_bidirectional_RSSI_LQI(deploy_dir, nb_pos, TX_Powers_List, Exp, Channel, subdir_prefix=''):    
    for power_or_msize in TX_Powers_List: 
        data_dir = deploy_dir + '/' + str(power_or_msize) + subdir_prefix
        image_rep = data_dir + '/Images'
        
        for node_a in range(1, nb_pos):
            for node_b in range(node_a+1, nb_pos+1):
                data_a_b = RD.read_rssi_lqi(deploy_dir, node_a, node_b, power_or_msize, subdir_prefix)
                data_b_a = RD.read_rssi_lqi(deploy_dir, node_b, node_a, power_or_msize, subdir_prefix)
                                
                data_x = []
                data_rssi = []
                data_lqi = []
                legds = []
                if len(data_a_b) > 0:
                    data_x.append([v[0] for v in data_a_b])
                    data_rssi.append([v[1] for v in data_a_b])
                    data_lqi.append([v[2] for v in data_a_b])
                    legds.append(str(node_a) + " ---> " + str(node_b))
                    
                if len(data_b_a) > 0:
                    data_x.append([v[0] for v in data_b_a])
                    data_rssi.append([v[1] for v in data_b_a])
                    data_lqi.append([v[2] for v in data_b_a])
                    legds.append(str(node_b) + " ---> " + str(node_a))
                
                
                print "RSSI AND LQI"    
                title  = 'Experiment ' + str(Exp) + ' : Channel ' + str(Channel) + '\n RSSI on LINK ' +  str(node_a) + ' <---> ' + str(node_b)            
                xlabel = 'Time(s)'
                legend_title = ''
                
                if len(data_x) > 0:          
                    min_x = min([min(v) for v in data_x])
                    max_x = max([max(v) for v in data_x])
                    stic_x = None
                    x_int = 0
                    
                    if max_x < 10:
                        xticslabels = None
                    else:
                        deb = int(math.ceil(float(min_x)/10)*10)
                        step = float(max_x - min_x)/10.0
                        step_dix = int(math.ceil(float(step)/10)*10)                        
                        xticslabels = range(deb, int(max_x), step_dix)
                else:
                    min_x = None
                    max_x = None
                    stic_x = None
                    x_int = None
                    xticslabels = None
                                    

                ylabel = 'RSSI(dBm)'
                if len(data_rssi) > 0:
                    min_y = min([min(v) for v in data_rssi]) - 0.5
                    max_y = max([max(v) for v in data_rssi]) + 0.5
                    stic_y = None
                    y_int = 0                    
                else:
                    min_y = None
                    max_y = None
                    stic_y = None
                    y_int = None                   
                    
                                    
                image_fname = image_rep + '/RSSI_' + str(node_a) + "_" + str(node_b) + '.eps'       
                plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(data_x, data_rssi, None, xlabel, ylabel, title, image_fname, legds, legend_title,\
                                                            x_int, y_int, 0, min_x, max_x, min_y, max_y, stic_x, stic_y, xticslabels)
                
                ylabel = 'LQI'
                if len(data_lqi) > 0:
                    min_y = min([min(v) for v in data_lqi]) - 0.5
                    max_y = max([max(v) for v in data_lqi]) + 0.5
                    stic_y = None
                    y_int = 1      
                else:
                    min_y = None
                    max_y = None
                    stic_y = None
                    y_int = None      
                                  
                                    
                title  = 'Experiment ' + str(Exp) + ' : Channel ' + str(Channel) + '\n LQI on LINK ' +  str(node_a) + ' <---> ' + str(node_b)            
                image_fname = image_rep + '/LQI_' + str(node_a) + "_" + str(node_b) + '.eps'       
                plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(data_x, data_lqi, None, xlabel, ylabel, title, image_fname, legds, legend_title,\
                                                            x_int, y_int, 0, min_x, max_x, min_y, max_y, stic_x, stic_y, xticslabels)
        

def plot_bidirectional_PRR(deploy_dir, nb_pos, TX_Powers_List, Exp, Channel, power_or_msize, subdir_prefix=''):    
    for power_or_msize in TX_Powers_List: 
        data_dir = deploy_dir + '/' + str(power_or_msize) + subdir_prefix
        image_rep = data_dir + '/Images'
                    
        for node_a in range(1, nb_pos):
            for node_b in range(node_a+1, nb_pos+1):
                data_a_b = RD.read_rssi_lqi(deploy_dir, node_a, node_b, power_or_msize, subdir_prefix)
                data_b_a = RD.read_rssi_lqi(deploy_dir, node_b, node_a, power_or_msize, subdir_prefix)
                
                if (len(data_a_b) != 0) and (len(data_b_a) != 0):
                    print "PRR"    
                    data_x = [[v[0] for v in data_a_b], [v[0] for v in data_b_a]]
                    data_prr = [[v[1] for v in data_a_b], [v[1] for v in data_b_a]]
                                    
                    min_x = min([min(v) for v in data_x])
                    max_x = max([max(v) for v in data_x])
                    stic_x = None
                    x_int = 0
                    if max_x < 10:
                        xticslabels = None
                    else:
                        deb = int(math.ceil(float(min_x)/10)*10)
                        step = float(max_x - min_x)/10.0
                        step_dix = int(math.ceil(float(step)/10)*10)                        
                        xticslabels = range(deb, int(max_x), step_dix)
                    
                    title  = 'Experiment ' + str(Exp) + ' : Channel ' + str(Channel) + '\n PRR on LINK ' +  str(node_a) + ' <---> ' + str(node_b)
                    xlabel = 'Time(s)'
                    legend_title = ''
                    legds = [str(node_a) + " ---> " + str(node_b), str(node_b) + " ---> " + str(node_a)]
    
                    ylabel = 'PRR'
                    min_y = 0.0
                    max_y = 1.02
                    stic_y = None
                    y_int = 0                    
                                        
                    image_fname = image_rep + '/PRR_' + str(node_a) + "_" + str(node_b) + '.eps'       
                    plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(data_x, data_prr, None, xlabel, ylabel, title, image_fname, legds, legend_title,\
                                                                x_int, y_int, 0, min_x, max_x, min_y, max_y, stic_x, stic_y, xticslabels)
                    
def plot_pdf_or_cdf_prr(deploy_dir, nb_pos, TX_Powers_List, distance, Exp, Channel, Distribution = 'PDF', subdir_prefix=''):
    for power_or_msize in TX_Powers_List:        
        data_dir = deploy_dir + '/' + str(power_or_msize) + subdir_prefix
        image_rep = data_dir + '/Images'
                
        pdf_prr_distance = dict()
        for node in range(1, nb_pos+1):
            dist = node*distance
            #fname = data_dir + '/'+Distribution+'_PRR_' + str(dist) + 'M.data'                
            tab = RD.read_pdf_or_cdf_distance(deploy_dir, Distribution, 'PRR', power_or_msize, dist, subdir_prefix)
            pdf_prr_distance[dist] = tab
        
        print pdf_prr_distance
        
        all_yy = []
        for dist in pdf_prr_distance.keys():
            all_yy += [v[1] for v in pdf_prr_distance[dist] if len(pdf_prr_distance[dist]) > 0]
        min_x = 0.0
        max_x = 1.02
        x_int = 0
        stic_x = 0.2
        xticslabels = None
        
        if len(all_yy) > 0:
            min_y = min(all_yy)
            max_y = max(all_yy)
            y_int = 0
            stic_y = (max_y - min_y)/5.0
            max_y += 0.02
        else:
            min_y = None
            max_y = None
            y_int = None
            stic_y = None
                
        ylabel = Distribution
        xlabel = 'Packet reception ratio'
        legend_title = ''
        legds = None
        for dist in pdf_prr_distance.keys():
            title  = 'Experiment ' + str(Exp) + ' : Channel ' + str(Channel) + '\n ' + Distribution + ' PRR : ' + str(dist) + 'M'
                
                                        
            xxx = [val[0] for val in pdf_prr_distance[dist]] 
            yyy = [val[1] for val in pdf_prr_distance[dist]] 
            
            image_fname = image_rep + '/' + Distribution + '_PRR_' + str(dist) + 'M.eps'
                       
        
            plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers([xxx], [yyy], None, xlabel, ylabel, title, image_fname, legds, legend_title,\
                                                        x_int, y_int, 0, min_x, max_x, min_y, max_y, stic_x, stic_y, xticslabels)
        
        fname = data_dir + '/' + Distribution + '_PRR_ALL_LINKS.data'
        xxx = []
        yyy = []
        if os.path.isfile(fname) and os.access(fname, os.R_OK):
            print fname
            ifile = open(fname, 'r')
            for line in ifile:
                data = line.strip('\r\n').split(' ')
                if len(data) != 2:
                    continue   
                xxx.append(float(data[0]))                 
                if data[1] != '?':
                    yyy.append(float(data[1]))
                else:
                    yyy.append(np.NaN)
            ifile.close()
        min_x = 0.0
        max_x = 1.02
        x_int = 0
        stic_x = 0.2
        xticslabels = None
        
        if len(yyy) > 0:
            min_y = 0.0
            max_y = max(yyy)
            y_int = 0
            stic_y = (max_y - min_y)/5.0
            max_y += 0.02            
        else:
            min_y = None
            max_y = None
            y_int = None
            stic_y = None
            
        title  = 'Experiment ' + str(Exp) + ' : Channel ' + str(Channel) + '\n' + Distribution + ' PRR ALL LINKS'
        
        image_fname = image_rep + '/' + Distribution + '_PRR_ALL_LINK.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers([xxx], [yyy], None, xlabel, ylabel, title, image_fname, legds, legend_title,\
                                                    x_int, y_int, 0, min_x, max_x, min_y, max_y, stic_x, stic_y, xticslabels)


def plot_pdf_or_cdf_rssi(deploy_dir, nb_pos, TX_Powers_List, distance, Exp, Channel, Distribution = 'PDF', subdir_prefix=''): 
    for power_or_msize in TX_Powers_List:        
        data_dir = deploy_dir + '/' + str(power_or_msize) + subdir_prefix
        image_rep = data_dir + '/Images'
        
        pdf_rssi_distance = dict()
        for node in range(1, nb_pos+1):
            dist = node*distance
            tab = RD.read_pdf_or_cdf_distance(deploy_dir, Distribution, 'RSSI', power_or_msize, dist, subdir_prefix)
            pdf_rssi_distance[dist] = tab
                            
        all_yy = []
        all_xx = []
        for dist in pdf_rssi_distance.keys():
            all_yy += [v[1] for v in pdf_rssi_distance[dist] if len(pdf_rssi_distance[dist]) > 0]
            all_xx += [v[0] for v in pdf_rssi_distance[dist] if len(pdf_rssi_distance[dist]) > 0]
        
        if len(all_xx) > 0:    
            min_x = min(all_xx)
            max_x = max(all_xx) + 1
            x_int = 1
            stic_x = (float(max_x) - float(min_x))/5.0
        else:
            min_x = None
            max_x = None
            x_int = None
            stic_x = None
            
        xticslabels = None
        
        if len(all_yy) > 0:
            min_y = min(all_yy)
            max_y = max(all_yy)
            y_int = 0
            stic_y = (max_y - min_y)/5.0
            max_y += 0.02
            
        else:
            min_y = None
            max_y = None
            y_int = None
            stic_y = None
                    
        ylabel = Distribution
        xlabel = 'RSSI(dBm)'
        legend_title = ''
        legds = None
        for dist in pdf_rssi_distance.keys():
            title  = 'Experiment ' + str(Exp) + ' : Channel ' + str(Channel) + '\n ' + Distribution + ' RSSI : ' + str(dist) + 'M'
                                        
            xxx = [val[0] for val in pdf_rssi_distance[dist]] 
            yyy = [val[1] for val in pdf_rssi_distance[dist]] 
            
            image_fname = image_rep + '/' + Distribution + '_RSSI_' + str(dist) + 'M.eps'       
        
            plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers([xxx], [yyy], None, xlabel, ylabel, title, image_fname, legds, legend_title,\
                                                        x_int, y_int, 0, min_x, max_x, min_y, max_y, stic_x, stic_y, xticslabels)
    
      
        fname = data_dir + '/' + Distribution + '_RSSI_ALL_LINKS.data'
        xxx = []
        yyy = []
        if os.path.isfile(fname) and os.access(fname, os.R_OK):
            print fname
            ifile = open(fname, 'r')
            for line in ifile:
                data = line.strip('\r\n').split(' ')
                if len(data) != 2:
                    continue   
                xxx.append(float(data[0]))                 
                if data[1] != '?':
                    yyy.append(float(data[1]))
                else:
                    yyy.append(np.NaN)
            ifile.close()
        
        if len(xxx) > 0:    
            min_x = min(xxx)
            max_x = max(xxx) + 1
            x_int = 1
            stic_x = (float(max_x) - float(min_x))/5.0
        else:
            min_x = None
            max_x = None
            x_int = None
            stic_x = None
            
        xticslabels = None
        
        if len(yyy) > 0:
            min_y = 0.0
            max_y = max(yyy)
            y_int = 0
            stic_y = (max_y - min_y)/5.0
            max_y += 0.02            
        else:
            min_y = None
            max_y = None
            y_int = None
            stic_y = None

        title  = 'Experiment ' + str(Exp) + ' : Channel ' + str(Channel) + '\n ' + Distribution + ' RSSI ALL LINKS'
        
        image_fname = image_rep + '/' + Distribution + '_RSSI_ALL_LINK.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers([xxx], [yyy], None, xlabel, ylabel, title, image_fname, legds, legend_title,\
                                                    x_int, y_int, 0, min_x, max_x, min_y, max_y, stic_x, stic_y, xticslabels)
        
      
def plot_pdf_or_cdf_lqi(deploy_dir, nb_pos, TX_Powers_List, distance, Exp, Channel, Distribution='PDF', subdir_prefix=''): 
    for power_or_msize in TX_Powers_List:        
        data_dir = deploy_dir + '/' + str(power_or_msize) + subdir_prefix
        image_rep = data_dir + '/Images'
        
        pdf_lqi_distance = dict()
        for node in range(1, nb_pos+1):
            dist = node*distance
            tab = RD.read_pdf_or_cdf_distance(deploy_dir, Distribution, 'RSSI', power_or_msize, dist, subdir_prefix)
            pdf_lqi_distance[dist] = tab
                            
        all_yy = []
        all_xx = []
        for dist in pdf_lqi_distance.keys():
            all_yy += [v[1] for v in pdf_lqi_distance[dist] if len(pdf_lqi_distance[dist]) > 0]
            all_xx += [v[0] for v in pdf_lqi_distance[dist] if len(pdf_lqi_distance[dist]) > 0]
            
        if len(all_xx) > 0:    
            min_x = min(all_xx)
            max_x = max(all_xx) + 1
            x_int = 1
            stic_x = (float(max_x) - float(min_x))/5.0
        else:
            min_x = None
            max_x = None
            x_int = None
            stic_x = None
            
        xticslabels = None
        
        if len(all_yy) > 0:
            min_y = min(all_yy)
            max_y = max(all_yy)
            y_int = 0
            stic_y = (max_y - min_y)/5.0
            max_y += 0.02            
        else:
            min_y = None
            max_y = None
            y_int = None
            stic_y = None
                            
        ylabel = Distribution
        xlabel = 'LQI'
        legend_title = ''
        legds = None
        for dist in pdf_lqi_distance.keys():
            title  = 'Experiment ' + str(Exp) + ' : Channel ' + str(Channel) + '\n ' + Distribution + ' LQI : ' + str(dist) + 'M'
                                        
            xxx = [val[0] for val in pdf_lqi_distance[dist]] 
            yyy = [val[1] for val in pdf_lqi_distance[dist]] 
            
            image_fname = image_rep + '/' + Distribution + '_LQI_' + str(dist) + 'M.eps'       
        
            plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers([xxx], [yyy], None, xlabel, ylabel, title, image_fname, legds, legend_title,\
                                                        x_int, y_int, 0, min_x, max_x, min_y, max_y, stic_x, stic_y, xticslabels)
    

    
                     