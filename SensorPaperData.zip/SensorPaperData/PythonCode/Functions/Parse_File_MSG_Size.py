
import sys, os, shutil

def add_prr(prr_list, distance, prr):
    for vv in prr_list:
        if vv[0] == distance:
            vv[1].append(prr)
            return
    prr_list.append((distance, [prr]))

def add_rssi(rssi_list, distance, rssi):
    for vv in rssi_list:
        if vv[0] == distance:
            vv[1].append(rssi)
            return
    rssi_list.append((distance, [rssi]))

def add_lqi(lqi_list, distance, lqi):
    for vv in lqi_list:
        if vv[0] == distance:
            vv[1].append(lqi)
            return
    lqi_list.append((distance, [lqi]))
    
def parse(deploy_dir, nb_pos, distance, nb_msg_prr, nb_msg, interval_l):        
    """
    if __name__ == "__main__":
    deploy_dir = sys.argv[1] #Dans quel repertoire sont stockes les fichiers    
    nb_pos = int(sys.argv[2]) #Dans le cas ou les donnees sont stockees dans chaque capteur, indique le nombre de fichier dans le repertoire d'origine
    distance = int(sys.argv[3]) #Distance entre capteurs
    nb_msg_prr = int(sys.argv[4]) #Nombre de point sur lequel on doit calculer le PRR (20 par exemple)
    nb_msg = int(sys.argv[5]) #Nombre de message envoyer par cycle
    interval_l = float(sys.argv[6]) #Pour le calcul de la distribution du PRR, on fait une repartition par intervalle dans l'intervalle [0,1]. Ceci est donc la longeur de l'intervalle, par exemple 0.01 ou encore 0.05
    """
     
    msg_size = []
    
    messages = []
    received_msg = []
    for n in range(nb_pos):
        fname = deploy_dir + '/' + str(n+1) + '.data'
        #print fname
                
        if os.path.isfile(fname) and os.access(fname, os.R_OK):    
            ifile = open(fname, 'r')
            """
            Chaque ligne de ce fichier est structuree comme suit :
            [SRC NUMERO_SEQUENCE DST RSSI LQI MSG_SIZE]
            """
            for line in ifile:
                data = line.strip('\r\n').split(' ')
                if len(data) != 6:
                    continue
                    
                payload = int(data[5])
                tx_node = int(data[0])-1
                rx_node = int(data[2])-1
                
                seq_no = int(data[1])
                rssi = int(data[3])
                lqi = int(data[4])

                if payload in msg_size:
                    msg_size_index = msg_size.index(payload)
                    
                    messages[msg_size_index][tx_node][rx_node].append((seq_no, rssi, lqi))
                    received_msg[msg_size_index][rx_node].append((seq_no, int(data[0])))                    
                else:
                    msg_size.append(payload)

                    node = [[[] for j in range(nb_pos)] for i in range(nb_pos)]
                    node[tx_node][rx_node].append((seq_no, rssi, lqi))
                    messages.append(node)
                    
                    rx_msg_from_node = [[] for i in range(nb_pos)]
                    rx_msg_from_node[rx_node].append((seq_no, int(data[0])))
                    received_msg.append(rx_msg_from_node)
                    
    for m_i in msg_size:
        dirname = deploy_dir + '/' + str(m_i)
        if os.path.exists(dirname):
            shutil.rmtree(dirname)        
        os.makedirs(dirname)
    
    for msg_size_index in range(len(msg_size)):
        dirname = deploy_dir + '/' + str(msg_size[msg_size_index])
        
        prr_Distance = []
        rssi_Distance = []
        lqi_Distance = []

        PRR_all_links = []
        RSSI_all_links = []
        LQI_all_links = []
        
        dict_prr_def = dict()
        
        for tx_node in range(nb_pos):
            for rx_node in range(nb_pos):
                if rx_node == tx_node:
                    continue
                if len(messages[msg_size_index][tx_node][rx_node]) > 0:
                    index = 0
                    nb_msg_rcv = 0
                    prr_point = 0
                    temps = 0.0
                    avg_rssi = 0.0
                    """
                    FILES TO STORE MESSAGE FROM src_node TO dst_node
                    ONE FILE FOR THE RSSI OF EACH MESSAGE, 
                    ONE FILE FOR THE PRR ON EPOCH OF nb_msg_prr AND
                    ONE OTHER FILE FOR THE AVERAGE RSSI ON THE EPOCH
                    Messages, PRR and Average RSSI on a particular Link
                    """
                    fmsg = open(dirname + '/MESSAGES_' + str(tx_node+1) + '_' + str(rx_node+1) + '.data', 'w')
                    fprr = open(dirname + '/PRR_' + str(tx_node+1) + '_' + str(rx_node+1) + '.data', 'w')
                    favg_rssi = open(dirname + '/AGV_RSSI_' + str(tx_node+1) + '_' + str(rx_node+1) + '.data', 'w')
                     
                    for message in messages[msg_size_index][tx_node][rx_node]:
                        add_rssi(rssi_Distance, abs(tx_node-rx_node)*distance, message[1])
                        add_lqi(lqi_Distance, abs(tx_node-rx_node)*distance, message[2])
                        
                        RSSI_all_links.append(message[1])
                        LQI_all_links.append(message[2])                        
                        
                        seq = int(message[0])                        
                        while index < seq:
                            """
                            TIME INDEX SEQUENCE_NUMBER SEQUENCE_NUMBER
                            ? IS FOR MISSING DATA/POINT
                            """
                            fmsg.write(str(temps) + ' ' + str(index) + ' ' + str(seq) + ' ' + str(message[0]) + ' ? ?\n')
                            index += 1
                            temps += 0.4
                            
                            if index % nb_msg_prr == 0:
                                prr = float(nb_msg_rcv)/float(nb_msg_prr)
                                add_prr(prr_Distance, abs(tx_node-rx_node)*distance, prr)
                                PRR_all_links.append(prr)
                                
                                fprr.write(str((prr_point+1)*8) + ' ' + str(prr) +'\n')                                
                                if nb_msg_rcv != 0:
                                    favg_rssi.write(str((prr_point+1)*8) + ' ' + str(float(avg_rssi)/float(nb_msg_rcv)) +'\n')
                                else:
                                    favg_rssi.write(str((prr_point+1)*8) + ' ?\n')
                                
                                vals = []
                                point = (prr, tx_node, rx_node)
                                if dict_prr_def.has_key(prr_point):
                                    vals = dict_prr_def[prr_point]
                                vals.append(point)
                                dict_prr_def[prr_point] = vals
                                
                                nb_msg_rcv = 0
                                prr_point += 1
                                avg_rssi = 0.0
                               
                        fmsg.write(str(temps) + ' ' + str(seq) + ' ' + str(seq) + ' ' + str(message[0]) +  ' ' + str(message[1])+ ' ' + str(message[2]) + '\n')
                        temps += 0.4
                        index += 1
                        nb_msg_rcv += 1
                        avg_rssi += message[1]
                        
                        if index % nb_msg_prr == 0:
                            prr = float(nb_msg_rcv)/float(nb_msg_prr)
                            add_prr(prr_Distance, abs(tx_node-rx_node)*distance, prr)
                            PRR_all_links.append(prr)
                            
                            fprr.write(str((prr_point+1)*8) + ' ' + str(prr) +'\n')
                            
                            if nb_msg_rcv != 0:
                                favg_rssi.write(str((prr_point+1)*8) + ' ' + str(float(avg_rssi)/float(nb_msg_rcv)) +'\n')
                            else:
                                favg_rssi.write(str((prr_point+1)*8) + ' ?\n')

                            vals = []
                            point = (prr, tx_node, rx_node)
                            if dict_prr_def.has_key(prr_point):
                                vals = dict_prr_def[prr_point]
                            vals.append(point)
                            dict_prr_def[prr_point] = vals
                            
                            nb_msg_rcv = 0
                            prr_point += 1
                            avg_rssi = 0.0
                                                                    
                    while index < nb_msg:
                        fmsg.write(str(temps) + ' ' + str(index) + ' ' + str(seq) + ' ' + str(message[0]) + ' ? ?\n')
                        index += 1
                        temps += 0.4
                    
                        if index % nb_msg_prr == 0:
                            prr = float(nb_msg_rcv)/float(nb_msg_prr)
                            add_prr(prr_Distance, abs(tx_node-rx_node)*distance, prr)
                            PRR_all_links.append(prr)
                            
                            fprr.write(str((prr_point+1)*8) + ' ' + str(prr) +'\n')
                            
                            if nb_msg_rcv != 0:
                                favg_rssi.write(str((prr_point+1)*8) + ' ' + str(float(avg_rssi)/float(nb_msg_rcv)) +'\n')
                            else:
                                favg_rssi.write(str((prr_point+1)*8) + ' ?\n')

                            vals = []
                            point = (prr, tx_node, rx_node)
                            if dict_prr_def.has_key(prr_point):
                                vals = dict_prr_def[prr_point]
                            vals.append(point)
                            dict_prr_def[prr_point] = vals
                            
                            nb_msg_rcv = 0
                            prr_point += 1
                            avg_rssi = 0.0
                                        
                    fmsg.close()
                    fprr.close()
                    favg_rssi.close()
        
        for rx_node in range(nb_pos):
            fmsg = open(dirname + '/RECEIVED_MESSAGES_' + str(rx_node + 1) + '.data', 'w')
            index = 0
            for message in received_msg[msg_size_index][rx_node]:
                fmsg.write(str(index) + ' ' + str(message[0]) + ' ' + str(message[1]) + '\n')
                index += 1
            fmsg.close()
        prr_def_file = open(dirname + '/TIME_PRR_DEF.data', 'w')
        #prr_def_file.write("'TIME' 'NO LINK' 'POOR' 'INTERMEDIATE' 'GOOD' 'PERFECT'\n")
        #print "NEW!!!", deploy_dir, msg_size[msg_size_index], " Bytes"
        for prr_point in dict_prr_def.keys():
            #print prr_point, len(dict_prr_def[prr_point]), dict_prr_def[prr_point]
            prrs = [v[0] for v in dict_prr_def[prr_point]]
            link_def = [0, 0, 0, 0, 0]
            for prr in prrs:
                if (prr == 0):
                    link_def[0] += 1                
                if (prr > 0) and (prr <= 0.1):
                    link_def[1] += 1
                elif (prr > 0.1) and (prr < 0.9):
                    link_def[2] += 1                
                elif (prr >= 0.9) and (prr < 1.0):
                    link_def[3] += 1
                elif (prr == 1.0):
                    link_def[4] += 1
            percentage = [float(c)*100.0/float(len(prrs)) for c in link_def]
            prr_def_file.write(str(prr_point) + ' ' + ' '.join([str(p) for p in percentage]) + '\n')
        prr_def_file.close()
        
        """
        Distribution du PRR en fonction de la distance du lien
        """
        prr_def_file = open(dirname + '/PRR_DEF.data', 'w')
        prr_def_file.write("'TYPE' 'NO LINK' 'POOR' 'INTERMEDIATE' 'GOOD' 'PERFECT'\n")
        
        count = int(1.0/interval_l)
        for prrs in prr_Distance:
            proba = [0 for k in range(count)]
            link_def = [0, 0, 0, 0, 0]
            #print "NEW!!! ==> ", msg_size[msg_size_index], " Bytes", prrs[0], " M", len(prrs[1]), prrs
                 
            for prr in prrs[1]:                
                for k in range(count - 1):
                    if ((prr >= float(k*interval_l)) and (prr < float((k+1)*interval_l))):
                        proba[k] = proba[k] + 1
                if ((prr >= float((count-1)*interval_l)) and (prr <= float(count*interval_l))):
                    proba[count-1] = proba[count-1] + 1

                if (prr == 0):
                    link_def[0] += 1                
                if (prr > 0) and (prr <= 0.1):
                    link_def[1] += 1
                elif (prr > 0.1) and (prr < 0.9):
                    link_def[2] += 1                
                elif (prr >= 0.9) and (prr < 1.0):
                    link_def[3] += 1
                elif (prr == 1.0):
                    link_def[4] += 1

            #Save PRR definition
            prr_def_file.write(str(prrs[0]) + 'M ' + ' '.join([str(float(c)*100.0/float(len(prrs[1]))) for c in link_def]) + '\n')
                            
            ofile = open(dirname + '/PDF_PRR_' + str(prrs[0]) + 'M.data', 'w')
            cdf_ofile = open(dirname + '/CDF_PRR_' + str(prrs[0]) + 'M.data', 'w')
            s_proba = 0.0
            for k in range(count):
                ofile.write(str((k+1)*interval_l) + ' ' + str(float(proba[k])/float(len(prrs[1]))) + '\n')
                cdf_ofile.write(str((k+1)*interval_l) + ' ' + str(float(sum(proba[:(k+1)]))/float(len(prrs[1]))) + '\n')
                s_proba += float(proba[k])/float(len(prrs[1]))
            ofile.close()
            cdf_ofile.close()
            #print s_proba

        """
        Distribution du PRR considerant tous les liens
        """
        proba = [0 for k in range(count)] 
        link_def = [0, 0, 0, 0, 0]         
        for prr in PRR_all_links:
            for k in range(count - 1):
                if ((prr >= float(k*interval_l)) and (prr < float((k+1)*interval_l))):
                    proba[k] = proba[k] + 1
                                        
            if ((prr >= float((count-1)*interval_l)) and (prr <= float(count*interval_l))):
                proba[count-1] = proba[count-1] + 1

            if (prr == 0):
                link_def[0] += 1                
            if (prr > 0) and (prr <= 0.1):
                link_def[1] += 1
            elif (prr > 0.1) and (prr < 0.9):
                link_def[2] += 1                
            elif (prr >= 0.9) and (prr < 1.0):
                link_def[3] += 1
            elif (prr == 1.0):
                link_def[4] += 1
                
        #Save PRR definition
        prr_def_file.write('ALL_LINKS '+ ' '.join([str(float(c)*100.0/float(len(PRR_all_links))) for c in link_def]) + '\n')
        prr_def_file.close()
        
        ofile = open(dirname + '/PDF_PRR_ALL_LINKS.data', 'w')
        cdf_ofile = open(dirname + '/CDF_PRR_ALL_LINKS.data', 'w')
        s_proba = 0.0
        for k in range(count):
            ofile.write(str((k+1)*interval_l) + ' ' + str(float(proba[k])/float(len(PRR_all_links))) + '\n')
            cdf_ofile.write(str((k+1)*interval_l) + ' ' + str(float(sum(proba[:(k+1)]))/float(len(PRR_all_links))) + '\n')
            s_proba += float(proba[k])/float(len(PRR_all_links))
        ofile.close()
        cdf_ofile.close()
        #print s_proba
           

        """
        Dans les trois fichiers suivants, on enregistre tous les points. CHaque ligne de ce fichier a le format ;
        DISTANCE DATA
        DATA peut etre : 
            -- une valeur du PRR pour un lien ayant la distance 
            -- une valeur de RSSI pour un lien ayant cette distance
            -- une valuur du LQI pour une lien ayant toujours cette distance
        """                        
        fdistrib_prr = open(dirname + '/ALL_DISTRIB_PRR.data', 'w')
        for prrs in prr_Distance:
            for prr in prrs[1]: 
                fdistrib_prr.write(str(prrs[0])+ ' ' + str(prr) + '\n')

        fdistrib_rssi = open(dirname + '/ALL_DISTRIB_RSSI.data', 'w')
        for rssis in rssi_Distance:
            for rssi in rssis[1]: 
                fdistrib_rssi.write(str(rssis[0])+ ' ' + str(rssi) + '\n')

        fdistrib_lqi = open(dirname + '/ALL_DISTRIB_LQI.data', 'w')                       
        for lqis in lqi_Distance:
            for lqi in lqis[1]: 
                fdistrib_lqi.write(str(lqis[0])+ ' ' + str(lqi) + '\n')

        for rssis in rssi_Distance:
            proba = []
            for rssi in rssis[1]:
                found = False
                for k in range(len(proba)):                    
                    if proba[k][0] == rssi:
                        v = (rssi, proba[k][1] + 1)
                        proba[k] = v
                        found = True
                        break
                if not found:
                    proba.append((rssi, 1))
            sort_proba = sorted(proba, key=lambda x: x[0])
            s_proba = 0.0            
            ofile = open(dirname + '/PDF_RSSI_' + str(rssis[0]) + 'M.data', 'w')
            cdf_ofile = open(dirname + '/CDF_RSSI_' + str(rssis[0]) + 'M.data', 'w')
            for k in range(len(sort_proba)):
                pr = float(sort_proba[k][1])/float(len(rssis[1]))
                pr_cdf = sum([sort_proba[i][1] for i in range(k+1)])                
                s_proba += pr
                ofile.write(str(sort_proba[k][0]) + ' ' + str(float(sort_proba[k][1])/float(len(rssis[1]))) + '\n')
                cdf_ofile.write(str(sort_proba[k][0]) + ' ' + str(float(pr_cdf)/float(len(rssis[1]))) + '\n')
            ofile.close()
            cdf_ofile.close()
            #print s_proba

        for lqis in lqi_Distance:
            proba = []
            for lqi in lqis[1]:
                found = False
                for k in range(len(proba)):
                    if proba[k][0] == lqi:
                        v = (lqi, proba[k][1] + 1)
                        proba[k] = v 
                        found = True
                        break
                if not found:
                    proba.append((lqi, 1))
            sort_proba = sorted(proba, key=lambda x: x[0])
            
            s_proba = 0.0
            ofile = open(dirname + '/PDF_LQI_' + str(lqis[0]) + 'M.data', 'w')
            for k in range(len(sort_proba)):
                pr = float(sort_proba[k][1])/float(len(lqis[1]))
                s_proba += pr
                ofile.write(str(sort_proba[k][0]) + ' ' + str(pr) + '\n')
            ofile.close()
            #print s_proba

        """
        Distribution du RSSI considerant tous les liens
        """
        proba = []        
        for rssi in RSSI_all_links:
            found = False        
            for k in range(len(proba)):                    
                if proba[k][0] == rssi:
                    v = (rssi, proba[k][1] + 1)
                    proba[k] = v
                    found = True
                    break
            if not found:
                proba.append((rssi, 1))

        sort_proba = sorted(proba, key=lambda x: x[0])
        s_proba = 0.0            
        ofile = open(dirname + '/PDF_RSSI_ALL_LINKS.data', 'w')
        cdf_ofile = open(dirname + '/CDF_RSSI_ALL_LINKS.data', 'w')
        for k in range(len(sort_proba)):
            pr = float(sort_proba[k][1])/float(len(RSSI_all_links))
            pr_cdf = sum([sort_proba[i][1] for i in range(k+1)])
            pr_cdf = float(pr_cdf)/float(len(RSSI_all_links))
            
            s_proba += pr
            ofile.write(str(sort_proba[k][0]) + ' ' + str(pr) + '\n')
            cdf_ofile.write(str(sort_proba[k][0]) + ' ' + str(pr_cdf) + '\n')
        ofile.close()
        cdf_ofile.close()
        #print s_proba

        fdistrib_prr.close()
        fdistrib_rssi.close()
        fdistrib_lqi.close()
            
    fmsg = open(deploy_dir + '/msg_size.data', 'w')                  
    fmsg.write(' '.join([str(x) for x in msg_size]))    
    fmsg.close()
        
