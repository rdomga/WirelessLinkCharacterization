
import os, math
import numpy as np
import pandas as pd

def read_rssi_lqi(base_dir, src, dst, power_or_msize, subdir_prefix):    
    tab = []
    fname = base_dir + '/' + str(power_or_msize) + subdir_prefix + '/MESSAGES_' + str(src) + '_' + str(dst) + '.data'
    if os.path.isfile(fname) and os.access(fname, os.R_OK):
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            if len(data) != 6:
                continue 
            time = float(data[0])
                             
            if data[4] != '?':
                rssi = float(data[4])
            else:
                rssi = np.NaN
            
            if data[5] != '?':
                lqi = float(data[5])
            else:
                lqi = np.NaN                
            tab.append((time, rssi, lqi))                         
        ifile.close()
        
    return tab
    
def read_prr(base_dir, src, dst, power_or_msize, subdir_prefix):    
    tab = []
    fname = base_dir + '/' + str(power_or_msize) + subdir_prefix + '/PRR_' + str(src) + '_' + str(dst) + '.data'
    if os.path.isfile(fname) and os.access(fname, os.R_OK):
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            if len(data) != 2:
                continue 
            time = float(data[0])
                             
            if data[1] != '?':
                prr = float(data[1])
            else:
                prr = np.NaN                                        
            tab.append((time, prr))                         
        ifile.close()
                
    return tab

def read_pdf_or_cdf_distance(base_dir, Distribution, Data, power_or_msize, distance, subdir_prefix, is_data_dir = False):    
    tab = []
    if is_data_dir == True:
        if subdir_prefix != '':
            if distance != None:
                fname = base_dir + '/' + Distribution + '_' + Data + '_' + subdir_prefix + '_' + str(distance) + 'M.data'
            else:
                fname = base_dir + '/' + Distribution + '_' + Data + '_' + subdir_prefix + '_ALL_LINKS.data'
        else:
            if distance != None:
                fname = base_dir + '/' + Distribution + '_' + Data + '_' + str(distance) + 'M.data'
            else:
                fname = base_dir + '/' + Distribution + '_' + Data + '_ALL_LINKS.data'
            
    else:        
        if distance != None:
            fname = base_dir + '/' + str(power_or_msize) + subdir_prefix + '/' + Distribution + '_' + Data + '_' + str(distance) + 'M.data'
        else:
            fname = base_dir + '/' + str(power_or_msize) + subdir_prefix + '/' + Distribution + '_' + Data + '_ALL_LINKS.data'
                
    if os.path.isfile(fname) and os.access(fname, os.R_OK):
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            if len(data) != 2:
                continue                    
            if data[1] != '?':
                tab.append((float(data[0]), float(data[1])))
            else:
                tab.append((float(data[0]), np.NaN))                                           
        ifile.close()
    
    return tab
    

def read_all_distrib_power_or_msize(base_dir, Data, power_or_msize, subdir_prefix):    
    tab = []
    fname = base_dir + '/' + str(power_or_msize) + subdir_prefix + '/ALL_DISTRIB_' + Data + '.data'
                
    if os.path.isfile(fname) and os.access(fname, os.R_OK):
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            if len(data) != 2:
                continue                    
            if data[1] != '?':
                tab.append((float(data[0]), float(data[1])))
            else:
                tab.append((float(data[0]), np.NaN))                                           
        ifile.close()
    
    return tab
    
def read_cdf_ass_power_or_msize(base_dir, Data, power_or_msize, subdir_prefix):    
    tab = []
    fname = base_dir + '/' + str(power_or_msize) + subdir_prefix + '/CDF_ASS_' + Data + '.data'                
    if os.path.isfile(fname) and os.access(fname, os.R_OK):
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            if len(data) != 2:
                continue                    
            if data[1] != '?':
                tab.append((float(data[0]), float(data[1])))
            else:
                tab.append((float(data[0]), np.NaN))                                           
        ifile.close()
    
    return tab    

def read_prr_def(base_dir, power_or_msize, subdir_prefix):
    poor_link = None
    intermediate_link = None
    good_link = None
    fname = base_dir + '/' + str(power_or_msize) + subdir_prefix + '/PRR_DEF.data'                
    if os.path.isfile(fname) and os.access(fname, os.R_OK):
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            if len(data) != 6:
                continue                    
            if data[0] == 'ALL_LINKS':
                poor_link = float(data[1]) + float(data[2])
                intermediate_link = float(data[3])
                good_link = float(data[4]) + float(data[5])
        ifile.close()
    
    return (poor_link, intermediate_link, good_link)

def read_prr_def_with_ci(base_dir, power_or_msize, subdir_prefix):
    ci_param_95_percent = 1.96     
    file_name = base_dir + '/' + str(power_or_msize) + subdir_prefix + '/TIME_PRR_DEF.data'   
    poors = []
    intermediates = []
    goods = []      
    if os.path.isfile(file_name) and os.access(file_name, os.R_OK):
        ifile = open(file_name, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            if len(data) != 6:
                continue 
            poors.append(float(data[1]) + float(data[2]))                   
            intermediates.append(float(data[3]))                   
            goods.append(float(data[4]) + float(data[5]))                   
        ifile.close()
        
    if len(poors) > 0:
        avg_poor = sum(poors)/len(poors)
        std_poor = math.sqrt(sum([(avg_poor - x)**2 for x in poors])/len(poors))
        min_poor = avg_poor - (ci_param_95_percent*std_poor)/math.sqrt(len(poors))
        max_poor = avg_poor + (ci_param_95_percent*std_poor)/math.sqrt(len(poors))
        
        avg_intermediate = sum(intermediates)/len(intermediates)
        std_intermediate = math.sqrt(sum([(avg_intermediate - x)**2 for x in intermediates])/len(intermediates))
        min_intermediate = avg_intermediate - (ci_param_95_percent*std_intermediate)/math.sqrt(len(intermediates))
        max_intermediate = avg_intermediate + (ci_param_95_percent*std_intermediate)/math.sqrt(len(intermediates))

        avg_good = sum(goods)/len(goods)
        std_good = math.sqrt(sum([(avg_good - x)**2 for x in goods])/len(goods))
        min_good = avg_good - (ci_param_95_percent*std_good)/math.sqrt(len(goods))
        max_good = avg_good + (ci_param_95_percent*std_good)/math.sqrt(len(goods))
                
        return ([avg_poor, max_poor-min_poor], [avg_intermediate, max_intermediate-min_intermediate],\
                 [avg_good, max_good-min_good])
    else:
        return (None, None, None)
    