
import sys, os, copy
import PlotFunction as plot

def add_prr(prr_list, distance, prr):
    for vv in prr_list:
        if vv[0] == distance:
            vv[1].append(prr)
            return
    prr_list.append((distance, [prr]))

def add_rssi(rssi_list, distance, rssi):
    for vv in rssi_list:
        if vv[0] == distance:
            vv[1].append(rssi)
            return
    rssi_list.append((distance, [rssi]))
                
    
nb_rep = len(sys.argv) - 1 #Nombre de repertoires
interval_l = 0.1

def plot_curve(list_rep, image_dir):    
    all_prr = []
    all_rssi = []
    
    data_prr = dict()
    data_rssi = dict()
    for rep in list_rep:
        fname = rep + '/ALL_DISTRIB_PRR.data'
        if os.path.isfile(fname) and os.access(fname, os.R_OK):    
            ifile = open(fname, 'r')
            for line in ifile:
                data = line.strip('\r\n').split(' ')
                if len(data) != 2:
                    continue
                
                vals = []
                xx = float(data[0])
                if data_prr.has_key(int(xx)):
                    vals = data_prr[int(xx)]                
                #if not float(data[1]) in vals:
                vals.append(float(data[1]))                
                data_prr[int(xx)] = vals                
                add_prr(all_prr, int(xx), float(data[1]))
                
            ifile.close()
                
        fname = rep + '/ALL_DISTRIB_RSSI.data'
        if os.path.isfile(fname) and os.access(fname, os.R_OK):
            ifile = open(fname, 'r')
            for line in ifile:
                data = line.strip('\r\n').split(' ')
                if len(data) != 2:
                    continue
                vals = []
                xx = float(data[0])
                if data_rssi.has_key(int(xx)):
                    vals = data_rssi[int(xx)]                
                #if not float(data[1]) in vals:
                vals.append(float(data[1]))                
                data_rssi[int(xx)] = vals
                add_rssi(all_rssi, int(xx), float(data[1]))
            ifile.close()
                
    list_prrs = []
    list_keys = data_prr.keys()
    list_keys.sort()
    #print list_keys
    x_data = [list_keys[i] for i  in range(0, len(list_keys)+1, 2)]
    for key in x_data:
        list_prrs.append(data_prr[key])
    
    xlabel = "Distance (M)" 
    ylabel = 'PRR'
    title = ''    
    #title = 'PRR distribution'    
    image_fname = image_dir + '/STAT_PRR_DISTANCE.eps'   
    plot.plot_box_plot(image_fname, list_prrs, x_data, xlabel, ylabel, title)
    
    list_rssis = []
    list_keys = data_rssi.keys()
    list_keys.sort()
    x_data = [list_keys[i] for i  in range(0, len(list_keys)+1, 2)]
    for key in x_data:
    #for dist in list_keys:
        list_rssis.append(data_rssi[key])

    xlabel = "Distance (M)" 
    ylabel = 'RSSI(dBm)'
    #title = 'RSSI distribution'    
    title = ''    
    image_fname = image_dir + '/STAT_RSSI_DISTANCE.eps'        
    plot.plot_box_plot(image_fname, list_rssis, x_data, xlabel, ylabel, title)
                