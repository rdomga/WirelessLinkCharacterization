
import Read_Data as RD
import math

import PlotFunction as plot
import numpy as np

def plot_curve(base_dir, image_rep, prefix, link_len = [3, 6, 9, 12]):
    """
    RSSI, LQI and PRR Value for some links for different msize level
    x_decimal=1, y_decimal=1
    """
    
    """
    READ_DATA From File
    data = {couple: {msize: (x_a_b[], x_b_a[], rssi_a_b[], rssi_b_a[], lqi_a_b[], lqi_b_a[])}}
    """ 
    msize_List = [2, 82]        
    links = [(1,2), (1,3), (1,4), (1,5), (2,4)]       
    data_rssi_lqi = dict()
    data_prr = dict()
    for a_link in links:
        val_msize_rssi_lqi = dict()
        val_msize_prr = dict()
        for msize in msize_List:
            Tab_a_b = RD.read_rssi_lqi(base_dir, a_link[0], a_link[1], msize, prefix)
            Tab_b_a = RD.read_rssi_lqi(base_dir, a_link[1], a_link[0], msize, prefix)
            val = ([v[0] for v in Tab_a_b], [v[0] for v in Tab_b_a], [v[1] for v in Tab_a_b], \
                   [v[1] for v in Tab_b_a], [v[2] for v in Tab_a_b], [v[2] for v in Tab_b_a])            
            val_msize_rssi_lqi[msize] = val
            
            Tab_a_b = RD.read_prr(base_dir, a_link[0], a_link[1], msize, prefix)
            Tab_b_a = RD.read_prr(base_dir, a_link[1], a_link[0], msize, prefix)
            val = ([v[0] for v in Tab_a_b], [v[0] for v in Tab_b_a], [v[1] for v in Tab_a_b], [v[1] for v in Tab_b_a])            
            val_msize_prr[msize] = val
            
        data_rssi_lqi[a_link] = val_msize_rssi_lqi
        data_prr[a_link] = val_msize_prr
    
    all_x_rssi_lqi = []
    all_x_prr = []
    all_rssi = []
    all_lqi = []
    all_prr = []
    for a_link in data_rssi_lqi.keys():
        val_msize_rssi_lqi = data_rssi_lqi[a_link]
        val_msize_prr = data_prr[a_link]
        
        for msize in val_msize_rssi_lqi.keys():
            val_rssi_lqi = val_msize_rssi_lqi[msize]
            all_x_rssi_lqi += val_rssi_lqi[0] + val_rssi_lqi[1]
            all_rssi += val_rssi_lqi[2] + val_rssi_lqi[3]
            all_lqi += val_rssi_lqi[4] + val_rssi_lqi[5]
            
            val_prr = val_msize_prr[msize]
            all_x_prr += val_prr[0] + val_prr[1]
            all_prr += val_prr[2] + val_prr[3]
            
    min_x_rssi_lqi = np.nanmin(all_x_rssi_lqi)
    max_x_rssi_lqi = np.nanmax(all_x_rssi_lqi)
    if max_x_rssi_lqi < 10:
        xticslabels_rssi_lqi = None
    else:
        deb = int(math.ceil(float(min_x_rssi_lqi)/10)*10)
        step = float(max_x_rssi_lqi - min_x_rssi_lqi)/10.0
        step_dix = int(math.ceil(float(step)/10)*10)                        
        xticslabels_rssi_lqi = range(deb, int(max_x_rssi_lqi), step_dix)

    min_x_prr = np.nanmin(all_x_rssi_lqi)
    max_x_prr = np.nanmax(all_x_rssi_lqi)
    if max_x_prr < 10:
        xticslabels_prr = None
    else:
        deb = int(math.ceil(float(min_x_prr)/10)*10)
        step = float(max_x_prr - min_x_prr)/10.0
        step_dix = int(math.ceil(float(step)/10)*10)                        
        xticslabels_prr = range(deb, int(max_x_prr), step_dix)
    
    min_rssi = np.nanmin(all_rssi) - 0.5
    max_rssi = np.nanmax(all_rssi) + 0.5
    
    min_lqi = np.nanmin(all_lqi) - 0.5
    max_lqi = np.nanmax(all_lqi) + 0.5
    
    min_prr = np.nanmin(all_prr)
    max_prr = np.nanmax(all_prr) + 0.02
    
    x_int = 1
    stic_x = None
    legend_title = ''
    xlabel = 'Time(s)'
    title = ''
    for a_link in data_rssi_lqi.keys():
        a = a_link[0]
        b = a_link[1]
        x_rssi_lqi = []
        x_prr = []
        y_rssi = []
        y_lqi = []
        y_prr = []
        legends = []
        val_msize_rssi_lqi = data_rssi_lqi[a_link]
        val_msize_prr = data_prr[a_link]
        
        for msize in val_msize_rssi_lqi.keys():            
            legends.append(str(msize) + 'B: ' + str(a) + ' --> ' + str(b))
            legends.append(str(msize) + 'B: ' + str(b) + ' --> ' + str(a))

            val_rssi_lqi = val_msize_rssi_lqi[msize]            
            x_rssi_lqi.append(val_rssi_lqi[0])
            x_rssi_lqi.append(val_rssi_lqi[1])

            y_rssi.append(val_rssi_lqi[2])
            y_rssi.append(val_rssi_lqi[3])
            
            y_lqi.append(val_rssi_lqi[4])
            y_lqi.append(val_rssi_lqi[5])

            val_prr = val_msize_prr[msize]            
            x_prr.append(val_prr[0])
            x_prr.append(val_prr[1])

            y_prr.append(val_prr[2])
            y_prr.append(val_prr[3])
        
        y_int = 1
        stic_y = None
        ylabel = 'RSSI(dBm)'
        image_fname = image_rep + '/RSSI_' + str(a) + "_" + str(b) + '_PKTSIZE.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(x_rssi_lqi, y_rssi, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_x_rssi_lqi, max_x_rssi_lqi, min_rssi, max_rssi, stic_x, stic_y, xticslabels_rssi_lqi)
    
        ylabel = 'LQI'
        image_fname = image_rep + '/LQI_' + str(a) + "_" + str(b) + '_PKTSIZE.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(x_rssi_lqi, y_lqi, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_x_rssi_lqi, max_x_rssi_lqi, min_lqi, max_lqi, stic_x, stic_y, xticslabels_rssi_lqi)
    
        y_int = 0
        stic_y = 0.1
        ylabel = 'PRR'
        image_fname = image_rep + '/PRR_' + str(a) + '_' + str(b) + '_PKTSIZE.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(x_prr, y_prr, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_x_prr, max_x_prr, min_prr, max_prr, stic_x, stic_y, xticslabels_prr, y_decimal=1)
    
    msize_List = [2, 42, 82]        
    """
    RSSI, LQI and PRR PDF for some distances
    """
    """
    READ_DATA From File
    data = {distance: {msize: (prr_vals, prr_pdf, rssi_vals, rssi_pdf, lqi_vals, lqi_pdf)}}
    """ 
    distances = link_len       
    data = dict()
    for a_dist in distances:
        val_msizes = dict()
        for msize in msize_List:            
            prr_pdf = RD.read_pdf_or_cdf_distance(base_dir, 'PDF', 'PRR', msize, a_dist, prefix)
            rssi_pdf = RD.read_pdf_or_cdf_distance(base_dir, 'PDF', 'RSSI', msize, a_dist, prefix)
            lqi_pdf = RD.read_pdf_or_cdf_distance(base_dir, 'PDF', 'LQI', msize, a_dist, prefix)
            
            val = ([v[0] for v in prr_pdf], [v[1] for v in prr_pdf], [v[0] for v in rssi_pdf], \
                   [v[1] for v in rssi_pdf], [v[0] for v in lqi_pdf], [v[1] for v in lqi_pdf])            
            val_msizes[msize] = val    
                                
        data[a_dist] = val_msizes
    
    data_all_links = dict()
    for msize in msize_List:
        prr_pdf_all_links = RD.read_pdf_or_cdf_distance(base_dir, 'PDF', 'PRR', msize, None, prefix)
        rssi_pdf_all_links = RD.read_pdf_or_cdf_distance(base_dir, 'PDF', 'RSSI', msize, None, prefix)
        
        val = ([v[0] for v in prr_pdf_all_links], [v[1] for v in prr_pdf_all_links], \
               [v[0] for v in rssi_pdf_all_links],[v[1] for v in rssi_pdf_all_links])
        
        data_all_links[msize] = val
    
    all_prr = []
    all_rssi = []
    all_lqi = []
    all_pdf_prr = []
    all_pdf_rssi = []
    all_pdf_lqi = []
    for a_dist in data.keys():
        val_msizes = data[a_dist]        
        for msize in val_msizes.keys():
            val = val_msizes[msize]
            val_all_links = data_all_links[msize]
            
            all_prr += val[0] + val_all_links[0]
            all_rssi += val[2] + val_all_links[2]
            all_lqi += val[4]
            
            all_pdf_prr += val[1] + val_all_links[1]
            all_pdf_rssi += val[3] + val_all_links[3]
            all_pdf_lqi += val[5]
                    
    maxpdfprr = max(all_pdf_prr) + 0.02 
    maxpdfrssi = max(all_pdf_rssi) + 0.02
    maxpdflqi = max(all_pdf_lqi) + 0.02
    
    min_rssi = min(all_rssi)
    max_rssi = max(all_rssi) + 0.5
    
    min_lqi =  min(all_lqi)
    max_lqi = max(all_lqi) + 0.5
    
    #min_prr = min(all_prr)
    min_prr = 0
    #max_prr = max(all_prr) + 0.02
    max_prr = 1.02
    
    legend_title = 'Payload'
    title = ''
    ylabel = 'PDF'
    y_int = 0
    stic_y = 0.1
    xticslabels = None    
    for a_dist in data.keys():
        rssis = []
        lqis = []
        prrs = []
        pdf_prr = []
        pdf_rssi = []
        pdf_lqi = []
        legends = []
        
        val_msizes = data[a_dist]
        lmsize = val_msizes.keys()
        lmsize = sorted(lmsize, reverse=True)
        for msize in lmsize: 
            val = val_msizes[msize]           
            legends.append(str(msize) + ' B')

            prrs.append(val[0])
            rssis.append(val[2])
            lqis.append(val[4])

            pdf_prr.append(val[1])
            pdf_rssi.append(val[3])
            pdf_lqi.append(val[5])
            
        x_int = 0
        stic_x = 0.1
        xlabel = 'Packet reception ratio'
        image_fname = image_rep + '/PDF_PRR_PKTSIZE_' + str(a_dist) + 'M.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(prrs, pdf_prr, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_prr, max_prr, 0.0, maxpdfprr, stic_x, stic_y, xticslabels, y_decimal=1, x_decimal=1)
    
        x_int = 1
        stic_x = None
        xlabel = 'RSSI(dBm)'
        image_fname = image_rep + '/PDF_RSSI_PKTSIZE_' + str(a_dist) + 'M.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(rssis, pdf_rssi, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_rssi, max_rssi, 0.0, maxpdfrssi, stic_x, stic_y, xticslabels,y_decimal=1)
    
        x_int = 1
        stic_x = None
        xlabel = 'LQI'
        image_fname = image_rep + '/PDF_LQI_PKTSIZE_' + str(a_dist) + 'M.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(lqis, pdf_lqi, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_lqi, max_lqi, 0.0, maxpdflqi, stic_x, stic_y, xticslabels,y_decimal=1)
        
    prrs = []
    rssis = []
    pdf_prr = []
    pdf_rssi = []
    legends = []
    
    lmsize = data_all_links.keys()    
    lmsize = sorted(lmsize, reverse=True)    
    for msize in lmsize: 
        val = data_all_links[msize]           
        legends.append(str(msize) + ' B')

        prrs.append(val[0])
        rssis.append(val[2])

        pdf_prr.append(val[1])
        pdf_rssi.append(val[3])
        
    x_int = 0
    stic_x = 0.1
    xlabel = 'Packet reception ratio'
    image_fname = image_rep + '/PDF_PRR_PKTSIZE_ALL_LINKS.eps'       
    plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(prrs, pdf_prr, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                x_int, y_int, 0, min_prr, max_prr, 0.0, maxpdfprr, stic_x, stic_y, xticslabels,y_decimal=1,x_decimal=1)

    x_int = 1
    stic_x = None
    xlabel = 'RSSI(dBm)'
    image_fname = image_rep + '/PDF_RSSI_PKTSIZE_ALL_LINKS.eps'       
    plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(rssis, pdf_rssi, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                x_int, y_int, 0, min_rssi, max_rssi, 0.0, maxpdfrssi, stic_x, stic_y, xticslabels,y_decimal=1)
    
    
    """
    RSSI, LQI and PRR CDF for some distances and for All Links
    READ_DATA From File
    data = {distance: {msize: (prr_vals, prr_cdf, rssi_vals, rssi_cdf)}}
    """ 
    distances = link_len       
    data = dict()
    for a_dist in distances:
        val_msizes = dict()
        for msize in msize_List:            
            prr_cdf = RD.read_pdf_or_cdf_distance(base_dir, 'CDF', 'PRR', msize, a_dist, prefix)
            rssi_cdf = RD.read_pdf_or_cdf_distance(base_dir, 'CDF', 'RSSI', msize, a_dist, prefix)
            
            val = ([v[0] for v in prr_cdf], [v[1] for v in prr_cdf], [v[0] for v in rssi_cdf], \
                   [v[1] for v in rssi_cdf])            
            val_msizes[msize] = val    
                                
        data[a_dist] = val_msizes
    
    data_all_links = dict()
    for msize in msize_List:
        prr_cdf_all_links = RD.read_pdf_or_cdf_distance(base_dir, 'CDF', 'PRR', msize, None, prefix)
        rssi_cdf_all_links = RD.read_pdf_or_cdf_distance(base_dir, 'CDF', 'RSSI', msize, None, prefix)
        
        val = ([v[0] for v in prr_cdf_all_links], [v[1] for v in prr_cdf_all_links], \
               [v[0] for v in rssi_cdf_all_links],[v[1] for v in rssi_cdf_all_links])
        
        data_all_links[msize] = val
    
    all_prr = []
    all_rssi = []
    all_cdf_prr = []
    all_cdf_rssi = []
    for a_dist in data.keys():
        val_msizes = data[a_dist]        
        for msize in val_msizes.keys():
            val = val_msizes[msize]
            val_all_links = val_msizes[msize]
            
            all_prr += val[0] + val_all_links[0]
            all_rssi += val[2] + val_all_links[2]
            
            all_cdf_prr += val[1] + val_all_links[1]
            all_cdf_rssi += val[3] + val_all_links[3]
                    
    maxcdfprr = max(all_cdf_prr) + 0.02    
    maxcdfrssi = max(all_cdf_rssi) + 0.02
    
    min_rssi = min(all_rssi)
    max_rssi = max(all_rssi) + 0.5
    
    min_prr = min(all_prr)
    max_prr = max(all_prr) + 0.02
    
    legend_title = 'Payload'
    title = ''
    ylabel = 'CDF'
    y_int = 0
    stic_y = 0.1
    xticslabels = None
    
    for a_dist in data.keys():
        rssis = []
        prrs = []
        cdf_prr = []
        cdf_rssi = []
        legends = []
        
        val_msizes = data[a_dist]
        lmsize = val_msizes.keys()    
        lmsize = sorted(lmsize, reverse=True)    
        for msize in lmsize: 
            val = val_msizes[msize]           
            legends.append(str(msize) + ' B')

            prrs.append(val[0])
            rssis.append(val[2])

            cdf_prr.append(val[1])
            cdf_rssi.append(val[3])

        x_int = 0
        stic_x = 0.1
        xlabel = 'Packet reception ratio'
        image_fname = image_rep + '/CDF_PRR_PKTSIZE_' + str(a_dist) + 'M.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(prrs, cdf_prr, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_prr, max_prr, 0.0, maxcdfprr, stic_x, stic_y, xticslabels,x_decimal=1, y_decimal=1)
        
        x_int = 1
        stic_x = None
        xlabel = 'RSSI(dBm)'
        image_fname = image_rep + '/CDF_RSSI_PKTSIZE_' + str(a_dist) + 'M.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(rssis, cdf_rssi, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_rssi, max_rssi, 0.0, maxcdfrssi, stic_x, stic_y, xticslabels,y_decimal=1)
        
    prrs = []
    rssis = []
    cdf_prr = []
    cdf_rssi = []
    legends = []    
    lmsize = data_all_links.keys()    
    lmsize = sorted(lmsize, reverse=True)    
    for msize in lmsize: 
        val = data_all_links[msize]           
        legends.append(str(msize) + ' B')

        prrs.append(val[0])
        rssis.append(val[2])

        cdf_prr.append(val[1])
        cdf_rssi.append(val[3])
    
     
    x_int = 0
    stic_x = 0.1
    xlabel = 'Packet reception ratio'
    image_fname = image_rep + '/CDF_PRR_PKTSIZE_ALL_LINKS.eps'       
    plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(prrs, cdf_prr, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                x_int, y_int, 0, min_prr, max_prr, 0.0, maxcdfprr, stic_x, stic_y, xticslabels,x_decimal=1,y_decimal=1)

    x_int = 1
    stic_x = None
    xlabel = 'RSSI(dBm)'
    image_fname = image_rep + '/CDF_RSSI_PKTSIZE_ALL_LINKS.eps'       
    plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(rssis, cdf_rssi, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                x_int, y_int, 0, min_rssi, max_rssi, 0.0, maxcdfrssi, stic_x, stic_y, xticslabels,y_decimal=1)
    
    
    """
    For different msize level, all the RSSI and PRR values versus distance
    data = {msize : (distance_rssi[], rssi_values[], distance_prr[], prr_values[])}
    """
    
    all_rssi = []
    all_distance = []
    data = dict()    
    for msize in msize_List:
        tab_rssi = RD.read_all_distrib_power_or_msize(base_dir, 'RSSI', msize, prefix)
        tab_prr = RD.read_all_distrib_power_or_msize(base_dir, 'PRR', msize, prefix)
        
        all_prr += [v[1] for v in tab_prr]
        all_rssi += [v[1] for v in tab_rssi]
        all_distance += [v[0] for v in tab_rssi]+[v[0] for v in tab_prr]
        
        val = ([v[0] for v in tab_rssi], [v[1] for v in tab_rssi],\
               [v[0] for v in tab_prr], [v[1] for v in tab_prr])
        
        data[msize] = val
    
    
    min_prr = 0
    max_prr = 1.02
    
    min_rssi = np.nanmin(all_rssi) - 0.5
    max_rssi = np.nanmax(all_rssi) + 0.5
    
    min_distance = np.nanmin(all_distance) - 0.5
    max_distance = np.nanmax(all_distance) - 0.5
    
    legend_title = ''
    stic_x = None
    x_int = 1
    xlabel = 'Distance (m)'  
    rr = set(all_distance)
    xticslabels = [a for a in rr]
    for msize in msize_List:        
        val = data[msize]
        
        y_int = 1
        xx = val[0]
        yy = val[1]        
        stic_y = (max_rssi - min_rssi)/5
        ylabel = 'RSSI(dBm)'
        titre = 'RSSI(dBm) vs Distance'    
        image_fname = image_rep + '/RSSI_DISTANCE_PKTSIZE_' + str(msize) + 'dBm.eps' 
        plot.plotScatter(xx, yy, xlabel, ylabel, image_fname, titre, min_distance, max_distance, min_rssi, max_rssi, stic_x, stic_y, \
                         xticslabels, x_int, y_int)
    
        y_int = 0
        xx = val[2]
        yy = val[3]        
        stic_y = 0.1
        ylabel = 'Packet reception ratio'    
        titre = 'PRR vs Distance'    
        image_fname = image_rep + '/PRR_DISTANCE_PKTSIZE_' + str(msize) + 'dBm.eps' 
        plot.plotScatter(xx, yy, xlabel, ylabel, image_fname, titre, min_distance, max_distance, min_prr, max_prr, stic_x, stic_y, \
                         xticslabels, x_int, y_int,y_decimal=1)
    
    
    """
    Distribution (CDF) of the link assymetri
    data = {msize : (rssi[], rssi_cdf[], prr[], prr_cdf[])}
    """
    all_ass_rssi = []
    all_ass_prr = []
    data = dict()    
    for msize in msize_List:
        tab_rssi = RD.read_cdf_ass_power_or_msize(base_dir, 'RSSI', msize, prefix)
        tab_prr = RD.read_cdf_ass_power_or_msize(base_dir, 'PRR', msize, prefix)
        
        all_ass_prr += [v[0] for v in tab_prr]
        all_ass_rssi += [v[0] for v in tab_rssi]
        
        val = ([v[0] for v in tab_rssi], [v[1] for v in tab_rssi],\
               [v[0] for v in tab_prr], [v[1] for v in tab_prr])
        
        data[msize] = val
    
    #print base_dir
    #print all_ass_prr
    min_ass_prr = np.nanmin(all_ass_prr)
    max_ass_prr = np.nanmax(all_ass_prr) + 0.2
    
    min_ass_rssi = np.nanmin(all_ass_rssi) - 0.5
    max_ass_rssi = np.nanmax(all_ass_rssi) + 0.5

    min_y = 0
    max_y = 1.02    
    y_int = 0
    stic_y = 0.1
    ylabel = 'CDF'
    
    xticslabels = None
    legend_title = 'Payload'
    xx_ass_rssi = []
    xx_ass_prr = []
    
    ass_rssi = []
    ass_prr = []
    legends = []
    for msize in msize_List:        
        val = data[msize]
        
        xx_ass_rssi.append(val[0])
        ass_rssi.append(val[1])

        xx_ass_prr.append(val[2])
        ass_prr.append(val[3])
        
        legends.append(str(msize) + ' B')
        
    x_int = 1
    stic_x = (max_ass_rssi - min_ass_rssi)/5
    xlabel = r'$|RSSI_{AB} - RSSI_{BA}|$'
    titre = ''    
    image_fname = image_rep + '/CDF_ASS_RSSI_PKTSIZE.eps' 
    plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(xx_ass_rssi, ass_rssi, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                            x_int, y_int, 0, min_ass_rssi, max_ass_rssi, min_y, max_y, stic_x, stic_y, xticslabels,y_decimal=1)

    x_int = 0
    stic_x = (max_ass_prr - min_ass_prr)/5 
    xlabel = r'$|PRR_{AB} - PRR_{BA}|$'
    titre = ''    
    image_fname = image_rep + '/CDF_ASS_PRR_PKTSIZE.eps' 
    plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(xx_ass_prr, ass_prr, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                            x_int, y_int, 0, min_ass_prr, max_ass_prr, min_y, max_y, stic_x, stic_y, xticslabels,y_decimal=1)
    

    """
    Links definition
    """
    msize_List = [2, 42, 82]        
    
    data_poor = dict()    
    data_intermediate = dict()    
    data_good = dict()    
    for msize in msize_List:
        #prr_def = RD.read_prr_def(base_dir, msize, prefix)
        prr_def = RD.read_prr_def_with_ci(base_dir, msize, prefix)
        
        data_poor[msize] = prr_def[0]
        data_intermediate[msize] = prr_def[1]
        data_good[msize] = prr_def[2]
    
    msize_List.sort()
    
    xx = [msize_List, msize_List, msize_List]
    #yy = [[data_poor[channel] for channel in msize_List], [data_intermediate[channel] for channel in msize_List], [data_good[channel] for channel in msize_List]]
    yy = [[data_poor[ms][0] for ms in msize_List], [data_intermediate[ms][0] for ms in msize_List], [data_good[ms][0] for ms in msize_List]]
    yy_error = [[data_poor[ms][1] for ms in msize_List], [data_intermediate[ms][1] for ms in msize_List], [data_good[ms][1] for ms in msize_List]]
    xticslabels = msize_List
    
    xlabel = 'Message size (Byte)'
    ylabel = 'Links (%)'
    titre = ''
    legends = ['Poor', 'Intermediate', 'Good']
    legend_title = 'Link quality'
    
    min_y = 0
    #max_y = max([max(v) for v in yy])
    max_y = 100
    stic_y = None
        
    image_fname = image_rep + '/LINK_PRR_DEF_PKTSIZE.eps' 
    plot.PlotBar(xx, yy, yy_error, xlabel, ylabel, titre, image_fname, legends, legend_title, min_y, max_y, stic_y, 2, xticslabels)
    