import Read_Data as RD
import math

import PlotFunction as plot
import numpy as np


def plot_curve(base_dir_ground, base_dir_heigth, image_rep, msize_or_power, prefix):
    """
    RSSI, LQI and PRR Value for some links for different power level
    """
    
    """
    READ_DATA From File
    data = {couple: {gh: (x_a_b[], x_b_a[], rssi_a_b[], rssi_b_a[], lqi_a_b[], lqi_b_a[])}}
    """ 
    links = [(1,2), (1,3), (1,4), (2,4), (3,4)]       
    data_rssi_lqi = dict()
    data_prr = dict()
    for a_link in links:
        val_GH_rssi_lqi = dict()        
        Tab_a_b = RD.read_rssi_lqi(base_dir_ground, a_link[0], a_link[1], msize_or_power, prefix)
        Tab_b_a = RD.read_rssi_lqi(base_dir_ground, a_link[1], a_link[0], msize_or_power, prefix)
        val = ([v[0] for v in Tab_a_b], [v[0] for v in Tab_b_a], [v[1] for v in Tab_a_b], \
               [v[1] for v in Tab_b_a], [v[2] for v in Tab_a_b], [v[2] for v in Tab_b_a])            
        val_GH_rssi_lqi['G'] = val
        
        Tab_a_b = RD.read_rssi_lqi(base_dir_heigth, a_link[0], a_link[1], msize_or_power, prefix)
        Tab_b_a = RD.read_rssi_lqi(base_dir_heigth, a_link[1], a_link[0], msize_or_power, prefix)
        val = ([v[0] for v in Tab_a_b], [v[0] for v in Tab_b_a], [v[1] for v in Tab_a_b], \
               [v[1] for v in Tab_b_a], [v[2] for v in Tab_a_b], [v[2] for v in Tab_b_a])            
        val_GH_rssi_lqi['H'] = val
        
        val_GH_prr = dict()
        Tab_a_b = RD.read_prr(base_dir_ground, a_link[0], a_link[1], msize_or_power, prefix)
        Tab_b_a = RD.read_prr(base_dir_ground, a_link[1], a_link[0], msize_or_power, prefix)
        val = ([v[0] for v in Tab_a_b], [v[0] for v in Tab_b_a], [v[1] for v in Tab_a_b], [v[1] for v in Tab_b_a])            
        val_GH_prr['G'] = val
        
        Tab_a_b = RD.read_prr(base_dir_heigth, a_link[0], a_link[1], msize_or_power, prefix)
        Tab_b_a = RD.read_prr(base_dir_heigth, a_link[1], a_link[0], msize_or_power, prefix)
        val = ([v[0] for v in Tab_a_b], [v[0] for v in Tab_b_a], [v[1] for v in Tab_a_b], [v[1] for v in Tab_b_a])            
        val_GH_prr['H'] = val
                    
        data_rssi_lqi[a_link] = val_GH_rssi_lqi
        data_prr[a_link] = val_GH_prr
    
    all_x_rssi_lqi = []
    all_x_prr = []
    all_rssi = []
    all_lqi = []
    all_prr = []
    for a_link in data_rssi_lqi.keys():
        val_GH_rssi_lqi = data_rssi_lqi[a_link]
        val_GH_prr = data_prr[a_link]
        
        for gh in val_GH_rssi_lqi.keys():
            val_rssi_lqi = val_GH_rssi_lqi[gh]
            all_x_rssi_lqi += val_rssi_lqi[0] + val_rssi_lqi[1]
            all_rssi += val_rssi_lqi[2] + val_rssi_lqi[3]
            all_lqi += val_rssi_lqi[4] + val_rssi_lqi[5]
            
            val_prr = val_GH_prr[gh]
            all_x_prr += val_prr[0] + val_prr[1]
            all_prr += val_prr[2] + val_prr[3]
            
    min_x_rssi_lqi = np.nanmin(all_x_rssi_lqi)
    max_x_rssi_lqi = np.nanmax(all_x_rssi_lqi)
    if max_x_rssi_lqi < 10:
        xticslabels_rssi_lqi = None
    else:
        deb = int(math.ceil(float(min_x_rssi_lqi)/10)*10)
        step = float(max_x_rssi_lqi - min_x_rssi_lqi)/10.0
        step_dix = int(math.ceil(float(step)/10)*10)                        
        xticslabels_rssi_lqi = range(deb, int(max_x_rssi_lqi), step_dix)

    min_x_prr = np.nanmin(all_x_rssi_lqi)
    max_x_prr = np.nanmax(all_x_rssi_lqi)
    if max_x_prr < 10:
        xticslabels_prr = None
    else:
        deb = int(math.ceil(float(min_x_prr)/10)*10)
        step = float(max_x_prr - min_x_prr)/10.0
        step_dix = int(math.ceil(float(step)/10)*10)                        
        xticslabels_prr = range(deb, int(max_x_prr), step_dix)
    
    min_rssi = np.nanmin(all_rssi) - 0.5
    max_rssi = np.nanmax(all_rssi) + 0.5
    
    min_lqi = np.nanmin(all_lqi) - 0.5
    max_lqi = np.nanmax(all_lqi) + 0.5
    
    min_prr = np.nanmin(all_prr)
    max_prr = np.nanmax(all_prr) + 0.02
    
    #print min_rssi, max_rssi, min_lqi, max_lqi
    x_int = 1
    stic_x = None
    legend_title = ''
    xlabel = 'Time(s)'
    title = ''
    for a_link in data_rssi_lqi.keys():
        a = a_link[0]
        b = a_link[1]
        x_rssi_lqi = []
        x_prr = []
        y_rssi = []
        y_lqi = []
        y_prr = []
        legends = []
        val_GH_rssi_lqi = data_rssi_lqi[a_link]
        val_GH_prr = data_prr[a_link]
        
        for gh in val_GH_rssi_lqi.keys():
            if gh == 'G':           
                legends.append('Ground: ' + str(a) + ' --> ' + str(b))
                legends.append('Ground: ' + str(b) + ' --> ' + str(a))
            else:
                legends.append('Height: ' + str(a) + ' --> ' + str(b))
                legends.append('Height: ' + str(b) + ' --> ' + str(a))
                
            val_rssi_lqi = val_GH_rssi_lqi[gh]            
            x_rssi_lqi.append(val_rssi_lqi[0])
            x_rssi_lqi.append(val_rssi_lqi[1])

            y_rssi.append(val_rssi_lqi[2])
            y_rssi.append(val_rssi_lqi[3])
            
            y_lqi.append(val_rssi_lqi[4])
            y_lqi.append(val_rssi_lqi[5])

            val_prr = val_GH_prr[gh]            
            x_prr.append(val_prr[0])
            x_prr.append(val_prr[1])

            y_prr.append(val_prr[2])
            y_prr.append(val_prr[3])
        
        max_x_rssi_lqi = max_x_prr = 80
        y_int = 1
        stic_y = None
        ylabel = 'RSSI(dBm)'
        image_fname = image_rep + '/RSSI_' + str(a) + "_" + str(b) + '_GROUND_HEIGTH.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(x_rssi_lqi, y_rssi, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_x_rssi_lqi, max_x_rssi_lqi, min_rssi, max_rssi, stic_x, stic_y, xticslabels_rssi_lqi)
    
        ylabel = 'LQI'
        image_fname = image_rep + '/LQI_' + str(a) + "_" + str(b) + '_GROUND_HEIGTH.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(x_rssi_lqi, y_lqi, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_x_rssi_lqi, max_x_rssi_lqi, min_lqi, max_lqi, stic_x, stic_y, xticslabels_rssi_lqi)
    
        y_int = 0
        stic_y = 0.1
        ylabel = 'PRR'
        image_fname = image_rep + '/PRR_' + str(a) + '_' + str(b) + '_GROUND_HEIGTH.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(x_prr, y_prr, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_x_prr, max_x_prr, min_prr, max_prr, stic_x, stic_y, xticslabels_prr,y_decimal=1)

    """
    RSSI, LQI and PRR PDF for some distances
    """
    """
    READ_DATA From File
    data = {distance: {gh: (prr_vals, prr_pdf, rssi_vals, rssi_pdf, lqi_vals, lqi_pdf)}}
    """ 
    distances = [3, 6, 9, 12]       
    data = dict()
    for a_dist in distances:
        val_GH = dict()
        prr_pdf = RD.read_pdf_or_cdf_distance(base_dir_ground, 'PDF', 'PRR', msize_or_power, a_dist, prefix)
        rssi_pdf = RD.read_pdf_or_cdf_distance(base_dir_ground, 'PDF', 'RSSI', msize_or_power, a_dist, prefix)
        lqi_pdf = RD.read_pdf_or_cdf_distance(base_dir_ground, 'PDF', 'LQI', msize_or_power, a_dist, prefix)
        
        val = ([v[0] for v in prr_pdf], [v[1] for v in prr_pdf], [v[0] for v in rssi_pdf], \
               [v[1] for v in rssi_pdf], [v[0] for v in lqi_pdf], [v[1] for v in lqi_pdf])            
        val_GH['G'] = val    
                                
        prr_pdf = RD.read_pdf_or_cdf_distance(base_dir_heigth, 'PDF', 'PRR', msize_or_power, a_dist, prefix)
        rssi_pdf = RD.read_pdf_or_cdf_distance(base_dir_heigth, 'PDF', 'RSSI', msize_or_power, a_dist, prefix)
        lqi_pdf = RD.read_pdf_or_cdf_distance(base_dir_heigth, 'PDF', 'LQI', msize_or_power, a_dist, prefix)
        
        val = ([v[0] for v in prr_pdf], [v[1] for v in prr_pdf], [v[0] for v in rssi_pdf], \
               [v[1] for v in rssi_pdf], [v[0] for v in lqi_pdf], [v[1] for v in lqi_pdf])            
        val_GH['H'] = val    

        data[a_dist] = val_GH
    
    data_all_links = dict()
    prr_pdf_all_links = RD.read_pdf_or_cdf_distance(base_dir_ground, 'PDF', 'PRR', msize_or_power, None, prefix)
    rssi_pdf_all_links = RD.read_pdf_or_cdf_distance(base_dir_ground, 'PDF', 'RSSI', msize_or_power, None, prefix)
    val = ([v[0] for v in prr_pdf_all_links], [v[1] for v in prr_pdf_all_links], \
           [v[0] for v in rssi_pdf_all_links],[v[1] for v in rssi_pdf_all_links])
    data_all_links['G'] = val

    prr_pdf_all_links = RD.read_pdf_or_cdf_distance(base_dir_heigth, 'PDF', 'PRR', msize_or_power, None, prefix)
    rssi_pdf_all_links = RD.read_pdf_or_cdf_distance(base_dir_heigth, 'PDF', 'RSSI', msize_or_power, None, prefix)
    val = ([v[0] for v in prr_pdf_all_links], [v[1] for v in prr_pdf_all_links], \
           [v[0] for v in rssi_pdf_all_links],[v[1] for v in rssi_pdf_all_links])
    data_all_links['H'] = val
    
    all_prr = []
    all_rssi = []
    all_lqi = []
    all_pdf_prr = []
    all_pdf_rssi = []
    all_pdf_lqi = []
    for a_dist in data.keys():
        val_GH = data[a_dist]        
        for gh in val_GH.keys():
            val = val_GH[gh]
            val_all_links = data_all_links[gh]
            
            all_prr += val[0] + val_all_links[0]
            all_rssi += val[2] + val_all_links[2]
            all_lqi += val[4]
            
            all_pdf_prr += val[1] + val_all_links[1]
            all_pdf_rssi += val[3] + val_all_links[3]
            all_pdf_lqi += val[5]
                    
    maxpdfprr = max(all_pdf_prr) + 0.02 
    maxpdfrssi = max(all_pdf_rssi) + 0.02
    maxpdflqi = max(all_pdf_lqi) + 0.02
    
    min_rssi = min(all_rssi)
    max_rssi = max(all_rssi) + 0.5
    
    min_lqi =  min(all_lqi)
    max_lqi = max(all_lqi) + 0.5
    
    min_prr = min(all_prr)
    #min_prr = 0
    #max_prr = max(all_prr) + 0.02
    max_prr = 1.02
    
    legend_title = ''
    title = ''
    ylabel = 'PDF'
    y_int = 0
    stic_y = 0.1
    xticslabels = None    
    for a_dist in data.keys():
        rssis = []
        lqis = []
        prrs = []
        pdf_prr = []
        pdf_rssi = []
        pdf_lqi = []
        legends = []
        
        val_GH = data[a_dist]
        lgh = val_GH.keys()
        lgh = sorted(lgh, reverse=True)        
        for gh in lgh: 
            val = val_GH[gh]  
            if gh == 'G':           
                legends.append('Ground')
            else:
                legends.append('Height')

            prrs.append(val[0])
            rssis.append(val[2])
            lqis.append(val[4])

            pdf_prr.append(val[1])
            pdf_rssi.append(val[3])
            pdf_lqi.append(val[5])
            
        x_int = 0
        stic_x = 0.1
        xlabel = 'Packet reception ratio'
        image_fname = image_rep + '/PDF_PRR_GROUND_HEIGTH_' + str(a_dist) + 'M.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(prrs, pdf_prr, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_prr, max_prr, 0.0, maxpdfprr, stic_x, stic_y, xticslabels,x_decimal=1,y_decimal=1)
    
        x_int = 1
        stic_x = None
        xlabel = 'RSSI(dBm)'
        image_fname = image_rep + '/PDF_RSSI_GROUND_HEIGTH_' + str(a_dist) + 'M.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(rssis, pdf_rssi, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_rssi, max_rssi, 0.0, maxpdfrssi, stic_x, stic_y, xticslabels,y_decimal=1)
    
        x_int = 1
        stic_x = None
        xlabel = 'LQI'
        image_fname = image_rep + '/PDF_LQI_GROUND_HEIGTH_' + str(a_dist) + 'M.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(lqis, pdf_lqi, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_lqi, max_lqi, 0.0, maxpdflqi, stic_x, stic_y, xticslabels,y_decimal=1)
        
    prrs = []
    rssis = []
    pdf_prr = []
    pdf_rssi = []
    legends = []
    
    lgh = data_all_links.keys()    
    lgh = sorted(lgh, reverse=True)    
    for gh in lgh: 
        val = data_all_links[gh]           
        if gh == 'G':           
            legends.append('Ground')
        else:
            legends.append('Height')

        prrs.append(val[0])
        rssis.append(val[2])

        pdf_prr.append(val[1])
        pdf_rssi.append(val[3])
        
    x_int = 0
    stic_x = 0.1
    xlabel = 'Packet reception ratio'
    image_fname = image_rep + '/PDF_PRR_GROUND_HEIGTH_ALL_LINKS.eps'       
    plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(prrs, pdf_prr, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                x_int, y_int, 0, min_prr, max_prr, 0.0, maxpdfprr, stic_x, stic_y, xticslabels,x_decimal=1,y_decimal=1)

    x_int = 1
    stic_x = None
    xlabel = 'RSSI(dBm)'
    image_fname = image_rep + '/PDF_RSSI_GROUND_HEIGTH_ALL_LINKS.eps'       
    plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(rssis, pdf_rssi, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                x_int, y_int, 0, min_rssi, max_rssi, 0.0, maxpdfrssi, stic_x, stic_y, xticslabels,y_decimal=1)
    

    """
    RSSI, LQI and PRR CDF for some distances and for All Links
    READ_DATA From File
    data = {distance: {power: (prr_vals, prr_cdf, rssi_vals, rssi_cdf)}}
    """ 
    data = dict()
    for a_dist in distances:
        val_GH = dict()
        prr_cdf = RD.read_pdf_or_cdf_distance(base_dir_ground, 'CDF', 'PRR', msize_or_power, a_dist, prefix)
        rssi_cdf = RD.read_pdf_or_cdf_distance(base_dir_ground, 'CDF', 'RSSI', msize_or_power, a_dist, prefix)        
        val = ([v[0] for v in prr_cdf], [v[1] for v in prr_cdf], [v[0] for v in rssi_cdf], [v[1] for v in rssi_cdf])            
        val_GH['G'] = val    
                                
        prr_cdf = RD.read_pdf_or_cdf_distance(base_dir_heigth, 'CDF', 'PRR', msize_or_power, a_dist, prefix)
        rssi_cdf = RD.read_pdf_or_cdf_distance(base_dir_heigth, 'CDF', 'RSSI', msize_or_power, a_dist, prefix)        
        val = ([v[0] for v in prr_cdf], [v[1] for v in prr_cdf], [v[0] for v in rssi_cdf], [v[1] for v in rssi_cdf])            
        val_GH['H'] = val    

        data[a_dist] = val_GH
    
    data_all_links = dict()
    prr_cdf_all_links = RD.read_pdf_or_cdf_distance(base_dir_ground, 'CDF', 'PRR', msize_or_power, None, prefix)
    rssi_cdf_all_links = RD.read_pdf_or_cdf_distance(base_dir_ground, 'CDF', 'RSSI', msize_or_power, None, prefix)
    val = ([v[0] for v in prr_cdf_all_links], [v[1] for v in prr_cdf_all_links], \
           [v[0] for v in rssi_cdf_all_links],[v[1] for v in rssi_cdf_all_links])
    data_all_links['G'] = val

    prr_cdf_all_links = RD.read_pdf_or_cdf_distance(base_dir_heigth, 'CDF', 'PRR', msize_or_power, None, prefix)
    rssi_cdf_all_links = RD.read_pdf_or_cdf_distance(base_dir_heigth, 'CDF', 'RSSI', msize_or_power, None, prefix)
    val = ([v[0] for v in prr_cdf_all_links], [v[1] for v in prr_cdf_all_links], \
           [v[0] for v in rssi_cdf_all_links],[v[1] for v in rssi_cdf_all_links])
    data_all_links['H'] = val
    
    all_prr = []
    all_rssi = []
    all_cdf_prr = []
    all_cdf_rssi = []
    for a_dist in data.keys():
        val_GH = data[a_dist]        
        for gh in val_GH.keys():
            val = val_GH[gh]
            val_all_links = data_all_links[gh]
            
            all_prr += val[0] + val_all_links[0]
            all_rssi += val[2] + val_all_links[2]
            
            all_cdf_prr += val[1] + val_all_links[1]
            all_cdf_rssi += val[3] + val_all_links[3]
                    
    maxcdfprr = max(all_cdf_prr) + 0.02 
    maxcdfrssi = max(all_cdf_rssi) + 0.02
    
    min_rssi = min(all_rssi)
    max_rssi = max(all_rssi) + 0.5
    
    min_prr = min(all_prr)
    max_prr = max(all_prr) + 0.02
    
    legend_title = ''
    title = ''
    ylabel = 'CDF'
    y_int = 0
    stic_y = 0.1
    xticslabels = None    
    for a_dist in data.keys():
        rssis = []
        prrs = []
        cdf_prr = []
        cdf_rssi = []
        legends = []
        
        val_GH = data[a_dist]
        lgh = val_GH.keys()
        lgh = sorted(lgh, reverse=True)        
        for gh in lgh: 
            val = val_GH[gh]  
            if gh == 'G':           
                legends.append('Ground')
            else:
                legends.append('Height')

            prrs.append(val[0])
            rssis.append(val[2])

            cdf_prr.append(val[1])
            cdf_rssi.append(val[3])
            
        x_int = 0
        stic_x = 0.1
        xlabel = 'Packet reception ratio'
        image_fname = image_rep + '/CDF_PRR_GROUND_HEIGTH_' + str(a_dist) + 'M.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(prrs, cdf_prr, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_prr, max_prr, 0.0, maxcdfprr, stic_x, stic_y, xticslabels,x_decimal=1,y_decimal=1)
    
        x_int = 1
        stic_x = None
        xlabel = 'RSSI(dBm)'
        image_fname = image_rep + '/CDF_RSSI_GROUND_HEIGTH_' + str(a_dist) + 'M.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(rssis, cdf_rssi, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_rssi, max_rssi, 0.0, maxcdfrssi, stic_x, stic_y, xticslabels,y_decimal=1)
            
    prrs = []
    rssis = []
    cdf_prr = []
    cdf_rssi = []
    legends = []
    
    lgh = data_all_links.keys()    
    lgh = sorted(lgh, reverse=True)    
    for gh in lgh: 
        val = data_all_links[gh]           
        if gh == 'G':           
            legends.append('Ground')
        else:
            legends.append('Height')

        prrs.append(val[0])
        rssis.append(val[2])

        cdf_prr.append(val[1])
        cdf_rssi.append(val[3])
        
    x_int = 0
    stic_x = 0.1
    xlabel = 'Packet reception ratio'
    image_fname = image_rep + '/CDF_PRR_GROUND_HEIGTH_ALL_LINKS.eps'       
    plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(prrs, cdf_prr, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                x_int, y_int, 0, min_prr, max_prr, 0.0, maxcdfprr, stic_x, stic_y, xticslabels,x_decimal=1,y_decimal=1)

    x_int = 1
    stic_x = None
    xlabel = 'RSSI(dBm)'
    image_fname = image_rep + '/CDF_RSSI_GROUND_HEIGTH_ALL_LINKS.eps'       
    plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(rssis, cdf_rssi, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                x_int, y_int, 0, min_rssi, max_rssi, 0.0, maxcdfrssi, stic_x, stic_y, xticslabels,y_decimal=1)

    
    """
    For different deployment, all the RSSI and PRR values versus distance
    data = {gh : (distance_rssi[], rssi_values[], distance_prr[], prr_values[])}
    """
    
    all_rssi = []
    all_distance = []
    data = dict()    
    tab_rssi = RD.read_all_distrib_power_or_msize(base_dir_ground, 'RSSI', msize_or_power, prefix)
    tab_prr = RD.read_all_distrib_power_or_msize(base_dir_ground, 'PRR', msize_or_power, prefix)
    
    all_prr += [v[1] for v in tab_prr]
    all_rssi += [v[1] for v in tab_rssi]
    all_distance += [v[0] for v in tab_rssi]+[v[0] for v in tab_prr]
    
    val = ([v[0] for v in tab_rssi], [v[1] for v in tab_rssi],\
           [v[0] for v in tab_prr], [v[1] for v in tab_prr])    
    data['G'] = val
    
    tab_rssi = RD.read_all_distrib_power_or_msize(base_dir_heigth, 'RSSI', msize_or_power, prefix)
    tab_prr = RD.read_all_distrib_power_or_msize(base_dir_heigth, 'PRR', msize_or_power, prefix)
    
    all_prr += [v[1] for v in tab_prr]
    all_rssi += [v[1] for v in tab_rssi]
    all_distance += [v[0] for v in tab_rssi]+[v[0] for v in tab_prr]
    
    val = ([v[0] for v in tab_rssi], [v[1] for v in tab_rssi],\
           [v[0] for v in tab_prr], [v[1] for v in tab_prr])    
    data['H'] = val
        
    min_prr = 0
    max_prr = 1.02
    
    min_rssi = np.nanmin(all_rssi) - 0.5
    max_rssi = np.nanmax(all_rssi) + 0.5
    
    min_distance = np.nanmin(all_distance) - 0.5
    max_distance = np.nanmax(all_distance) - 0.5
    
    stic_x = None
    x_int = 1
    xlabel = 'Distance (m)'  
    rr = set(all_distance)
    xticslabels = [a for a in rr]
    for gh in data.keys():        
        val = data[gh]
        
        y_int = 1
        xx = val[0]
        yy = val[1]        
        stic_y = (max_rssi - min_rssi)/5
        ylabel = 'RSSI(dBm)'
        titre = 'RSSI(dBm) vs Distance'   
        if gh == 'G': 
            image_fname = image_rep + '/GROUND_HEIGTH_RSSI_DISTANCE_GROUND.eps' 
        else:
            image_fname = image_rep + '/GROUND_HEIGTH_RSSI_DISTANCE_HEIGTH.eps' 
        plot.plotScatter(xx, yy, xlabel, ylabel, image_fname, titre, min_distance, max_distance, min_rssi, max_rssi, stic_x, stic_y, \
                         xticslabels, x_int, y_int)
    
        y_int = 0
        xx = val[2]
        yy = val[3]        
        stic_y = 0.2
        ylabel = 'Packet reception ratio'    
        titre = 'PRR vs Distance'    
        if gh == 'G': 
            image_fname = image_rep + '/GROUND_HEIGTH_PRR_DISTANCE_GROUND.eps' 
        else:
            image_fname = image_rep + '/GROUND_HEIGTH_PRR_DISTANCE_HEIGTH.eps' 
        plot.plotScatter(xx, yy, xlabel, ylabel, image_fname, titre, min_distance, max_distance, min_prr, max_prr, stic_x, stic_y, \
                         xticslabels, x_int, y_int,y_decimal=1)
    
    
    """
    Distribution (CDF) of the link assymetri
    data = {gh : (rssi[], rssi_cdf[], prr[], prr_cdf[])}
    """
    
    all_ass_rssi = []
    all_ass_prr = []
    data = dict()    
    tab_rssi = RD.read_cdf_ass_power_or_msize(base_dir_ground, 'RSSI', msize_or_power, prefix)
    tab_prr = RD.read_cdf_ass_power_or_msize(base_dir_ground, 'PRR', msize_or_power, prefix)
    
    all_ass_prr += [v[0] for v in tab_prr]
    all_ass_rssi += [v[0] for v in tab_rssi]
    
    val = ([v[0] for v in tab_rssi], [v[1] for v in tab_rssi],\
           [v[0] for v in tab_prr], [v[1] for v in tab_prr])    
    data['G'] = val

    tab_rssi = RD.read_cdf_ass_power_or_msize(base_dir_heigth, 'RSSI', msize_or_power, prefix)
    tab_prr = RD.read_cdf_ass_power_or_msize(base_dir_heigth, 'PRR', msize_or_power, prefix)
    
    all_ass_prr += [v[0] for v in tab_prr]
    all_ass_rssi += [v[0] for v in tab_rssi]
    
    val = ([v[0] for v in tab_rssi], [v[1] for v in tab_rssi],\
           [v[0] for v in tab_prr], [v[1] for v in tab_prr])    
    data['H'] = val
    
        
    min_ass_prr = np.nanmin(all_ass_prr)
    max_ass_prr = np.nanmax(all_ass_prr) + 0.2
    
    min_ass_rssi = np.nanmin(all_ass_rssi) - 0.5
    max_ass_rssi = np.nanmax(all_ass_rssi) + 0.5

    min_y = 0
    max_y = 1.02    
    y_int = 0
    stic_y = 0.1
    ylabel = 'CDF'
    
    xticslabels = None
    
    legend_title = ''
    
    xx_ass_rssi = []
    xx_ass_prr = []
    
    ass_rssi = []
    ass_prr = []
    legends = []
    for gh in data.keys():        
        val = data[gh]
        
        xx_ass_rssi.append(val[0])
        ass_rssi.append(val[1])

        xx_ass_prr.append(val[2])
        ass_prr.append(val[3])
        
        if gh == 'G':           
            legends.append('Ground')
        else:
            legends.append('Height')
        
    x_int = 1
    stic_x = (max_ass_rssi - min_ass_rssi)/5
    #xlabel = r'$|RSSI_{AB} - RSSI_{BA}|$'
    xlabel = r'$asm_{AB}^{RSSI}$'
    titre = ''    
    image_fname = image_rep + '/CDF_ASS_RSSI_GROUND_HEIGTH.eps' 
    plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(xx_ass_rssi, ass_rssi, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                            x_int, y_int, 0, min_ass_rssi, max_ass_rssi, min_y, max_y, stic_x, stic_y, xticslabels,y_decimal=1)

    x_int = 0
    stic_x = (max_ass_prr - min_ass_prr)/5 
    #print stic_x   
    #xlabel = r'$|PRR_{AB} - PRR_{BA}|$'
    xlabel = r'$asm_{AB}^{PRR}$'
    titre = ''    
    image_fname = image_rep + '/CDF_ASS_PRR_GROUND_HEIGTH.eps' 
    plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(xx_ass_prr, ass_prr, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                            x_int, y_int, 0, min_ass_prr, max_ass_prr, min_y, max_y, stic_x, stic_y, xticslabels,y_decimal=1)
    
    
    """
    Link Definition
    """
    #link_def_ground = RD.read_prr_def(base_dir_ground, msize_or_power, prefix)
    #link_def_heigth = RD.read_prr_def(base_dir_heigth, msize_or_power, prefix)
    
    link_def_ground = RD.read_prr_def_with_ci(base_dir_ground, msize_or_power, prefix)
    link_def_heigth = RD.read_prr_def_with_ci(base_dir_heigth, msize_or_power, prefix)    
    if (link_def_ground[0] != None) and (link_def_heigth[0] != None):
        xx = [[1, 2], [1, 2], [1, 2]]
        #yy = [[link_def_ground[0], link_def_heigth[0]], [link_def_ground[1], link_def_heigth[1]], [link_def_ground[2], link_def_heigth[2]]]
        yy = [[link_def_ground[0][0], link_def_heigth[0][0]], [link_def_ground[1][0], link_def_heigth[1][0]], [link_def_ground[2][0], link_def_heigth[2][0]]]
        yy_error = [[link_def_ground[0][1], link_def_heigth[0][1]], [link_def_ground[1][1], link_def_heigth[1][1]], [link_def_ground[2][1], link_def_heigth[2][1]]]
        xticslabels = ['Ground', 'Height']
        
        #(x_datas, y_datas, y_errors, xlab, ylab, titre, image_fname, legends, legend_title, min_y, max_y, stic_y, o_legend=1, xticslabels=None)
        xlabel = 'Deployment'
        ylabel = 'Links (%)'
        titre = ''
        legends = ['Poor', 'Intermediate', 'Good']
        legend_title = 'Link quality'
        
        min_y = 0
        #max_y = max([max(v) for v in yy])
        max_y = 100
        stic_y = None
        #stic_y = (max_y - min_y)/5.0
            
        image_fname = image_rep + '/LINK_PRR_DEF_GROUND_HEIGTH.eps' 
        plot.PlotBar(xx, yy, yy_error, xlabel, ylabel, titre, image_fname, legends, legend_title, min_y, max_y, stic_y, 2, xticslabels)
        
