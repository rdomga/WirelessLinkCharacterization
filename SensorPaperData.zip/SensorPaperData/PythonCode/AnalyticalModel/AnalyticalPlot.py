
import PlotFunction as plot
from Functions import Read_Data as RED

import os


def plot_data(datadir, rep_emrirical_data, packet_size_byte, sigma, path_lost_expo):
    """
    All data points : RSSI and PRR : Scatter plot
    """
    
    """
    RSSI Firts
    """
    tab = []
    tab_dict_theo = dict()
    fname = datadir + '/RSSI_VAL_ANA.data'
    if os.path.isfile(fname) and os.access(fname, os.R_OK):
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            if len(data) != 2:
                continue 
            tab.append((float(data[0]), float(data[1])))
            
            vals = []
            if tab_dict_theo.has_key(float(data[0])):
                vals = tab_dict_theo[float(data[0])]
            vals.append(float(data[1]))
            tab_dict_theo[float(data[0])] = vals
            
        ifile.close()
    

    tab_dict_emp = dict()
    fname = rep_emrirical_data + '/ALL_DISTRIB_RSSI.data'
    if os.path.isfile(fname) and os.access(fname, os.R_OK):
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            if len(data) != 2:
                continue             
            vals = []
            if tab_dict_emp.has_key(float(data[0])):
                vals = tab_dict_emp[float(data[0])]
            vals.append(float(data[1]))
            tab_dict_emp[float(data[0])] = vals
            
        ifile.close()

    if len(data) != 0:
        tab = sorted(tab, key = lambda x: x[0])
        x_scatter = [val[0] for val in tab]                             
        y_scatter = [val[1] for val in tab]
        
        min_x = min(x_scatter) - 0.5
        max_x = max(x_scatter) + 0.5  
             
        min_y = min(y_scatter)
        max_y = max(y_scatter) + 0.5 
        
        stic_x = (max_x - min_x)/5.0
        stic_y = (max_y - min_y)/5.0
        
        xticInt = 1
        yticInt = 1        
        
        xticslabels = None
        
        xlab = 'Distance (m)'
        ylab = 'RSSI(dBm)'
        
        titre = 'RSSI distribution : Theoretical model\nPacket size = ' + str(packet_size_byte) + r', $\alpha$ =' + "{0:.2f}".format(path_lost_expo) + r' and $\sigma$ = ' + "{0:.2f}".format(sigma)        
        image_fname = datadir + '/RSSI_VAL_ANA.eps'                
        plot.plotScatter(x_scatter, y_scatter, xlab, ylab, image_fname, titre, min_x, max_x, min_y, max_y, stic_x, \
                    stic_y, xticslabels, xticInt, yticInt)
        
        labels = []
        datas = []
        
        list_keys = tab_dict_theo.keys()
        list_keys.sort()
        for dist in list_keys:
            labels.append(int(dist))
            datas.append(tab_dict_theo[dist])
        
        image_fname = datadir + '/STAT_THEO_RSSI.eps'
        plot.plot_box_plot(image_fname, datas, labels, xlab, ylab, titre)
        
        titre = 'RSSI distribution : Empirical values'
        ylab = 'RSSI'
        labels = []
        datas = []        
        list_keys = tab_dict_emp.keys()
        list_keys.sort()
        for dist in list_keys:
            labels.append(int(dist))
            datas.append(tab_dict_emp[dist])        
        image_fname = datadir + '/STAT_EMP_RSSI.eps'
        plot.plot_box_plot(image_fname, datas, labels, xlab, ylab, titre)
    
    """
    Then PRR
    """
    tab = []
    tab_dict = dict()
    fname = datadir + '/PRR_VAL_ANA.data'
    if os.path.isfile(fname) and os.access(fname, os.R_OK):
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            if len(data) != 2:
                continue 
            tab.append((float(data[0]), float(data[1])))

            vals = []
            if tab_dict.has_key(float(data[0])):
                vals = tab_dict[float(data[0])]
            vals.append(float(data[1]))
            tab_dict[float(data[0])] = vals
            
        ifile.close()
    
    tab_dict_emp = dict()
    fname = rep_emrirical_data + '/ALL_DISTRIB_PRR.data'
    if os.path.isfile(fname) and os.access(fname, os.R_OK):
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            if len(data) != 2:
                continue             
            vals = []
            if tab_dict_emp.has_key(float(data[0])):
                vals = tab_dict_emp[float(data[0])]
            vals.append(float(data[1]))
            tab_dict_emp[float(data[0])] = vals
            
        ifile.close()

    if len(data) != 0:
        tab = sorted(tab, key = lambda x: x[0])
        x_scatter = [val[0] for val in tab]                             
        y_scatter = [val[1] for val in tab]
        
        min_x = min(x_scatter) - 0.5
        max_x = max(x_scatter) + 0.5
               
        min_y = min(y_scatter)
        max_y = max(y_scatter) + 0.02
        
        stic_x = (max_x - min_x)/5.0
        stic_y = 0.1
        
        xticInt = 1
        yticInt = 0        
        
        xticslabels = None
        
        xlab = 'Distance (m)'
        ylab = 'PRR'
        "".format(path_lost_expo,".2")
        titre = 'PRR distribution : Theoretical model\nPacket size = ' + str(packet_size_byte) + r', $\alpha$ =' + "{0:.2f}".format(path_lost_expo) + r' and $\sigma$ = ' + "{0:.2f}".format(sigma)        
        image_fname = datadir + '/PRR_VAL_ANA.eps'                
        plot.plotScatter(x_scatter, y_scatter, xlab, ylab, image_fname, titre, min_x, max_x, min_y, max_y, stic_x, \
                    stic_y, xticslabels, xticInt, yticInt, y_decimal=1)  
        
        labels = []
        datas = []
        
        list_keys = tab_dict.keys()
        list_keys.sort()
        for dist in list_keys:
            labels.append(int(dist))
            datas.append(tab_dict[dist])
        
        image_fname = datadir + '/STAT_THEO_PRR.eps'
        plot.plot_box_plot(image_fname, datas, labels, xlab, ylab, titre)
                   
        titre = 'PRR distribution : Empirical values'
        ylab = 'PRR'
        labels = []
        datas = []        
        list_keys = tab_dict_emp.keys()
        list_keys.sort()
        for dist in list_keys:
            labels.append(int(dist))
            datas.append(tab_dict_emp[dist])        
        image_fname = datadir + '/STAT_EMP_PRR.eps'
        plot.plot_box_plot(image_fname, datas, labels, xlab, ylab, titre)
                  
    
    """
    PDF and CDF  of RSSI and PRR
    """ 
    list_distance = [3, 6, 9, 12]   
    for dist in list_distance:
        """
        RSSI
        """
        tab_theo = RED.read_pdf_or_cdf_distance(datadir, 'PDF', 'RSSI', None, dist, 'ANA', is_data_dir = True)
        tab_emp = RED.read_pdf_or_cdf_distance(rep_emrirical_data, 'PDF', 'RSSI', None, dist, '', is_data_dir = True)

        
        if (len(tab_theo) >0) and (len(tab_emp) > 0):
            xx = [[val[0] for val in tab_theo], [val[0] for val in tab_emp]]
            yy = [[val[1] for val in tab_theo], [val[1] for val in tab_emp]]
            legends = ['Analytical Model', 'Empirical data']
            legend_title = ''
            
            min_rssi = min(min([v for v in xx]))
            max_rssi = max(max([v for v in xx])) + 0.5
            stic_x = (max_rssi - min_rssi)/5.0
            xticslabels = None
            
            min_y = min(min([v for v in yy]))
            max_y = max(max([v for v in yy])) + 0.02
            
            xlabel = 'RSSI (dBm)'
            ylabel = 'PDF'        
            x_int = 1
            y_int = 0        
            title = ''
            stic_y = 0.1
    
            image_fname = datadir + '/VALIDATION_RSSI_PDF_' + str(dist) + 'M.eps'       
            plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(xx, yy, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                        x_int, y_int, 0, min_rssi, max_rssi, min_y, max_y, stic_x, stic_y, xticslabels,y_decimal=1)
        
        tab_theo = RED.read_pdf_or_cdf_distance(datadir, 'CDF', 'RSSI', None, dist, 'ANA', is_data_dir = True)
        tab_emp = RED.read_pdf_or_cdf_distance(rep_emrirical_data, 'CDF', 'RSSI', None, dist, '', is_data_dir = True)
        
        if (len(tab_theo) >0) and (len(tab_emp) > 0):        
            xx = [[val[0] for val in tab_theo], [val[0] for val in tab_emp]]
            yy = [[val[1] for val in tab_theo], [val[1] for val in tab_emp]]
            legends = ['Analytical Model', 'Empirical data']
            legend_title = ''
            
            min_rssi = min(min([v for v in xx]))
            max_rssi = max(max([v for v in xx])) + 0.5
            
            min_y = min(min([v for v in yy]))
            max_y = max(max([v for v in yy])) + 0.02
            
            ylabel = 'CDF'
            
            image_fname = datadir + '/VALIDATION_RSSI_CDF_' + str(dist) + 'M.eps'       
            plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(xx, yy, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                        x_int, y_int, 0, min_rssi, max_rssi, min_y, max_y, stic_x, stic_y, xticslabels,y_decimal=1)
        
        """
        PRR
        """
        tab_theo = RED.read_pdf_or_cdf_distance(datadir, 'PDF', 'PRR', None, dist, 'ANA', is_data_dir = True)
        tab_emp = RED.read_pdf_or_cdf_distance(rep_emrirical_data, 'PDF', 'PRR', None, dist, '', is_data_dir = True)

        
        if (len(tab_theo) >0) and (len(tab_emp) > 0):
            xx = [[val[0] for val in tab_theo], [val[0] for val in tab_emp]]
            yy = [[val[1] for val in tab_theo], [val[1] for val in tab_emp]]
            legends = ['Analytical Model', 'Empirical data']
            legend_title = ''
            
            min_prr = 0.1
            max_prr = 1.02
            stic_x = 0.1
            xticslabels = None
            
            min_y = min(min([v for v in yy]))
            max_y = max(max([v for v in yy])) + 0.02
            
            xlabel = 'PRR'
            ylabel = 'PDF'        
            x_int = 0
            y_int = 0        
            title = ''
            stic_y = 0.1
    
            image_fname = datadir + '/VALIDATION_PRR_PDF_' + str(dist) + 'M.eps'       
            plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(xx, yy, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                        x_int, y_int, 0, min_prr, max_prr, min_y, max_y, stic_x, stic_y, xticslabels,y_decimal=1,x_decimal=1)
        
        tab_theo = RED.read_pdf_or_cdf_distance(datadir, 'CDF', 'PRR', None, dist, 'ANA', is_data_dir = True)
        tab_emp = RED.read_pdf_or_cdf_distance(rep_emrirical_data, 'CDF', 'PRR', None, dist, '', is_data_dir = True)
                
        if (len(tab_theo) >0) and (len(tab_emp) > 0):
            xx = [[val[0] for val in tab_theo], [val[0] for val in tab_emp]]
            yy = [[val[1] for val in tab_theo], [val[1] for val in tab_emp]]
            legends = ['Analytical Model', 'Empirical data']
            legend_title = ''
            
            min_y = min(min([v for v in yy]))
            max_y = max(max([v for v in yy])) + 0.02
            
            ylabel = 'CDF'
            
            image_fname = datadir + '/VALIDATION_PRR_CDF_' + str(dist) + 'M.eps'       
            plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(xx, yy, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                        x_int, y_int, 0, min_prr, max_prr, min_y, max_y, stic_x, stic_y, xticslabels,y_decimal=1,x_decimal=1)
        
    
    """
    ALL LINKs RSSI
    """    
    tab_theo = RED.read_pdf_or_cdf_distance(datadir, 'PDF', 'RSSI', None, None, 'ANA', is_data_dir = True)
    tab_emp = RED.read_pdf_or_cdf_distance(rep_emrirical_data, 'PDF', 'RSSI', None, None, '', is_data_dir = True)

    
    if (len(tab_theo) >0) and (len(tab_emp) > 0):
        xx = [[val[0] for val in tab_theo], [val[0] for val in tab_emp]]
        yy = [[val[1] for val in tab_theo], [val[1] for val in tab_emp]]
        legends = ['Analytical Model', 'Empirical data']
        legend_title = ''
        
        min_rssi = min(min([v for v in xx]))
        max_rssi = max(max([v for v in xx])) + 0.5
        stic_x = (max_rssi - min_rssi)/5.0
        xticslabels = None
        
        min_y = min(min([v for v in yy]))
        max_y = max(max([v for v in yy])) + 0.02
        
        xlabel = 'RSSI (dBm)'
        ylabel = 'PDF'        
        x_int = 1
        y_int = 0        
        title = ''
        stic_y = 0.1
    
        image_fname = datadir + '/VALIDATION_RSSI_PDF_ALL_LINKS.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(xx, yy, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_rssi, max_rssi, min_y, max_y, stic_x, stic_y, xticslabels,y_decimal=1)
    
    tab_theo = RED.read_pdf_or_cdf_distance(datadir, 'CDF', 'RSSI', None, None, 'ANA', is_data_dir = True)
    tab_emp = RED.read_pdf_or_cdf_distance(rep_emrirical_data, 'CDF', 'RSSI', None, None, '', is_data_dir = True)
    
    if (len(tab_theo) >0) and (len(tab_emp) > 0):
        xx = [[val[0] for val in tab_theo], [val[0] for val in tab_emp]]
        yy = [[val[1] for val in tab_theo], [val[1] for val in tab_emp]]
        legends = ['Analytical Model', 'Empirical data']
        legend_title = ''
        
        min_rssi = min(min([v for v in xx]))
        max_rssi = max(max([v for v in xx])) + 0.5
        
        min_y = min(min([v for v in yy]))
        max_y = max(max([v for v in yy])) + 0.02
        
        ylabel = 'CDF'
        
        image_fname = datadir + '/VALIDATION_RSSI_CDF_ALL_LINKS.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(xx, yy, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_rssi, max_rssi, min_y, max_y, stic_x, stic_y, xticslabels,y_decimal=1)
            

    """
    ALL LINKs PRR
    """    
    tab_theo = RED.read_pdf_or_cdf_distance(datadir, 'PDF', 'PRR', None, None, 'ANA', is_data_dir = True)
    tab_emp = RED.read_pdf_or_cdf_distance(rep_emrirical_data, 'PDF', 'PRR', None, None, '', is_data_dir = True)
    
    if (len(tab_theo) >0) and (len(tab_emp) > 0):
        xx = [[val[0] for val in tab_theo], [val[0] for val in tab_emp]]
        yy = [[val[1] for val in tab_theo], [val[1] for val in tab_emp]]
        legends = ['Analytical Model', 'Empirical data']
        legend_title = ''
        
        min_prr = 0.1
        max_prr = 1.02
        stic_x = 0.1
        xticslabels = None
        
        min_y = min(min([v for v in yy]))
        max_y = max(max([v for v in yy])) + 0.02
        
        xlabel = 'PRR'
        ylabel = 'PDF'        
        x_int = 0
        y_int = 0        
        title = ''
        stic_y = 0.1
    
        image_fname = datadir + '/VALIDATION_PRR_PDF_ALL_LINKS.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(xx, yy, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_rssi, max_rssi, min_y, max_y, stic_x, stic_y, xticslabels,y_decimal=1,x_decimal=1)
    
    tab_theo = RED.read_pdf_or_cdf_distance(datadir, 'CDF', 'PRR', None, None, 'ANA', is_data_dir = True)
    tab_emp = RED.read_pdf_or_cdf_distance(rep_emrirical_data, 'CDF', 'PRR', None, None, '', is_data_dir = True)
    
    if (len(tab_theo) > 0) and (len(tab_emp) > 0):
        xx = [[val[0] for val in tab_theo], [val[0] for val in tab_emp]]
        yy = [[val[1] for val in tab_theo], [val[1] for val in tab_emp]]
        legends = ['Analytical Model', 'Empirical data']
        legend_title = ''
        
        min_y = min(min([v for v in yy]))
        max_y = max(max([v for v in yy])) + 0.02
        
        ylabel = 'CDF'
        
        image_fname = datadir + '/VALIDATION_PRR_CDF_ALL_LINKS.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(xx, yy, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_prr, max_prr, min_y, max_y, stic_x, stic_y, xticslabels,y_decimal=1,x_decimal=1)
                          
def compare_distribution(msize, base_dir_emp, base_dir_theo, image_dir):
    theo_flat = RED.read_pdf_or_cdf_distance(base_dir_theo + '/FLAT_26_3_' + str(msize), 'CDF', 'PRR', None, None, 'ANA', is_data_dir = True)
    theo_hill = RED.read_pdf_or_cdf_distance(base_dir_theo + '/FLAT_HILL_26_3_' + str(msize), 'CDF', 'PRR', None, None, 'ANA', is_data_dir = True)
    
    emp_flat = RED.read_pdf_or_cdf_distance(base_dir_emp + '/MSG/3/' + str(msize), 'CDF', 'PRR', None, None, '', is_data_dir = True)
    emp_hill = RED.read_pdf_or_cdf_distance(base_dir_emp + '/Coline/MSG/3/' + str(msize), 'CDF', 'PRR', None, None, '', is_data_dir = True)
    
    if (len(theo_flat) > 0) and (len(theo_hill) >0) and (len(emp_flat) > 0) and (len(emp_hill) > 0):
        xx = [[val[0] for val in emp_flat], [val[0] for val in theo_flat], [val[0] for val in emp_hill], [val[0] for val in theo_hill]]
        yy = [[val[1] for val in emp_flat], [val[1] for val in theo_flat], [val[1] for val in emp_hill], [val[1] for val in theo_hill]]

        legends = ['Measured data: flat', 'Theoretical data: flat','Measured data: hill', 'Theoretical data: hill']
        legend_title = ''
        
        min_prr = 0.1
        max_prr = 1.02
        stic_x = 0.1
        x_int = 0
        xticslabels = None
        
        min_y = 0
        max_y = max(max([v for v in yy])) + 0.02
        stic_y = 0.1
        y_int = 0
        
        ylabel = 'CDF'
        xlabel = 'Packet reception ratio'
        title = ''
        
        image_fname = image_dir + '/VALIDATION_PRR_FLAT_HILL_CDF_ALL_LINKS_' + str(msize) + '.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(xx, yy, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 0, min_prr, max_prr, min_y, max_y, stic_x, stic_y, xticslabels,y_decimal=1,x_decimal=1)
    
    theo_flat = RED.read_pdf_or_cdf_distance(base_dir_theo + '/FLAT_26_3_' + str(msize), 'CDF', 'RSSI', None, None, 'ANA', is_data_dir = True)
    theo_hill = RED.read_pdf_or_cdf_distance(base_dir_theo + '/FLAT_HILL_26_3_' + str(msize), 'CDF', 'RSSI', None, None, 'ANA', is_data_dir = True)
    
    emp_flat = RED.read_pdf_or_cdf_distance(base_dir_emp + '/MSG/3/' + str(msize), 'CDF', 'RSSI', None, None, '', is_data_dir = True)
    emp_hill = RED.read_pdf_or_cdf_distance(base_dir_emp + '/Coline/MSG/3/' + str(msize), 'CDF', 'RSSI', None, None, '', is_data_dir = True)
    
    if (len(theo_flat) > 0) and (len(theo_hill) >0) and (len(emp_flat) > 0) and (len(emp_hill) > 0):
        xx = [[val[0] for val in emp_flat], [val[0] for val in theo_flat], [val[0] for val in emp_hill], [val[0] for val in theo_hill]]
        yy = [[val[1] for val in emp_flat], [val[1] for val in theo_flat], [val[1] for val in emp_hill], [val[1] for val in theo_hill]]

        legends = ['Measured data: flat', 'Theoretical data: flat','Measured data: hill', 'Theoretical data: hill']
        legend_title = ''
        
        min_rssi = min([min(x) for x in xx])
        max_rssi = max([max(x) for x in xx])
        stic_x = (max_rssi - min_rssi)/5
        x_int = 1
        xticslabels = None
        
        min_y = 0
        max_y = max(max([v for v in yy])) + 0.02
        stic_y = 0.1
        y_int = 0
        
        ylabel = 'CDF'
        xlabel = 'Received power'
        title = ''
        
        image_fname = image_dir + '/VALIDATION_RSSI_FLAT_HILL_CDF_ALL_LINKS_' + str(msize) + '.eps'       
        plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(xx, yy, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                    x_int, y_int, 3, min_rssi, max_rssi, min_y, max_y, stic_x, stic_y, xticslabels,y_decimal=1,x_decimal=1)    
    
    
                  