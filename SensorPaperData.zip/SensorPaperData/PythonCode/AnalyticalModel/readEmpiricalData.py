
import copy
import os

def readAllPRR(nb_node, rep_emrirical_data,  min_prr, max_prr):
    all_prr_link = []
    for i in range(nb_node):
        for j in range(nb_node):
            if i==j:
                continue
            else:
                #Le PRR
                empirical_prr_link = []
                fname = rep_emrirical_data + '/PRR_' + str(i+1) + '_' + str(j+1) + '.data'
                if os.path.isfile(fname) and os.access(fname, os.R_OK):    
                    ifile = open(fname, 'r')
                    for line in ifile:
                        data = line.strip('\r\n').split(' ')
                        if len(data) != 2:
                            continue
                        empirical_prr_link.append(float(data[1]))
                    ifile.close()
                    #theorical_prr_link = T.generate_prr_array(abs(i-j)*node_distance, param, len(empirical_prr_link))
                    e_prr = []
                    for prr in empirical_prr_link:
                        if prr >= min_prr and prr <= max_prr:
                            e_prr.append(prr)                
                    all_prr_link.append((i+1, j+1, copy.deepcopy(e_prr)))
    return all_prr_link
                        

def readAllRSSI(nb_node, rep_emrirical_data):
    all_rss_link = []
    for i in range(nb_node):
        for j in range(nb_node):
            if i==j:
                continue
            else:                        
                #Le RSSI
                empirical_rssi_link = []            
                fname = rep_emrirical_data + '/MESSAGES_' + str(i+1) + '_' + str(j+1) + '.data'
                if os.path.isfile(fname) and os.access(fname, os.R_OK):    
                    ifile = open(fname, 'r')
                    for line in ifile:
                        data = line.strip('\r\n').split(' ')
                        if len(data) != 6:
                            continue
                        if data[4] != '?':
                            empirical_rssi_link.append(float(data[4]))
                    ifile.close()            
                    
                    all_rss_link.append((i+1, j+1, copy.deepcopy(empirical_rssi_link)))
    return all_rss_link

def readSymetricRSSI(nb_node, rep_emrirical_data):
    all_rss_link = []
    for i in range(nb_node-1):
        for j in range(i+1, nb_node):
            #Link i->j
            empirical_rssi_link_i_j = []            
            fname = rep_emrirical_data + '/MESSAGES_' + str(i+1) + '_' + str(j+1) + '.data'
            if os.path.isfile(fname) and os.access(fname, os.R_OK):    
                ifile = open(fname, 'r')
                for line in ifile:
                    data = line.strip('\r\n').split(' ')
                    if len(data) != 6:
                        continue
                    if data[4] != '?':
                        empirical_rssi_link_i_j.append(float(data[4]))
                ifile.close()            
            #Link i->j
            empirical_rssi_link_j_i = []            
            fname = rep_emrirical_data + '/MESSAGES_' + str(j+1) + '_' + str(i+1) + '.data'
            if os.path.isfile(fname) and os.access(fname, os.R_OK):    
                ifile = open(fname, 'r')
                for line in ifile:
                    data = line.strip('\r\n').split(' ')
                    if len(data) != 6:
                        continue
                    if data[4] != '?':
                        empirical_rssi_link_j_i.append(float(data[4]))
                ifile.close()            
                
            if len(empirical_rssi_link_i_j) != 0 and len(empirical_rssi_link_j_i) != 0:
                all_rss_link.append((i+1, j+1, copy.deepcopy(empirical_rssi_link_i_j), copy.deepcopy(empirical_rssi_link_j_i)))
    return all_rss_link
