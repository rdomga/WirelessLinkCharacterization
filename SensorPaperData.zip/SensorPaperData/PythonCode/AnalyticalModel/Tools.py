
import random, math, sys, os
import copy as CP
from scipy import stats, copy
from Param import Param

#Convert a power from dBm to milliwat
def dbm2mwatt(power_dBm):
    return float(math.pow(10.0, power_dBm/10.0));

#Convert a powerfrom milliwatt to dB
def mwatt2dB(power_mwatt):
    return 10.0*math.log10(power_mwatt)
    
#Convert a power from dbm to watt
def dbm2watt(power_dBm):
    return float(math.pow(10.0, power_dBm/10.0))/1000.0;
    

"""
This function calculated the attenuation
params :
    path_lost_d0 : The path loss at the reference distance d0    
    path_lost_expo : The path loss exponnent
    sigma : The fading is modelled by a gauss RV of mean 0 and standar deviation sigma
    distance : The distance between the transmitter and the receiver
    distanc_0 : The reference distance
"""
def get_attenuation(path_lost_d0, path_lost_expo, sigma, distance, distance0):
    """
    sigma_mw = dbm2mwatt(sigma)
    val = -1
    while val < 0:
        val = random.gauss(0.0, sigma_mw)
    val_dbm = mwatt2dB(val)
    """
    shadowing_dbm = random.gauss(0.0, 1)*sigma
    return - path_lost_d0 - 10.0*path_lost_expo*math.log10(float(distance)/float(distance0)) + shadowing_dbm

def get_ideal_attenuation(path_lost_d0, path_lost_expo, distance, distance0):
    return - path_lost_d0 - 10.0*path_lost_expo*math.log10(float(distance)/float(distance0))
    
"""
This function calculated the received power
params :
    output_power : The Transmission power in dB
    attenuation : The attenuation in dB
"""    
def get_rcv_power(output_power, attenuation):
    return output_power + attenuation
    
"""
This function calculated the BER for OPSQ modulation
params :
    snr : Signal to nose ratio in dB
    bandwidth : The channel bandwidth in Hz
    data_rate : The data rate in bits/s
"""    
def get_ber_opsq(snr, noise_bandwidth_Hz, data_rate):
    return 0.5*math.erfc(math.sqrt((2.0*snr*noise_bandwidth_Hz)/(data_rate*math.sqrt(2.0)))) 

"""
This function calculated the packet reception rate
params :
    ber : The bit Error Rate
    packet_size : The packet size in Byte
"""
def get_prr(ber, packet_size):
    return math.pow(1.0-ber, packet_size*8.0)

"""
This function calculated the noise floor noise floor
noise_floor_dBm : The noise floor standard deviation or Value depending of the second parameter
type : How to calculate the noise floor If 
  - 0, we assume a Gaussian random process of mean 0 and standard deviation noise_floor_dBm
  - otherwise noise_floor_dBm is returned as noise floor
"""
def getNoiseFloor(noise_floor_dBm, type=0):
    if type == 0 :
        n_f_mw = dbm2mwatt(noise_floor_dBm)
        val = -1
        while val < 0:
            val = random.gauss(0.0, 1)*n_f_mw
        return mwatt2dB(val)
    else :
        return noise_floor_dBm

def add_prr(prr_list, distance, prr):
    for vv in prr_list:
        if vv[0] == distance:
            vv[1].append(prr)
            return
    prr_list.append((distance, [prr]))

def add_rssi(rssi_list, distance, rssi):
    for vv in rssi_list:
        if vv[0] == distance:
            vv[1].append(rssi)
            return
    rssi_list.append((distance, [rssi]))

def cal_interval_proba(tab, max_val, interval_l):
    count = int(1.0/interval_l)
    proba = [0 for kk in range(count)]    
    for prr in tab:
        for k in range(count - 1):
            if ((prr >= float(k*interval_l)) and (prr < float((k+1)*interval_l))):
                proba[k] = proba[k] + 1                                    
        if ((prr >= float((count-1)*interval_l)) and (prr <= float(count*interval_l))):
            proba[count-1] = proba[count-1] + 1
    
    pdf = []    
    for k in range(count):
        pdf.append(float(proba[k])/float(len(tab)))
    
    cdf =[]
    for k in range(count):
        s_cdf = sum(proba[:(k+1)])
        cdf.append(float(s_cdf)/float(len(tab)))
    
    return [pdf,cdf]
    
def cal_intval_proba(tab, min_val, max_val):    
    proba = []
    nb_val = 0
    for v in tab:
        if math.ceil(v) >= min_val and math.ceil(v) <= max_val:
            nb_val += 1
            found = False
            for k in range(len(proba)):
                if proba[k][0] == math.ceil(v):
                    v = (math.ceil(v), proba[k][1] + 1)
                    proba[k] = v
                    found = True
                    break
            if not found:
                proba.append((math.ceil(v), 1))
    
    pdfs = []
    cdfs = []                
    sort_proba = sorted(proba, key=lambda x: x[0])
    for k in range(len(sort_proba)):
        pdf = float(sort_proba[k][1])/float(nb_val)
        cdf = sum([sort_proba[ii][1] for ii in range(k+1)])/float(nb_val)
        pdfs.append((sort_proba[k][0], pdf))
        cdfs.append((sort_proba[k][0], cdf))
            
    return [pdfs,cdfs]
    
def cal_interval_proba_borne(tab, min_val, max_val, interval_l):
    count = int((max_val - min_val)/interval_l)
    proba = [0 for kk in range(count)]    
    for val in tab:
        diff = val - min_val
        for k in range(count - 1):
            if ((diff >= float(k*interval_l)) and (diff < float((k+1)*interval_l))):
                proba[k] = proba[k] + 1                                    
        if ((diff >= float((count-1)*interval_l)) and (diff <= float(count*interval_l))):
            proba[count-1] = proba[count-1] + 1
    
    pdf = []    
    for k in range(count):
        pdf.append(float(proba[k])/float(len(tab)))
        
    return pdf
    
def statistical_test(dataset1, t1, dataset2, t2, data_type, dirname):    
    n1 = len(dataset1)
    n2 = len(dataset2)
    
    #print "N1 = ", n1, "N2 = ", n2
    ALL_DATA = []
    for v in dataset1:
        ALL_DATA.append((t1, v))
        
    for v in dataset2:
        ALL_DATA.append((t2, v))
        
    ALL_SORTED_DATA = sorted(ALL_DATA, key=lambda x: x[1])
    
    R_1 = 0
    R_2 = 0
    r = 0
    ALL_RANK = []
    #nn = n1 + n2
    #correction = 0
    sum_ties = 0
    while r < len(ALL_SORTED_DATA):    
        j = r+1
        count_equal = 1
        sum_rang = r+1
        while (j < len(ALL_SORTED_DATA)) and  (ALL_SORTED_DATA[j][1] == ALL_SORTED_DATA[r][1]):
            count_equal += 1
            sum_rang += (j+1)
            j += 1
            
        rang = float(sum_rang)/float(count_equal)
        
        #correction = float(count_equal)*(math.pow(count_equal, 2) - 1.0)/(math.pow(float(nn), 3) - float(nn))        
        sum_ties += math.pow(count_equal, 3.0) - count_equal
        
        for i in range(r, r+count_equal):
            ALL_RANK.append((ALL_SORTED_DATA[i], rang))
            if ALL_SORTED_DATA[i][0] == t1:
                R_1 += rang
            else:
                R_2 += rang
        
        #print r, count_equal, sum_rang,     
        r += count_equal
        
    avg_R_1 = R_1/float(n1)
    avg_R_2 = R_2/float(n2)    
    
    #print 'Dataset 1 : SOMME RANG = ', R_1, 'Rang Moyen = ', avg_R_1
    #print 'Dataset 2 : SOMME RANG = ', R_2, 'Rang Moyen = ', avg_R_2
    
    U_t = R_1 - float(n1)*(float(n1) +1)/2.0 
    U_e = R_2 - float(n2)*(float(n2) +1)/2.0
    U = min(U_t, U_e)
    #print '\nSTAT Manuelle'
    #print 'STAT Dataset 1 = ', U_t, 'STAT Dataset 2 =', U_e,'STAT Definitive = ', U 
    
        
    #print "mannwhitneyu TEST Results"    
    
    results = []
    test = stats.mannwhitneyu(dataset1, dataset2)
    mu = float(n1*n2)*0.5
    #variance = float(n1 * n2)*(n1 + n2 + 1.0)/12.0
    try:
        n = n1 + n2
        n_variance = (float(n1 * n2)*(math.pow(n, 3.0) - n - sum_ties))/(12.0*n*(n - 1.0))
        n_smu = math.sqrt(n_variance)
        
        U_cri = mu - 1.96*n_smu - 0.5
        Z = (test[0] - mu)/n_smu

        """
        print "\tU_obs = ", test[0]
        print "\t p_value = ", test[1]
        print "\tU_crti = ", U_cri
        print "\tZobs = ", Z
        """
        
        if test[0] > U_cri:
            results.append('O')
        else:
            results.append('N')
        
        if abs(Z) <= 1.96:
            results.append('O')
        else:
            results.append('N')
    
        #print "MU = ", mu, "SIGMA = ", n_smu
    except ValueError as e:
        print "Unexpected error:", sys.exc_info()[0]
    
    #print "\n\nKS test"
    try:
        test2 = stats.ks_2samp(dataset1, dataset2)
        c_alpha = math.sqrt(float(n1 + n2)/float(n1 * n2))
        D_Max = c_alpha*1.36
        #print test
        #print D_Max
        
        if test2[0] <= D_Max:
            results.append('O')
        else:
            results.append('N')
            
        D_Max1 = c_alpha*1.63
        if test2[0] <= D_Max1:
            results.append('O')
        else:
            results.append('N')
            
    except ValueError:
        print "Unexpected error:", sys.exc_info()[0]
        
    results.append((n1, n2))
    results.append((test[0],  test[1]*2, mu, n_smu, Z, U_cri, test2[0], test2[1], D_Max, D_Max1))
    
    return results
   
def generate_prr_array(distance, param, size):
    tab = []
    for p in range(size):
        attenuation_d = get_attenuation(param.path_lost_d0, param.path_lost_expo, param.sigma, distance, param.distance0)        
        receive_power_dBm_d = get_rcv_power(param.output_power_dBm, attenuation_d)
        
                
        noise_val = getNoiseFloor(param.n_f_dBm, param.noise_type)
        
        snr_d = dbm2watt(receive_power_dBm_d)/dbm2watt(noise_val)
    
        ber_d =  get_ber_opsq(snr_d, param.noise_bandwidth_Hz, param.data_rate_bitps)
        prr_d =  get_prr(ber_d, param.packet_size_byte)
        tab.append(prr_d)
    return tab
     
def generate_rssi_array(distance, param, size):
    tab = []
    for p in range(size):
        attenuation_d = get_attenuation(param.path_lost_d0, param.path_lost_expo, param.sigma, distance, param.distance0)        
        receive_power_dBm_d = get_rcv_power(param.output_power_dBm, attenuation_d)

        tab.append(receive_power_dBm_d)
    return tab    
    
def clean_data(data):
    taille = len(data)
    dd = sorted(data)
    
    i1 = int(taille/4)
    i2 = int(taille*3/4)
    Q1 = dd[i1]
    Q2 = dd[i2]
    IRQ = Q2 - Q1
    
    x = 1.5
    tab = []
    for v in data:
        if (v > Q1 - (x * IRQ)) and (v < Q2 + (x * IRQ)):
            tab.append(v)
                
    return tab
    #return data

def gets_statistic_element(tab):
    if len(tab) > 0:
        sorted_data = sorted(tab)
        N = len(sorted_data)
        min_data = sorted_data[0] 
        max_data = sorted_data[N-1]
        i1 = int(N/4)
        i2 = int(N*3/4)
        fst_qt = sorted_data[i1]
        snd_qt = sorted_data[i2]
        m = int(N/2)
        if N%2 == 0:
            mediane = (sorted_data[m] + sorted_data[m-1])/2.0
        else:
            mediane = sorted_data[m]
        avg = float(sum(sorted_data))/float(N)
        
        return [min_data, fst_qt, avg, mediane, snd_qt, max_data]
    else:
        return []
    
    
def getIndividualLinkData(nb_node, rep_emrirical_data, node_distance):
    all_rss_prr_link = [[], []]
    for i in range(nb_node):
        for j in range(nb_node):
            if i == j:
                continue
            empirical_rssi_link_i_j = []            
            fname = rep_emrirical_data + '/MESSAGES_' + str(i+1) + '_' + str(j+1) + '.data'
            if os.path.isfile(fname) and os.access(fname, os.R_OK):    
                ifile = open(fname, 'r')
                for line in ifile:
                    data = line.strip('\r\n').split(' ')
                    if len(data) != 6:
                        continue
                    if data[4] != '?':
                        empirical_rssi_link_i_j.append(float(data[4]))
                ifile.close()
            
            if len(empirical_rssi_link_i_j) != 0:
                all_rss_prr_link[0].append((node_distance*(abs(i-j)), CP.deepcopy(empirical_rssi_link_i_j)))
                
            empirical_prr_link_i_j = []
            fname = rep_emrirical_data + '/PRR_' + str(i+1) + '_' + str(j+1) + '.data'
            if os.path.isfile(fname) and os.access(fname, os.R_OK):    
                ifile = open(fname, 'r')
                for line in ifile:
                    data = line.strip('\r\n').split(' ')
                    if len(data) != 2:
                        continue
                    empirical_prr_link_i_j.append(float(data[1]))
                ifile.close()
            if len(empirical_prr_link_i_j) != 0:
                all_rss_prr_link[1].append((node_distance*(abs(i-j)), CP.deepcopy(empirical_prr_link_i_j)))                                
    return all_rss_prr_link


def statisticalTestPRRIndividualLink(List_PRR, link_param, min_prr, max_prr):
    all_results = []
    for emp_l_prr in List_PRR:
        theo_l_prr = generate_prr_array(emp_l_prr[0], link_param, len(emp_l_prr[1]))
        
        e_prr = []
        for prr in emp_l_prr[1]:
            if prr >= min_prr and prr <= max_prr:
                e_prr.append(prr)

        t_prr = []
        for prr in theo_l_prr:
            if prr >= min_prr and prr <= max_prr:
                t_prr.append(prr)
        if len(set(t_prr + e_prr)) != 1 and len(t_prr) != 0 and len(e_prr) != 0:
            r = statistical_test(t_prr, 't', e_prr, 'e', "PRR", '')
            all_results.append(('**', CP.deepcopy(r)))
        
    return all_results
        
def statisticalTestRSSIIndividualLink(List_RSSI, link_param):
    all_results = []
    for emp_l_rssi in List_RSSI:
        theo_l_rssi = generate_rssi_array(emp_l_rssi[0], link_param, len(emp_l_rssi[1]))
        
        e_rssi = []
        for rssi in emp_l_rssi[1]:
            e_rssi.append(rssi)

        t_rssi = []
        for rssi in theo_l_rssi:
            t_rssi.append(rssi)
        t1 = clean_data(t_rssi)
        t2 = clean_data(e_rssi)
        if len(set(t1 + t2)) != 1 and len(t1) != 0 and len(t2) != 0:
            r = statistical_test(t1, 't', t2, 'e', "RSSI", '')
            all_results.append(('**', CP.deepcopy(r)))
        
    return all_results

        