
import math, os
import PlotFunction as plot

import Tools as T

"""
#The maximal node position : We assume that the distance between nodes can vary from 1 meter to max_distance meters 
max_distance = int(sys.argv[1])

#The interval lengh for PRR point : The interval [0,1] is divided into sub-interval of same length "interval_l" 
interval_l = float(sys.argv[2])

#The packet size in byte
packet_size_byte = int(sys.argv[3])

#The standard deviation for fading
sigma = float(sys.argv[4])

#The standard deviation for noise floor : Value in dBm
sigma_noise_floor_dbm = float(sys.argv[5])
n_f_dBm = float(sys.argv[5])

#Path Loss exponent
path_lost_expo = float(sys.argv[6])

#Radio sensitivity
sensitivity = float(sys.argv[7])

#Output Directory
o_rep=sys.argv[8]
"""

def generate(max_distance, packet_size_byte, sigma, path_lost_expo, o_rep):
    interval_l = 0.1
    sensitivity = -100
    n_f_dBm = -85
    
    #print "PARAMETERS : ",packet_size_byte, sigma, path_lost_expo
    
    #The Transmission Power is set to 0dBm
    output_power_dBm = 0.0
    #The CC2420 frequency band is (2.4 - 2483.5 GHz). It is used to compute the signal attenuation at the reference distance and it is expressed in MHz. We use the value of 2480.0 MHz which we hope is the channel 26
    frequency_MHz = 2480.0
    
    #No data found in the CC2420 datasheet. We use the value define at this link :
    #http://www.fi.muni.cz/~xstetsko/simutools/castalia.pdf, available online on Febuary 12, 2016
    noise_bandwidth_Hz = 194000
    
    #The data rate in the band 2.4GHz is 250Kbits/s = 250000 bits/s
    #Reference : http://www.hikob.com/assets/uploads/2014/07/HIKOB_WISE_COW_ProductSheet_EN.pdf
    data_rate_bitps = 250000.0
    
    
    #Create the directory to store the data
    dirname = o_rep + '/SIMULATED'
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    
    #The list of path loss exponnent used : From 4 to 20
    #path_loss_exponent = [i for i in range(4, 21)]
    
    #The reference distance
    d0 = 1.0
    
    #The signal attenuation or the path loss at the reference distance in dB : For the reference distance a Free space model is used
    #path_lost_d0 = 20.0*math.log10(d0) + 20.0*math.log10(frequency_MHz) - 27.55
    path_lost_d0 = 20.0*math.log10(4.0*math.pi*frequency_MHz/300.0)
    
    #The output power in milliwatt
    output_power_mw = T.dbm2mwatt(output_power_dBm) 
    #The output power in dB
    output_power_dB = T.mwatt2dB(output_power_mw)
    
    #The noise floor in dBm for interference
    
    noise_type = 0
    
    nb_point = 200
    distribution = []
    list_rss = []
    
    """
    Received power as function of distance
    """
    rcv_power_file = open(dirname + '/Received_Power.data', 'w')
    for dd in range(max_distance):
        attenuation_d = T.get_attenuation(path_lost_d0, path_lost_expo, sigma, (dd+1), d0)        
        receive_power_dBm_d = T.get_rcv_power(output_power_dB, attenuation_d)
        rcv_power_file.write(str(dd+1) + ' ' + str(receive_power_dBm_d) + '\n')    
    rcv_power_file.close()    
    
    f_g_noise = open(dirname + '/Generated_Noise_Foor.data', 'w')
    
    for dd in range(max_distance):
        d = dd + 1
        distribution.append([])
        list_rss.append([])
    
        d_index = len(distribution) - 1
    
        for p in range(nb_point):
            receive_power_dBm_d = sensitivity - 10
            while receive_power_dBm_d < sensitivity:
                attenuation_d = T.get_attenuation(path_lost_d0, path_lost_expo, sigma, d, d0)        
                receive_power_dBm_d = T.get_rcv_power(output_power_dB, attenuation_d)
            
            noise_val = T.getNoiseFloor(n_f_dBm, noise_type)
            snr = receive_power_dBm_d - noise_val
            f_g_noise.write(str(noise_val) + '\n')
            
            
            snr_d_1 = math.pow(10.0, snr/10.0)
            snr_d_2 = T.dbm2watt(receive_power_dBm_d)/T.dbm2watt(n_f_dBm)
        
            ber_d =  T.get_ber_opsq(snr_d_2, noise_bandwidth_Hz, data_rate_bitps)
            prr_d =  T.get_prr(ber_d, packet_size_byte)
            distribution[d_index].append(prr_d)
            list_rss[d_index].append(receive_power_dBm_d)
            #print receive_power_dBm_d, prr_d
            
            #print receive_power_dBm_d, noise_floor_dBm
    
    distribution_rss = []
    distribution_prr = []
    n_val = 20
    for dd in range(max_distance):
        d = dd + 1
        distribution_rss.append([])
        distribution_prr.append([])
    
        d_index = len(distribution_rss) - 1
    
        for p in range(n_val):
            receive_power_dBm_d = sensitivity - 20
            while receive_power_dBm_d < sensitivity:
                attenuation_d = T.get_attenuation(path_lost_d0, path_lost_expo, sigma, d, d0)        
                receive_power_dBm_d = T.get_rcv_power(output_power_dB, attenuation_d)
            
            noise_val = T.getNoiseFloor(n_f_dBm, noise_type)
            snr = receive_power_dBm_d - noise_val
            f_g_noise.write(str(noise_val) + '\n')
                                
            snr_d_1 = math.pow(10.0, snr/10.0)
            snr_d_2 = T.dbm2watt(receive_power_dBm_d)/T.dbm2watt(n_f_dBm)
        
            ber_d =  T.get_ber_opsq(snr_d_2, noise_bandwidth_Hz, data_rate_bitps)
            prr_d =  T.get_prr(ber_d, packet_size_byte)
            
            distribution_prr[d_index].append(prr_d)
            distribution_rss[d_index].append(receive_power_dBm_d)
    
    ideal_rss = []
    real_rss = []
    dd = 1
    while dd <= max_distance:    
        ideal_receive_power_dBm = sensitivity - 20
        while ideal_receive_power_dBm < sensitivity:
            ideal_attenuation = T.get_ideal_attenuation(path_lost_d0, path_lost_expo, dd, d0)
            ideal_receive_power_dBm = T.get_rcv_power(output_power_dB, ideal_attenuation)
        ideal_rss.append((dd, ideal_receive_power_dBm))
    
        real_receive_power_dBm = sensitivity - 20
        while real_receive_power_dBm < sensitivity:
            real_attenuation = T.get_attenuation(path_lost_d0, path_lost_expo, sigma, dd, d0)        
            real_receive_power_dBm = T.get_rcv_power(output_power_dB, real_attenuation)    
        real_rss.append((dd, real_receive_power_dBm))
        
        dd += 0.25
    
    
    
    count = int(1.0/interval_l)
    #PDF PRR vs Distance
    proba = [[0 for kk in range(count)] for d in range(max_distance)]
    for i in range(max_distance):
        proba[i] = T.cal_interval_proba(distribution[i], 1.0, interval_l)
            
    #Save generated data into a file
    #PDF PRR vs Distance
    """
    y_con, y_trans, y_discon, y_no_mark
    """
    for i in range(max_distance):
        ofile = open(dirname + '/PDF_PRR_' + str(i+1) + 'M.data', 'w')
        for k in range(count):
            ofile.write(str((k+1)*interval_l) + ' '  + str(float(proba[i][0][k])) + '\n')
                     
        ofile.close()
        
    #CDF PRR vs Distance
    y_con = []
    y_trans = []
    y_discon = []
    
    y_no_mark = []
    for i in range(max_distance):
        ofile = open(dirname + '/CDF_PRR_' + str(i+1) + 'M.data', 'w')
        tab = []
        for k in range(count):
            ofile.write(str((k+1)*interval_l) + ' '  + str(float(proba[i][1][k])) + '\n')
            if i+1 == 3:
                y_con.append(float(proba[i][1][k]))
            
            if i+1 == 10:
                y_trans.append(float(proba[i][1][k]))
            
            if i+1 == 27:
                y_discon.append(float(proba[i][1][k]))
                
            if not (i in [0, 2, 26]):
                tab.append(float(proba[i][1][k]))
                
        y_no_mark.append(tab)
            
        ofile.close()
        
    #CDF PRR vs Distance : ALL LINK
    all_link_ofile = open(dirname + '/ANA_ALL_DISTRIB_PRR.data', 'w')
    all_pt = []
    for i in range(max_distance):
        for prr in distribution[i]:
            all_pt.append(prr)
            all_link_ofile.write(str(i+1) + ' '  + str(prr) + '\n')        
    all_link_ofile.close()
    
    dist_all_link = T.cal_interval_proba(all_pt, 1.0, interval_l)
    
    ofile = open(dirname + '/PDF_PRR_ALL_LINKS.data', 'w')
    for k in range(count):
        ofile.write(str((k+1)*interval_l) + ' '  + str(float(dist_all_link[0][k])) + '\n')
    ofile.close()
                    
    ofile = open(dirname + '/CDF_PRR_ALL_LINKS.data', 'w')
    for k in range(count):
        ofile.write(str((k+1)*interval_l) + ' '  + str(dist_all_link[1][k]) + '\n')
    ofile.close()
    
    #PDF and CDF RSSI vs Distance
    for i in range(max_distance):
        pdf_ofile = open(dirname + '/PDF_RSSI_' + str(i+1) + 'M.data', 'w')
        cdf_ofile = open(dirname + '/CDF_RSSI_' + str(i+1) + 'M.data', 'w')    
        proba = T.cal_intval_proba(list_rss[i], -86, -54)    
        for k in range(len(proba[0])):
            pdf_ofile.write(str(proba[0][k][0]) + ' ' + str(proba[0][k][1]) + '\n')
            cdf_ofile.write(str(proba[1][k][0]) + ' ' + str(proba[1][k][1]) + '\n')
        pdf_ofile.close()
        cdf_ofile.close()
    
    #PDF and CDF RSSI : ALL LINKS
    pdf_ofile = open(dirname + '/PDF_RSSI_ALL_LINKS.data', 'w')
    cdf_ofile = open(dirname + '/CDF_RSSI_ALL_LINKS.data', 'w')
    all_link_ofile = open(dirname + '/ANA_ALL_DISTRIB_RSSI.data', 'w')
    
    proba = []
    nb_point = 0
    all_rssi = []
    
    for i in range(max_distance):
        for rssi in list_rss[i]:
            all_rssi.append(rssi)        
            if math.ceil(rssi) >= -86 and math.ceil(rssi) <= -54:
                all_link_ofile.write(str(i+1) + ' '  + str(math.ceil(rssi)) + '\n')
    all_link_ofile.close()
    
    dist_all_link = T.cal_intval_proba(all_rssi, -86, -54)
    
    for k in range(len(dist_all_link[0])):
        pdf_ofile.write(str(dist_all_link[0][k][0]) + ' ' + str(dist_all_link[0][k][1]) + '\n')
        cdf_ofile.write(str(dist_all_link[1][k][0]) + ' ' + str(dist_all_link[1][k][1]) + '\n')
    pdf_ofile.close()
    cdf_ofile.close()
        
    #RSSI VAL
    ofile = open(dirname + '/RSSI_VAL.data', 'w')
    avg_ofile = open(dirname + '/AVG_RSSI_VAL.data', 'w')
    for d in range(max_distance):
        rssis = distribution_rss[d]
        for rss in rssis:
            ofile.write(str(d+1) + ' ' + str(rss) + '\n')    
        avg = float(sum(distribution_rss[d])) / float(len(distribution_rss[d]))
        avg_ofile.write(str(d+1) + ' ' + str(avg) + '\n')    
    ofile.close()
    avg_ofile.close()
    
    ofile = open(dirname + '/SIMULATED_RSSI.data', 'w')
    for i in range(len(ideal_rss)):
        ofile.write(str(ideal_rss[i][0]) + ' ' + str(ideal_rss[i][1]) + ' ' + str(real_rss[i][1]) + '\n')        
    ofile.close()
    
    #PRR VAL
    x_scatter_prr = []
    y_scatter_prr = []
    ofile = open(dirname + '/PRR_VAL.data', 'w')
    for d in range(max_distance):
        prrs = distribution_prr[d]
        for prr in prrs:
            ofile.write(str(d+1) + ' ' + str(prr) + '\n')
            x_scatter_prr.append(d+1)
            y_scatter_prr.append(prr)    
    ofile.close()
    f_g_noise.close()
    
    """
    Theoretical RSSI
    """
    x_data = [[val[0] for val in ideal_rss], [val[0] for val in real_rss]] 
    y_data = [[val[1] for val in ideal_rss], [val[1] for val in real_rss]]
    xlabel = 'Distance (m)'
    ylabel = 'Received power (dBm)'
    title = ''
    
    legends = ['Simple path-lost', 'Shadowing effects']
    legend_title = ''
    x_int = 1
    y_int = 1
    min_x = min([min(v) for v in x_data])
    max_x = min([max(v) for v in x_data]) + 0.5
    
    min_y = min([min(v) for v in y_data])
    max_y = min([max(v) for v in y_data]) + 0.5
    
    stic_x = (max_x - min_x)/5.0
    stic_y = (max_y - min_y)/5.0
    xticslabels = None
    
    image_fname = dirname + '/SIMULATED_RSSI.eps'       
    plot.PlotSingleTopologieMultipleCurves_AllParams_SomeMarkers(x_data, y_data, None, xlabel, ylabel, title, image_fname, legends, legend_title,\
                                                x_int, y_int, 0, min_x, max_x, min_y, max_y, stic_x, stic_y, xticslabels)
    
    
    min_x = min(x_scatter_prr) - 0.5
    max_x = max(x_scatter_prr) + 0.5
           
    min_y = min(y_scatter_prr)
    max_y = max(y_scatter_prr) + 0.02
    
    stic_x = (max_x - min_x)/10.0
    stic_y = 0.1
    
    xticInt = 1
    yticInt = 0        
    
    xticslabels = None
    
    verlineabs = [7, 22]
    xlab = 'Distance (m)'
    ylab = 'PRR'
    titre = ''
    #print packet_size_byte, path_lost_expo, sigma
    image_fname = dirname + '/ANAL_PRR_VAL.eps'                
    plot.plotScatter(x_scatter_prr, y_scatter_prr, xlab, ylab, image_fname, titre, min_x, max_x, min_y, max_y, stic_x, \
                stic_y, xticslabels, xticInt, yticInt, y_decimal=1, verlabs = verlineabs)  
    
    
    xx = [(k+1)*interval_l for k in range(count)]
    
    lab_con = 'distance 3M, Connected'
    lab_trans = 'distance 10M, Transitionnal'
    lab_discon = 'distance 27M, Disconnected'
    
    image_fname = dirname + '/ANAL_CDF_PRR.eps'                
    plot.Plot_Theoretical_PRR(xx, y_con, y_trans, y_discon, y_no_mark, lab_con, lab_trans, lab_discon, image_fname)
    
    
    
