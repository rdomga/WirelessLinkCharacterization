
import math,  os
import Tools as T
import readEmpiricalData as RED
from Param import Param


#The maximal node position : We assume that the distance between nodes can vary from 1 meter to max_distance meters 
max_distance = 30

#The interval lengh for PRR point : The interval [0,1] is divided into sub-interval of same length "interval_l" 
interval_l = 0.1

#The standard deviation for noise floor : Value in dBm
sigma_noise_floor_dbm = -85
n_f_dBm = -85

#Radio sensitivity
sensitivity = -100

#The Transmission Power is set to 0dBm
output_power_dBm = 0.0

#The CC2420 frequency band is (2.4 - 2483.5 GHz). It is used to compute the signal attenuation at the reference distance and it is expressed in MHz. We use the value of 2480.0 MHz which we hope is the channel 26
frequency_MHz = 2480.0

#No data found in the CC2420 datasheet. We use the value define at this link :
#http://www.fi.muni.cz/~xstetsko/simutools/castalia.pdf, available online on febuary 12, 2016
noise_bandwidth_Hz = 194000

#The data rate in the band 2.4GHz is 250Kbits/s = 250000 bits/s
#Reference : http://www.hikob.com/assets/uploads/2014/07/HIKOB_WISE_COW_ProductSheet_EN.pdf
data_rate_bitps = 250000.0

#packet_size_byte = int(sys.argv[3])



#Create the directory to store the data
#dirname = o_rep + '/' + str(packet_size_byte) + '_' + str(int(sigma)) + '/Model'
#if not os.path.exists(dirname):
#    os.makedirs(dirname)

#The list of path loss exponnent used : From 4 to 20
#path_loss_exponent = [i for i in range(4, 21)]

#The reference distance
d0 = 1.0
noise_type = 0

#The signal attenuation or the path loss at the reference distance in dB : For the reference distance a Free space model is used
#path_lost_d0 = 20.0*math.log10(d0) + 20.0*math.log10(frequency_MHz) - 27.55
path_lost_d0 = 20.0*math.log10(4.0*math.pi*frequency_MHz/300.0)

#The output power in milliwatt
output_power_mw = T.dbm2mwatt(output_power_dBm) 
#The output power in dB
output_power_dB = T.mwatt2dB(output_power_mw)

"""
packet_size_byte : The packet size
sigma : The standard deviation for fading
path_lost_expo : Path Loss exponent
o_rep : Output Directory
rep_emrirical_data : The directory containing empirical (experimental) data
node_distance : The distance beteewn two consecutive node
"""
def run(packet_size_byte, sigma, path_lost_expo, o_rep, rep_emrirical_data, node_distance):
    dirname = o_rep
    
    msize = packet_size_byte + 5
    #msize = 100
    #path_lost_expo = 3.6
    #sigma = 6.8
    print dirname
        
    #Read enpirical data from file
    em_prr = []
    fname = rep_emrirical_data + '/ALL_DISTRIB_PRR.data'
    if os.path.isfile(fname) and os.access(fname, os.R_OK):    
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            if len(data) != 2:
                continue
            T.add_prr(em_prr, int(data[0]), float(data[1]))
        ifile.close()
    
    min_val_rss = 200
    max_val_rss = -200
    em_rss = []
    fname = rep_emrirical_data + '/ALL_DISTRIB_RSSI.data'
    if os.path.isfile(fname) and os.access(fname, os.R_OK):    
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            if len(data) != 2:
                continue
            T.add_rssi(em_rss, int(data[0]), int(data[1]))
            
            if int(data[1]) > max_val_rss:
                max_val_rss = int(data[1])
            if int(data[1]) < min_val_rss:
                min_val_rss = int(data[1])
        ifile.close()
    
    """
    Pour chaque distance, donne le nombre de points de PRR qu'on a
    (distance, nb_points)
    """
    distance_set_prr = []
    for vv in em_prr:
        distance_set_prr.append((vv[0], len(vv[1])))
    
    """
    Pour chaque distance, donne le nombre de RSSI qu'on a
    """
    
    distance_set_rssi = []
    """
    Pour chaque distance, donne les RSSI MIN et MAX
    """
    max_min_dist = []
    for vv in em_rss:
        distance_set_rssi.append((vv[0], len(vv[1])))
        max_min_dist.append((vv[0], min(vv[1]), max(vv[1])))
    #print "RSSI Stat : ", distance_set_rssi
        
    #Generate PRR Value
    """
    Pour chaque distance, generer autant de PRR theorique que de RPP empirique dont on dispose
    """
    distribution = [[] for i in range(len(distance_set_prr))]
    for i in range(len(distance_set_prr)):
        """
        La distance
        """
        d = distance_set_prr[i][0]
        """
        Nombre de PRR empirique
        """
        nb_point = distance_set_prr[i][1]
        
        """
        Generation de nb_point PRRs theoriques
        """
        for p in range(nb_point):
            receive_power_dBm_d = sensitivity - 20
            while receive_power_dBm_d < sensitivity:
                attenuation_d = T.get_attenuation(path_lost_d0, path_lost_expo, sigma, d, d0)        
                receive_power_dBm_d = T.get_rcv_power(output_power_dB, attenuation_d)
    
            noise_val = T.getNoiseFloor(n_f_dBm, noise_type)
            snr = receive_power_dBm_d - noise_val
            
            snr_d_1 = math.pow(10.0, snr/10.0)
            snr_d_2 = T.dbm2watt(receive_power_dBm_d)/T.dbm2watt(noise_val)
        
            ber_d =  T.get_ber_opsq(snr_d_2, noise_bandwidth_Hz, data_rate_bitps)
            prr_d =  T.get_prr(ber_d, msize)
            distribution[i].append(prr_d)
    
    #Generate RSSI Value
    """
    Pour chaque distance, generer autant de RSSI theorique que de RSSI mesures dont on dispose
    """
    list_rss = [[] for i in range(len(distance_set_prr))]
    for i in range(len(distance_set_rssi)):
        d = distance_set_rssi[i][0]
        nb_point = distance_set_rssi[i][1]
        
        """
        min_v_rss = max_min_dist[i][1]
        max_v_rss = max_min_dist[i][2]
        """    
        for p in range(nb_point):
            receive_power_dBm_d = sensitivity - 20
            while receive_power_dBm_d < sensitivity:
                attenuation_d = T.get_attenuation(path_lost_d0, path_lost_expo, sigma, d, d0)        
                receive_power_dBm_d = T.get_rcv_power(output_power_dB, attenuation_d)
                        
            list_rss[i].append(receive_power_dBm_d)
            
    count = int(1.0/interval_l)
    
    #PDF PRR vs Distance
    proba = [[0 for kk in range(count)] for d in range(len(distance_set_prr))]
    for i in range(len(distance_set_prr)):
        proba[i] = T.cal_interval_proba(distribution[i], 1.0, interval_l)
                
    #Save generated data into a file
    for i in range(len(distance_set_prr)):
        ofile = open(dirname + '/PDF_PRR_ANA_' + str(distance_set_prr[i][0]) + 'M.data', 'w')
        for k in range(count):
            ofile.write(str((k+1)*interval_l) + ' '  + str(float(proba[i][0][k])) + '\n')
        ofile.close()
        
    #CDF PRR vs Distance
    for i in range(len(distance_set_prr)):
        ofile = open(dirname + '/CDF_PRR_ANA_' + str(distance_set_prr[i][0]) + 'M.data', 'w')
        for k in range(count):
            ofile.write(str((k+1)*interval_l) + ' '  + str(float(proba[i][1][k])) + '\n')
        ofile.close()
        
    #PDF and CDF RSSI vs Distance
    for i in range(len(distance_set_rssi)):
        pdf_ofile = open(dirname + '/PDF_RSSI_ANA_' + str(distance_set_rssi[i][0]) + 'M.data', 'w')
        cdf_ofile = open(dirname + '/CDF_RSSI_ANA_' + str(distance_set_rssi[i][0]) + 'M.data', 'w')    
        proba = T.cal_intval_proba(list_rss[i], max_min_dist[i][1], max_min_dist[i][2])    
        for k in range(len(proba[0])):
            pdf_ofile.write(str(proba[0][k][0]) + ' ' + str(proba[0][k][1]) + '\n')
            cdf_ofile.write(str(proba[1][k][0]) + ' ' + str(proba[1][k][1]) + '\n')
        pdf_ofile.close()
        cdf_ofile.close()
    
            
    #PDF PRR All link
    all_link_ofile = open(dirname + '/ANA_ALL_DISTRIB_PRR.data', 'w')
    all_pt = []
    for i in range(len(distance_set_prr)):
        for prr in distribution[i]:
            all_pt.append(prr)
            all_link_ofile.write(str(distance_set_prr[i][0]) + ' '  + str(prr) + '\n')        
    all_link_ofile.close()
    
    """
    Theoretical distribution : PRR
    """
    dist_all_link = T.cal_interval_proba(all_pt, 1.0, interval_l)            
    ofile = open(dirname + '/PDF_PRR_ANA_ALL_LINKS.data', 'w')
    for k in range(count):
        ofile.write(str((k+1)*interval_l) + ' '  + str(float(dist_all_link[0][k])) + '\n')
    ofile.close()
                    
    ofile = open(dirname + '/CDF_PRR_ANA_ALL_LINKS.data', 'w')
    for k in range(count):
        ofile.write(str((k+1)*interval_l) + ' '  + str(dist_all_link[1][k]) + '\n')
    ofile.close()
        
    #PDF and CDF RSSI : ALL LINKS
    pdf_ofile = open(dirname + '/PDF_RSSI_ANA_ALL_LINKS.data', 'w')
    cdf_ofile = open(dirname + '/CDF_RSSI_ANA_ALL_LINKS.data', 'w')
    all_link_ofile = open(dirname + '/ANA_ALL_DISTRIB_RSSI.data', 'w')
    
    proba = []
    nb_point = 0
    all_rssi = []    
    for i in range(len(distance_set_rssi)):
        for rssi in list_rss[i]:
            all_rssi.append(rssi)        
            if math.ceil(rssi) >= min_val_rss and math.ceil(rssi) <= max_val_rss:
                all_link_ofile.write(str(distance_set_rssi[i][0]) + ' '  + str(math.ceil(rssi)) + '\n')
    all_link_ofile.close()
    
    dist_all_link = T.cal_intval_proba(all_rssi, min_val_rss, max_val_rss)
    for k in range(len(dist_all_link[0])):
        pdf_ofile.write(str(dist_all_link[0][k][0]) + ' ' + str(dist_all_link[0][k][1]) + '\n')
        cdf_ofile.write(str(dist_all_link[1][k][0]) + ' ' + str(dist_all_link[1][k][1]) + '\n')
    pdf_ofile.close()
    cdf_ofile.close()
    
    
    
        
    #RSSI VAL
    ofile = open(dirname + '/RSSI_VAL_ANA.data', 'w')
    for i in range(len(distance_set_rssi)):
        rssis = list_rss[i]
        for rss in rssis:
            ofile.write(str(distance_set_rssi[i][0]) + ' ' + str(rss) + '\n')    
    ofile.close()
    
    #PRR VAL
    ofile = open(dirname + '/PRR_VAL_ANA.data', 'w')
    for i in range(len(distance_set_prr)):
        prrs = distribution[i]
        for prr in prrs:
            ofile.write(str(distance_set_prr[i][0]) + ' ' + str(prr) + '\n')    
    ofile.close()
    
    #PRR
    count = int(1.0/interval_l)
    min_prr = 0.1
    max_prr = 1.0
    
    theorical_prr = []
    for i in range(len(distance_set_prr)):
        for prr in distribution[i]:
            if prr >= min_prr and prr <= max_prr:
                theorical_prr.append(prr)
    
    empirical_prr = []
    for i in range(len(distance_set_prr)):
        for prr in em_prr[i][1]:
            if prr >= min_prr and prr <= max_prr:
                empirical_prr.append(prr)
    
    #Save data into a file
    ofile = open(dirname + '/EMP_PRR_VAL.data', 'w')
    for prr in empirical_prr:
        ofile.write(str(prr) + '\n')    
    ofile.close()
    
    ofile = open(dirname + '/THEO_PRR_VAL.data', 'w')
    for prr in theorical_prr:
        ofile.write(str(prr) + '\n')    
    ofile.close()
    
    theorical_rss = []
    for i in range(len(distance_set_rssi)):
        for rss in list_rss[i]:
            #if rss >= min_val_rss and rss <= max_val_rss:
            theorical_rss.append(rss)
    
    empirical_rss = []
    for i in range(len(distance_set_rssi)):
        for rss in em_rss[i][1]:
            #if rss >= min_val_rss and rss <= max_val_rss:
            empirical_rss.append(rss)
    
    ofile = open(dirname + '/EMP_RSS_VAL.data', 'w')
    for rss in empirical_rss:
        ofile.write(str(rss) + '\n')    
    ofile.close()
    
    ofile = open(dirname + '/THEO_RSS_VAL.data', 'w')
    for rss in theorical_rss:
        ofile.write(str(rss) + '\n')    
    ofile.close()
    
    print "PRR STATISTICAL TEST"
    r = T.statistical_test(theorical_prr, 't', empirical_prr, 'e', "PRR", dirname)
    #all_results_prr.append(('ALL_PRR', r))
    print r
    
    print "******************************************************************************************************"
    print "RSSI STATISTICAL TEST en dBm"
    t1 = T.clean_data(theorical_rss)
    t2 = T.clean_data(empirical_rss)
    if len(set(t1 + t2)) != 1 and len(t1) != 0 and len(t2) != 0:
        r = T.statistical_test(t1, 't', t2, 'e', "RSSI", dirname)
        #all_results_rssi.append(('ALL_RSSI', r))
        print r
    
    print "STATISTICAL TEST LINKS PAIRS"    
    nb_node = 5
    all_prr_link = RED.readAllPRR(nb_node, rep_emrirical_data, min_prr, max_prr)
    all_rss_link = RED.readAllRSSI(nb_node, rep_emrirical_data)
    all_rrs_link_pairs = RED.readSymetricRSSI(nb_node, rep_emrirical_data)
    
    all_results_prr = []
    all_results_rssi = []
    all_results_rssi_link_pairs = []
    
    nb_prr_link = len(all_prr_link)
    for i in range(nb_prr_link-1):
        for j in range(i+1, nb_prr_link):
            if len(set(all_prr_link[i][2] + all_prr_link[j][2])) != 1 and len(all_prr_link[i][2]) != 0 and len(all_prr_link[j][2]) != 0:
                r = T.statistical_test(all_prr_link[i][2], 'e1', all_prr_link[j][2], 'e2', "", "")
                all_results_prr.append((str(all_prr_link[i][0]) + '_' + str(all_prr_link[i][1]), r))
    
    nb_rssi_link = len(all_rss_link)
    for i in range(nb_rssi_link-1):
        for j in range(i+1, nb_rssi_link):
            t1 = T.clean_data(all_rss_link[i][2])
            t2 = T.clean_data(all_rss_link[j][2])
            
            if len(set(t1 + t2)) != 1 and len(t1) != 0 and len(t2) != 0:
                r = T.statistical_test(t1, 'e1', t2, 'e2', "", "")
                all_results_rssi.append((str(all_rss_link[i][0]) + '_' + str(all_rss_link[i][1]), r))
    
    nb_rssi_link_pair = len(all_rrs_link_pairs)
    for i in range(nb_rssi_link_pair):
        t1 = T.clean_data(all_rrs_link_pairs[i][2])
        t2 = T.clean_data(all_rrs_link_pairs[i][3])
        
        if len(set(t1 + t2)) != 1 and len(t1) != 0 and len(t2) != 0:
            r = T.statistical_test(t1, 'e1', t2, 'e2', "", "")
            all_results_rssi_link_pairs.append((str(all_rrs_link_pairs[i][0]) + '_' + str(all_rrs_link_pairs[i][1]), r))
    
    print "STAISTICAL TEST FOR PRR VALUES"
    nb_t = 0
    nb_ok = 0
    for v in all_results_prr:
        nb_t += 1
        if v[1][0] == 'O' or v[1][1] == 'O' or v[1][2] == 'O':
            nb_ok += 1
    if nb_t != 0:    
        print nb_t, nb_ok, float(nb_ok) / float(nb_t)
    
    print "STAISTICAL TEST FOR RSSI VALUES"
    nb_t = 0
    nb_ok = 0
    for v in all_results_rssi:
        nb_t += 1
        if v[1][0] == 'O' or v[1][1] == 'O' or v[1][2] == 'O':
            nb_ok += 1
    if nb_t != 0:    
        print nb_t, nb_ok, float(nb_ok) / float(nb_t)
        
    print "STAISTICAL TEST FOR RSSI VALUES, LINK PAIRS"
    nb_t = 0
    nb_ok = 0
    for v in all_results_rssi_link_pairs:
        nb_t += 1
        if v[1][0] == 'O' or v[1][1] == 'O' or v[1][2] == 'O':
            nb_ok += 1
    if nb_t != 0:    
        print nb_t, nb_ok, float(nb_ok) / float(nb_t)
        
    print "Test Individual LINK"    
    param = Param(max_distance, interval_l, msize, sigma, sigma_noise_floor_dbm, path_lost_expo, sensitivity, o_rep, 
                     output_power_dBm, frequency_MHz, noise_bandwidth_Hz, data_rate_bitps, dirname, d0, noise_type)
    
    emp_data_individual_link = T.getIndividualLinkData(nb_node, rep_emrirical_data, node_distance)
    
    r_prr = T.statisticalTestPRRIndividualLink(emp_data_individual_link[1], param, min_prr, max_prr)
    r_rssi = T.statisticalTestRSSIIndividualLink(emp_data_individual_link[0], param)
    
    #print r_prr
    #print r_rssi
    print "PRR LINKS"
    nb_t = 0
    nb_ok = 0
    for v in r_prr:
        nb_t += 1
        if v[1][0] == 'O' or v[1][1] == 'O' or v[1][2] == 'O':
            nb_ok += 1
            #print v[1]
    if nb_t != 0:    
        print nb_t, nb_ok, float(nb_ok) / float(nb_t)
    
    print "RSSI LINKS"
    nb_t = 0
    nb_ok = 0
    for v in r_rssi:
        nb_t += 1
        if v[1][0] == 'O' or v[1][1] == 'O' or v[1][2] == 'O':
            nb_ok += 1
            #print v[1]
    if nb_t != 0:    
        print nb_t, nb_ok, float(nb_ok) / float(nb_t)
    
    print "\n\n"
    
    
                
    