
import os, math

class Param:
    def __init__(self, max_distance, interval_l, packet_size_byte, sigma, sigma_noise_floor_dbm, path_lost_expo, sensitivity, o_rep, 
                 output_power_dBm, frequency_MHz, noise_bandwidth_Hz, data_rate_bitps, dirname, distance0, noise_type):
        self.max_distance = max_distance
        self.interval_l = interval_l
        self.packet_size_byte = packet_size_byte
        self.sigma = sigma
        self.sigma_noise_floor_dbm = sigma_noise_floor_dbm
        self.n_f_dBm = sigma_noise_floor_dbm
        self.path_lost_expo = path_lost_expo
        self.sensitivity = sensitivity
        self.o_rep = o_rep
        self.output_power_dBm = output_power_dBm
        self.frequency_MHz = frequency_MHz
        self.noise_bandwidth_Hz = noise_bandwidth_Hz
        self.data_rate_bitps = data_rate_bitps
        self.dirname = dirname
            
        self.distance0 = distance0
        self.noise_type = noise_type
        self.path_lost_d0 = 20.0*math.log10(4.0*math.pi*frequency_MHz/300.0)


        