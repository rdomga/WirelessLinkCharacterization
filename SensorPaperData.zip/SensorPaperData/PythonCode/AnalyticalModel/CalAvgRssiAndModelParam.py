
import os, math

#The frequency used if 2.4GHz = 2400 MHz. It is used to compute the signal attenuation at the reference distance and it is expressed in MHz
frequency_MHz = 2480.0

#The reference distance
d0 = 1.0

output_power_dBm = 0.0

#The signal attenuation or the path loss at the reference distance in dB : For the reference distance a Free space model is used
#path_lost_d0 = 20.0*math.log10(d0) + 20.0*math.log10(frequency_MHz) - 27.55
path_lost_d0 = 20.0*math.log10(4.0*math.pi*frequency_MHz/300.0)

def add_rssi(rssi_list, distance, rssi):
    for vv in rssi_list:
        if vv[0] == distance:
            vv[1].append(rssi)
            return
    rssi_list.append((distance, [rssi]))
                
def calc(channel, distance, msize, area = ''):
    if area == '':
        if channel == 26:
            base_dir = 'Extention/' + str(channel) + '/MSG/' + str(distance) + '/' + str(msize)
        else:
            base_dir = 'Extention/' + str(channel) + '/' + str(distance) + '/0dBm'
    else:
        if channel == 26:
            base_dir = 'Extention/' + str(channel) +'/' + area + '/MSG/' + str(distance) + '/' + str(msize)
        else:
            base_dir = 'Extention/' + str(channel) + '/' + str(distance) + '/0dBm'
        
    
    print base_dir
    all_rssi = []
    
    #Transmission power of 0dBm
    fname = base_dir + '/ALL_DISTRIB_RSSI.data'
    if os.path.isfile(fname) and os.access(fname, os.R_OK):
        ifile = open(fname, 'r')
        for line in ifile:
            data = line.strip('\r\n').split(' ')
            if len(data) != 2:
                continue
            add_rssi(all_rssi, int(data[0]), int(data[1]))
        ifile.close()


    list_rssi = []
    s_copy_all_rssi = sorted(all_rssi, key=lambda rssi_distance: rssi_distance[0])
    for rssis in s_copy_all_rssi:
        avg = float(sum(rssis[1]))/float(len(rssis[1]))
        list_rssi.append((rssis[0], avg))
                    
    Measured_RSS = [(x[0], x[1]) for x in list_rssi]

    FL = []
    for i in range(len(Measured_RSS)):
        if Measured_RSS[i][0] != d0:
            a = (output_power_dBm - Measured_RSS[i][1]) - path_lost_d0
            b = -1*10*math.log10(float(Measured_RSS[i][0])/float(d0))
            FL.append((a, b))
    #print FL
    
    FLL = []
    for cc in FL:
        a = cc[0]*cc[0]
        b = 2*cc[0]*cc[1]
        c = cc[1]*cc[1]
        FLL.append((a, b, c))
    #pATH-LOSS EXPONENT
    v = [0, 0, 0]    
    for cc in FLL:
        v[0] += cc[0]
        v[1] += cc[1]
        v[2] += cc[2]
    
    alpha = -1*v[1]/(2*v[2])    
    
    #Shadowing Variance
    ss = 0.0
    cc = 0.0
    for i in range(len(Measured_RSS)):
        if Measured_RSS[i][0] != d0:
            val = (output_power_dBm - Measured_RSS[i][1]) - path_lost_d0 - 10*alpha*math.log10(float(Measured_RSS[i][0])/float(d0))
            ss += val*val
            cc += 1.0
    variance = ss/cc
    sigma = math.sqrt(variance)

    return (alpha, sigma)

